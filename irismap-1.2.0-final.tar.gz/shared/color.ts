import type { BrandPalette } from "./hotelConfig";

/** Colour helpers for palettes: contrast checks and palettes from one or two colours. */

type Rgb = [number, number, number];

export function parseHex(hex: string): Rgb | null {
  const match = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(hex.trim());
  if (!match) return null;
  const value = match[1].length === 3 ? match[1].split("").map((c) => c + c).join("") : match[1];
  return [0, 2, 4].map((index) => parseInt(value.slice(index, index + 2), 16)) as Rgb;
}

const toHex = (rgb: Rgb) =>
  `#${rgb.map((channel) => Math.round(Math.min(255, Math.max(0, channel))).toString(16).padStart(2, "0")).join("").toUpperCase()}`;

/** Mixes `from` towards `to`; amount 0 keeps `from`, 1 gives `to`. */
export function mix(from: string, to: string, amount: number): string {
  const a = parseHex(from);
  const b = parseHex(to);
  if (!a || !b) return from;
  return toHex(a.map((channel, index) => channel + (b[index] - channel) * amount) as Rgb);
}

export function relativeLuminance(hex: string): number {
  const rgb = parseHex(hex);
  if (!rgb) return 0;
  const [r, g, b] = rgb.map((channel) => {
    const value = channel / 255;
    return value <= 0.03928 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** WCAG contrast ratio between two colours (1 to 21). */
export function contrastRatio(a: string, b: string): number {
  const [light, dark] = [relativeLuminance(a), relativeLuminance(b)].sort((x, y) => y - x);
  return (light + 0.05) / (dark + 0.05);
}

/** Darkens a colour step by step until white text on it is readable (4.5:1). */
export function readableOnWhite(hex: string): string {
  let color = hex.toUpperCase();
  for (let step = 0; step < 20 && contrastRatio(color, "#FFFFFF") < 4.5; step += 1) {
    color = mix(color, "#000000", 0.08);
  }
  return color;
}

/**
 * A complete palette from the hotel's main colour (and optional accent).
 * The main colour is darkened only if white button text would be hard to read.
 */
export function derivePalette(primary: string, accent = "#C9A46A"): BrandPalette {
  const main = readableOnWhite(primary);
  return {
    primary: main,
    primaryInk: main,
    primaryDeep: mix(main, "#000000", 0.42),
    accent: accent.toUpperCase(),
    accentSoft: mix(accent, "#FFFFFF", 0.45),
    page: "#FFFFFF",
    card: "#FFFFFF",
    soft: mix(accent, "#FFFFFF", 0.93),
    ink: "#2E2E2E",
    line: mix(accent, "#E6E6E3", 0.82),
    logoFrame: main,
  };
}
