import { contrastRatio } from "./color";
import { DESIGN_IDS, DESIGNS, isDesignId, type DesignId } from "./designs";
import { DESTINATIONS, isDestinationId, type DestinationId } from "./destinations";
import { isLanguage, LANGUAGES, type Language, type LocalizedText } from "./languages";

/* ------------------------------------------------------------------------ */
/* Normalised configuration (what the app receives)                          */
/* ------------------------------------------------------------------------ */

export interface BrandPalette {
  /** Buttons, badges and highlighted surfaces. */
  primary: string;
  /** Headings and links drawn in the primary colour (may be darker for contrast). */
  primaryInk: string;
  /** Deep shade used for gradients and dark panels. */
  primaryDeep: string;
  /** Secondary decorative colour (icons, outlines). */
  accent: string;
  /** Light tint of the accent, used on dark backgrounds. */
  accentSoft: string;
  /** Page background. */
  page: string;
  /** Card and panel background. */
  card: string;
  /** Soft tinted surface used for secondary cards. */
  soft: string;
  /** Main text colour. */
  ink: string;
  /** Hairline borders. */
  line: string;
  /** Background behind the hotel logo. */
  logoFrame: string;
}

export interface BrandVariant {
  id: string;
  palette: BrandPalette;
  logoUrl: string;
}

export interface SpecialDayRule extends BrandVariant {
  /** Fixed calendar days written as MM-DD. */
  dates: string[];
  /** Inclusive MM-DD range; may wrap over the new year. */
  range: { from: string; to: string } | null;
}

export interface PhoneNumber {
  display: string;
  /** Value for a `tel:` link, e.g. `+903325234242`. */
  dial: string;
}

export interface HotelFeatures {
  aiGuide: boolean;
  events: boolean;
  practicalInfo: boolean;
  roomNumber: boolean;
  feedback: boolean;
  weather: boolean;
  booking: boolean;
}

export interface HotelConfig {
  id: string;
  name: LocalizedText;
  shortName: string;
  tagline: LocalizedText;
  about: LocalizedText;
  stars: number | null;
  defaultLanguage: Language;
  languages: Language[];
  timezone: string;
  destination: DestinationId;
  city: LocalizedText;
  location: { lat: number; lng: number; address: LocalizedText };
  contact: {
    phone: PhoneNumber | null;
    whatsapp: (PhoneNumber & { number: string }) | null;
    email: string | null;
    website: string | null;
    bookingUrl: string | null;
    receptionHours: LocalizedText;
  };
  branding: {
    /** Ready-made design (typefaces, shapes, banner pattern, default colours). */
    design: DesignId;
    base: BrandVariant;
    alternate: BrandVariant | null;
    specialDays: SpecialDayRule[];
  };
  services: { included: LocalizedText[]; onRequest: LocalizedText[] };
  links: Array<{ label: LocalizedText; url: string }>;
  features: HotelFeatures;
  map: {
    surroundingsRadiusMeters: number;
    featuredPlaceIds: number[];
    /** Raster tile URL templates with {z}, {x} and {y}. */
    tileUrls: string[];
    tileAttribution: string;
    /**
     * MapLibre (vector) style address; OpenFreeMap by default. When it cannot
     * be loaded the map falls back to the raster tiles above. null: raster only.
     */
    styleUrl: string | null;
  };
  aroundHotelTour: {
    enabled: boolean;
    placeIds: number[];
    maxStops: number;
    radiusMeters: number;
  };
  emergencyContacts: Array<{ label: LocalizedText; phone: PhoneNumber }>;
  /** Who is responsible for guest data (KVKK/GDPR data controller). */
  privacy: {
    controller: string;
    email: string | null;
    policyUrl: string | null;
  };
}

/** Server-only settings that are never sent to the browser. */
export interface HotelServerSettings {
  hosts: string[];
  aiHotelFacts: string;
  /** Sales demo hotel: loaded only when demo mode is on. */
  demo: boolean;
}

export interface LoadedHotel {
  config: HotelConfig;
  server: HotelServerSettings;
}

/* ------------------------------------------------------------------------ */
/* Defaults                                                                  */
/* ------------------------------------------------------------------------ */

export const DEFAULT_PALETTE: BrandPalette = {
  primary: "#2F5D62",
  primaryInk: "#2F5D62",
  primaryDeep: "#1C3A3E",
  accent: "#C9A46A",
  accentSoft: "#E7D3AE",
  page: "#FFFFFF",
  card: "#FFFFFF",
  soft: "#F7F7F4",
  ink: "#2E2E2E",
  line: "#E6E6E3",
  logoFrame: "#2F5D62",
};

export const DEFAULT_FEATURES: HotelFeatures = {
  aiGuide: true,
  events: true,
  practicalInfo: true,
  roomNumber: true,
  feedback: true,
  weather: true,
  booking: true,
};

export const DEFAULT_FEATURED_PLACE_IDS = [1, 2, 3, 4];
export const DEFAULT_SURROUNDINGS_RADIUS_METERS = 850;
export const DEFAULT_TILE_URLS = ["a", "b", "c", "d"].map(
  (server) => `https://${server}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}@2x.png`,
);
export const DEFAULT_TILE_ATTRIBUTION = "&copy; OpenStreetMap contributors &copy; CARTO";
/**
 * Default base map: OpenFreeMap (free, also for commercial use, no key).
 * The raster tiles above are only the fallback when it cannot be reached.
 */
export const DEFAULT_STYLE_URL = "https://tiles.openfreemap.org/styles/positron";

/* ------------------------------------------------------------------------ */
/* Validation helpers                                                        */
/* ------------------------------------------------------------------------ */

type Raw = Record<string, unknown>;

export class ConfigProblems {
  readonly errors: string[] = [];
  readonly warnings: string[] = [];
  error(path: string, message: string) {
    this.errors.push(`${path}: ${message}`);
  }
  warn(path: string, message: string) {
    this.warnings.push(`${path}: ${message}`);
  }
}

const isObject = (value: unknown): value is Raw =>
  typeof value === "object" && value !== null && !Array.isArray(value);

const HEX_COLOR = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
const MONTH_DAY = /^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
const DAYS_IN_MONTH = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
const EMAIL = /^[^\s@<>"']+@[^\s@<>"']+\.[^\s@<>"']{2,}$/;
const HOSTNAME = /^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*(:\d{1,5})?$/;
export const TENANT_ID = /^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$/;

function checkKnownKeys(value: Raw, allowed: string[], path: string, problems: ConfigProblems) {
  for (const key of Object.keys(value)) {
    if (key.startsWith("$") || key.startsWith("_")) continue;
    if (!allowed.includes(key)) problems.warn(`${path}.${key}`, "unknown field is ignored (typo?)");
  }
}

function readLocalized(
  value: unknown,
  path: string,
  problems: ConfigProblems,
  { required = false, maxLength = 4000 }: { required?: boolean; maxLength?: number } = {},
): LocalizedText {
  if (value === undefined || value === null) {
    if (required) problems.error(path, "is required");
    return {};
  }
  if (typeof value === "string") {
    const text = value.trim();
    if (!text && required) problems.error(path, "must not be empty");
    if (text.length > maxLength) problems.error(path, `must be at most ${maxLength} characters`);
    return text ? Object.fromEntries(LANGUAGES.map((language) => [language, text])) : {};
  }
  if (!isObject(value)) {
    problems.error(path, "must be text or an object with language keys (TR, EN, DE, ZH, RU, AR)");
    return {};
  }
  const result: LocalizedText = {};
  for (const [key, entry] of Object.entries(value)) {
    if (!isLanguage(key)) {
      problems.error(`${path}.${key}`, `unknown language; use one of ${LANGUAGES.join(", ")}`);
      continue;
    }
    if (typeof entry !== "string") {
      problems.error(`${path}.${key}`, "must be text");
      continue;
    }
    const text = entry.trim();
    if (text.length > maxLength) problems.error(`${path}.${key}`, `must be at most ${maxLength} characters`);
    if (text) result[key] = text;
  }
  if (required && Object.keys(result).length === 0) problems.error(path, "needs at least one translation");
  return result;
}

function readNumber(
  value: unknown,
  path: string,
  problems: ConfigProblems,
  { min, max, integer = false, fallback }: { min: number; max: number; integer?: boolean; fallback: number },
): number {
  if (value === undefined) return fallback;
  if (typeof value !== "number" || !Number.isFinite(value) || (integer && !Number.isInteger(value))) {
    problems.error(path, integer ? "must be a whole number" : "must be a number");
    return fallback;
  }
  if (value < min || value > max) {
    problems.error(path, `must be between ${min} and ${max}`);
    return fallback;
  }
  return value;
}

function readBoolean(value: unknown, path: string, problems: ConfigProblems, fallback: boolean): boolean {
  if (value === undefined) return fallback;
  if (typeof value !== "boolean") {
    problems.error(path, "must be true or false");
    return fallback;
  }
  return value;
}

function readIdList(value: unknown, path: string, problems: ConfigProblems, fallback: number[]): number[] {
  if (value === undefined) return fallback;
  if (!Array.isArray(value) || !value.every((item) => Number.isInteger(item) && item > 0 && item < 100_000)) {
    problems.error(path, "must be a list of place ids (whole numbers)");
    return fallback;
  }
  const unique = [...new Set(value as number[])];
  if (unique.length !== value.length) problems.warn(path, "duplicate place ids are ignored");
  return unique;
}

function readUrl(value: unknown, path: string, problems: ConfigProblems): string | null {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string") {
    problems.error(path, "must be a web address");
    return null;
  }
  try {
    const url = new URL(value.trim());
    if (url.protocol !== "https:" && url.protocol !== "http:") throw new Error("protocol");
    if (url.protocol === "http:") problems.warn(path, "uses http; https is recommended");
    return url.toString();
  } catch {
    problems.error(path, "must be a full web address starting with https://");
    return null;
  }
}

export function parsePhone(value: unknown, path: string, problems: ConfigProblems): PhoneNumber | null {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string") {
    problems.error(path, "must be a phone number written as text, e.g. \"+90 332 523 42 42\"");
    return null;
  }
  const display = value.trim();
  if (!/^\+?[\d\s().-]+$/.test(display)) {
    problems.error(path, "may contain only digits, spaces, brackets, dashes and a leading +");
    return null;
  }
  const digits = display.replace(/\D/g, "");
  if (digits.length < 3 || digits.length > 15) {
    problems.error(path, "must contain between 3 and 15 digits");
    return null;
  }
  return { display, dial: display.startsWith("+") ? `+${digits}` : digits };
}

function readPalette(
  value: unknown,
  path: string,
  problems: ConfigProblems,
  base: BrandPalette,
): BrandPalette {
  if (value === undefined) return { ...base };
  if (!isObject(value)) {
    problems.error(path, "must be an object of colours");
    return { ...base };
  }
  const keys = Object.keys(base) as Array<keyof BrandPalette>;
  checkKnownKeys(value, keys, path, problems);
  const palette = { ...base };
  for (const key of keys) {
    const color = value[key];
    if (color === undefined) continue;
    if (typeof color !== "string" || !HEX_COLOR.test(color.trim())) {
      problems.error(`${path}.${key}`, "must be a hex colour such as #A0423D");
      continue;
    }
    palette[key] = color.trim().toUpperCase();
  }
  // A primary colour without an explicit ink/frame colour should follow it.
  if (value.primary !== undefined && value.primaryInk === undefined) palette.primaryInk = palette.primary;
  if (value.primary !== undefined && value.logoFrame === undefined) palette.logoFrame = palette.primary;
  return palette;
}

function readMonthDay(value: unknown, path: string, problems: ConfigProblems): string | null {
  if (typeof value !== "string" || !MONTH_DAY.test(value)) {
    problems.error(path, "must be a calendar day written as MM-DD, e.g. 12-07");
    return null;
  }
  const [month, day] = value.split("-").map(Number);
  if (day > DAYS_IN_MONTH[month - 1]) {
    problems.error(path, "is not a real calendar day");
    return null;
  }
  return value;
}

export type AssetResolver = (file: string) => string | null;

function readLogo(
  value: unknown,
  path: string,
  problems: ConfigProblems,
  resolveAsset: AssetResolver,
  required: boolean,
): string | null {
  if (value === undefined) {
    if (required) problems.error(path, "is required (file name inside the hotel's assets folder)");
    return null;
  }
  if (typeof value !== "string" || !value.trim()) {
    problems.error(path, "must be a file name such as logo.svg");
    return null;
  }
  const file = value.trim();
  if (/^https:\/\//.test(file)) return file;
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*\.(svg|png|jpe?g|webp)$/i.test(file)) {
    problems.error(path, "must be an .svg, .png, .jpg or .webp file name inside the assets folder");
    return null;
  }
  const url = resolveAsset(file);
  if (!url) problems.error(path, `file "${file}" was not found in the assets folder`);
  return url;
}

function isValidTimeZone(value: string): boolean {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: value }).format(new Date());
    return true;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------------ */
/* Normalisation                                                             */
/* ------------------------------------------------------------------------ */

const TOP_LEVEL_KEYS = [
  "id", "hosts", "demo", "name", "shortName", "tagline", "about", "stars", "defaultLanguage",
  "languages", "timezone", "destination", "location", "contact", "branding", "services",
  "links", "features", "map", "aroundHotelTour", "emergencyContacts", "ai", "privacy",
];

/** Great-circle distance in kilometres. */
function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const rad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * rad;
  const dLng = (b.lng - a.lng) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * 6371 * Math.asin(Math.sqrt(h));
}

/** Warns about colour pairs guests would find hard to read. */
function checkPaletteContrast(palette: BrandPalette, path: string, problems: ConfigProblems) {
  const pairs: Array<[keyof BrandPalette, keyof BrandPalette | "white", string]> = [
    ["primary", "white", "white button text on primary"],
    ["ink", "page", "ink text on the page colour"],
    ["ink", "card", "ink text on the card colour"],
    ["primaryInk", "page", "primaryInk headings on the page colour"],
  ];
  for (const [foreground, background, description] of pairs) {
    const ratio = contrastRatio(palette[foreground], background === "white" ? "#FFFFFF" : palette[background]);
    if (ratio < 4.5) {
      problems.warn(`${path}.${foreground}`, `${description} is hard to read (contrast ${ratio.toFixed(1)}:1, at least 4.5:1 recommended); choose a darker colour`);
    }
  }
}

/**
 * Validates a raw hotel configuration (the parsed `hotel.json`) and returns
 * a complete configuration with defaults applied. Every problem is reported
 * with its path so hotel staff can fix the file without reading code.
 */
export function normalizeHotelConfig(
  raw: unknown,
  resolveAsset: AssetResolver,
): { hotel: LoadedHotel | null; problems: ConfigProblems } {
  const problems = new ConfigProblems();
  if (!isObject(raw)) {
    problems.error("(root)", "the configuration must be a JSON object");
    return { hotel: null, problems };
  }
  checkKnownKeys(raw, TOP_LEVEL_KEYS, "(root)", problems);

  const id = typeof raw.id === "string" ? raw.id.trim() : "";
  if (!TENANT_ID.test(id)) {
    problems.error("id", "is required: lowercase letters, digits and dashes (e.g. \"grand-konya\")");
  }

  const hosts: string[] = [];
  if (raw.hosts !== undefined) {
    if (!Array.isArray(raw.hosts)) problems.error("hosts", "must be a list of domain names");
    else {
      raw.hosts.forEach((host, index) => {
        const value = typeof host === "string" ? host.trim().toLowerCase() : "";
        if (!HOSTNAME.test(value)) problems.error(`hosts[${index}]`, "must be a domain such as guide.example.com");
        else hosts.push(value);
      });
    }
  }

  const demo = readBoolean(raw.demo, "demo", problems, false);

  const defaultLanguage: Language = isLanguage(raw.defaultLanguage) ? raw.defaultLanguage : "TR";
  if (raw.defaultLanguage === undefined) problems.error("defaultLanguage", `is required (${LANGUAGES.join(", ")})`);
  else if (!isLanguage(raw.defaultLanguage)) problems.error("defaultLanguage", `must be one of ${LANGUAGES.join(", ")}`);

  let languages: Language[] = [...LANGUAGES];
  if (raw.languages !== undefined) {
    if (!Array.isArray(raw.languages) || raw.languages.length === 0 || !raw.languages.every(isLanguage)) {
      problems.error("languages", `must be a non-empty list from ${LANGUAGES.join(", ")}`);
    } else {
      languages = LANGUAGES.filter((language) => (raw.languages as unknown[]).includes(language));
    }
  }
  if (!languages.includes(defaultLanguage)) {
    problems.error("languages", "must include the defaultLanguage");
  }

  const name = readLocalized(raw.name, "name", problems, { required: true, maxLength: 80 });
  const primaryName = name[defaultLanguage] || name.EN || name.TR || Object.values(name)[0] || "Hotel";
  let shortName = primaryName;
  if (raw.shortName !== undefined) {
    if (typeof raw.shortName !== "string" || !raw.shortName.trim() || raw.shortName.trim().length > 24) {
      problems.error("shortName", "must be text of at most 24 characters");
    } else {
      shortName = raw.shortName.trim();
    }
  } else if (shortName.length > 24) {
    problems.warn("shortName", "is not set; the hotel name is long for a home-screen icon label");
  }

  const tagline = readLocalized(raw.tagline, "tagline", problems, { maxLength: 120 });
  const about = readLocalized(raw.about, "about", problems, { maxLength: 2000 });

  let stars: number | null = null;
  if (raw.stars !== undefined && raw.stars !== null) {
    stars = readNumber(raw.stars, "stars", problems, { min: 1, max: 5, integer: true, fallback: 0 }) || null;
  }

  const destination: DestinationId = isDestinationId(raw.destination) ? raw.destination : "konya";
  if (!isDestinationId(raw.destination)) {
    problems.error("destination", `must be one of: ${Object.keys(DESTINATIONS).join(", ")}`);
  }
  const destinationInfo = DESTINATIONS[destination];

  let timezone: string = destinationInfo.timezone;
  if (raw.timezone !== undefined) {
    if (typeof raw.timezone !== "string" || !isValidTimeZone(raw.timezone)) {
      problems.error("timezone", "must be an IANA time zone such as Europe/Istanbul");
    } else {
      timezone = raw.timezone;
    }
  }

  // Location
  let location = { lat: 0, lng: 0, address: {} as LocalizedText };
  if (!isObject(raw.location)) {
    problems.error("location", "is required with lat and lng");
  } else {
    checkKnownKeys(raw.location, ["lat", "lng", "address"], "location", problems);
    if (raw.location.lat === undefined) problems.error("location.lat", "is required");
    if (raw.location.lng === undefined) problems.error("location.lng", "is required");
    location = {
      lat: readNumber(raw.location.lat, "location.lat", problems, { min: -90, max: 90, fallback: 0 }),
      lng: readNumber(raw.location.lng, "location.lng", problems, { min: -180, max: 180, fallback: 0 }),
      address: readLocalized(raw.location.address, "location.address", problems, { maxLength: 300 }),
    };
    if (raw.location.lat !== undefined && raw.location.lng !== undefined && problems.errors.every((error) => !error.startsWith("location."))) {
      const away = distanceKm(location, destinationInfo.center);
      const city = destinationInfo.city.EN ?? destination;
      if (away > destinationInfo.areaRadiusKm * 4) {
        problems.error("location", `is ${Math.round(away)} km from ${city}; check that lat and lng are not swapped or mistyped`);
      } else if (away > destinationInfo.areaRadiusKm) {
        problems.warn("location", `is ${Math.round(away)} km from ${city}; the ${city} guide content may not suit this hotel`);
      }
    }
  }

  // Contact
  const contactRaw = raw.contact === undefined ? {} : raw.contact;
  const contact: HotelConfig["contact"] = {
    phone: null, whatsapp: null, email: null, website: null, bookingUrl: null, receptionHours: {},
  };
  if (!isObject(contactRaw)) {
    problems.error("contact", "must be an object");
  } else {
    checkKnownKeys(contactRaw, ["phone", "whatsapp", "email", "website", "bookingUrl", "receptionHours"], "contact", problems);
    contact.phone = parsePhone(contactRaw.phone, "contact.phone", problems);
    const whatsapp = parsePhone(contactRaw.whatsapp, "contact.whatsapp", problems);
    if (whatsapp) {
      const number = whatsapp.dial.replace(/\D/g, "");
      if (!whatsapp.dial.startsWith("+") || number.length < 8) {
        problems.error("contact.whatsapp", "must be an international number starting with + and the country code");
      } else {
        contact.whatsapp = { ...whatsapp, number };
      }
    }
    if (contactRaw.email !== undefined && contactRaw.email !== "") {
      if (typeof contactRaw.email !== "string" || !EMAIL.test(contactRaw.email.trim())) {
        problems.error("contact.email", "must be an e-mail address");
      } else {
        contact.email = contactRaw.email.trim();
      }
    }
    contact.website = readUrl(contactRaw.website, "contact.website", problems);
    contact.bookingUrl = readUrl(contactRaw.bookingUrl, "contact.bookingUrl", problems);
    contact.receptionHours = readLocalized(contactRaw.receptionHours, "contact.receptionHours", problems, { maxLength: 60 });
  }
  if (!contact.phone && !contact.whatsapp && !contact.email) {
    problems.warn("contact", "no phone, WhatsApp or e-mail is set; guests will not see any way to reach reception");
  }

  // Branding
  let branding: HotelConfig["branding"] = {
    design: "modern",
    base: { id: "base", palette: { ...DEFAULT_PALETTE }, logoUrl: "" },
    alternate: null,
    specialDays: [],
  };
  if (!isObject(raw.branding)) {
    problems.error("branding", "is required with at least a logo");
  } else {
    const brandingRaw = raw.branding;
    checkKnownKeys(brandingRaw, ["design", "logo", "palette", "alternate", "specialDays"], "branding", problems);
    let design: DesignId = "modern";
    if (brandingRaw.design !== undefined) {
      if (isDesignId(brandingRaw.design)) design = brandingRaw.design;
      else problems.error("branding.design", `must be one of: ${DESIGN_IDS.join(", ")}`);
    }
    const baseLogo = readLogo(brandingRaw.logo, "branding.logo", problems, resolveAsset, true) ?? "";
    const basePalette = readPalette(brandingRaw.palette, "branding.palette", problems, DESIGNS[design].palette);
    branding = {
      design,
      base: { id: "base", palette: basePalette, logoUrl: baseLogo },
      alternate: null,
      specialDays: [],
    };

    if (brandingRaw.alternate !== undefined) {
      if (!isObject(brandingRaw.alternate)) {
        problems.error("branding.alternate", "must be an object with palette and optional logo");
      } else {
        checkKnownKeys(brandingRaw.alternate, ["palette", "logo"], "branding.alternate", problems);
        branding.alternate = {
          id: "alternate",
          palette: readPalette(brandingRaw.alternate.palette, "branding.alternate.palette", problems, basePalette),
          logoUrl: readLogo(brandingRaw.alternate.logo, "branding.alternate.logo", problems, resolveAsset, false) ?? baseLogo,
        };
      }
    }

    if (brandingRaw.specialDays !== undefined) {
      if (!Array.isArray(brandingRaw.specialDays)) {
        problems.error("branding.specialDays", "must be a list");
      } else {
        brandingRaw.specialDays.forEach((rule, index) => {
          const path = `branding.specialDays[${index}]`;
          if (!isObject(rule)) {
            problems.error(path, "must be an object");
            return;
          }
          checkKnownKeys(rule, ["id", "dates", "from", "to", "palette", "logo"], path, problems);
          const ruleId = typeof rule.id === "string" && TENANT_ID.test(rule.id) ? rule.id : `special-${index + 1}`;
          if (rule.id !== undefined && ruleId !== rule.id) problems.error(`${path}.id`, "must use lowercase letters, digits and dashes");
          const dates: string[] = [];
          if (rule.dates !== undefined) {
            if (!Array.isArray(rule.dates)) problems.error(`${path}.dates`, "must be a list of MM-DD days");
            else rule.dates.forEach((date, dateIndex) => {
              const parsed = readMonthDay(date, `${path}.dates[${dateIndex}]`, problems);
              if (parsed) dates.push(parsed);
            });
          }
          let range: SpecialDayRule["range"] = null;
          if (rule.from !== undefined || rule.to !== undefined) {
            const from = readMonthDay(rule.from, `${path}.from`, problems);
            const to = readMonthDay(rule.to, `${path}.to`, problems);
            if (from && to) range = { from, to };
          }
          if (dates.length === 0 && !range) {
            problems.error(path, "needs \"dates\" or a \"from\"/\"to\" range");
            return;
          }
          branding.specialDays.push({
            id: ruleId,
            dates,
            range,
            palette: readPalette(rule.palette, `${path}.palette`, problems, basePalette),
            logoUrl: readLogo(rule.logo, `${path}.logo`, problems, resolveAsset, false) ?? baseLogo,
          });
        });
      }
    }
  }

  checkPaletteContrast(branding.base.palette, "branding.palette", problems);
  if (branding.alternate) checkPaletteContrast(branding.alternate.palette, "branding.alternate.palette", problems);
  branding.specialDays.forEach((rule, index) => checkPaletteContrast(rule.palette, `branding.specialDays[${index}].palette`, problems));

  // Services
  const services: HotelConfig["services"] = { included: [], onRequest: [] };
  if (raw.services !== undefined) {
    if (!isObject(raw.services)) problems.error("services", "must be an object with included / onRequest lists");
    else {
      checkKnownKeys(raw.services, ["included", "onRequest"], "services", problems);
      for (const key of ["included", "onRequest"] as const) {
        const list = raw.services[key];
        if (list === undefined) continue;
        if (!Array.isArray(list)) {
          problems.error(`services.${key}`, "must be a list");
          continue;
        }
        list.forEach((item, index) => {
          const text = readLocalized(item, `services.${key}[${index}]`, problems, { required: true, maxLength: 120 });
          if (Object.keys(text).length) services[key].push(text);
        });
      }
    }
  }

  // Links
  const links: HotelConfig["links"] = [];
  if (raw.links !== undefined) {
    if (!Array.isArray(raw.links)) problems.error("links", "must be a list");
    else raw.links.forEach((link, index) => {
      const path = `links[${index}]`;
      if (!isObject(link)) {
        problems.error(path, "must be an object with label and url");
        return;
      }
      checkKnownKeys(link, ["label", "url"], path, problems);
      const label = readLocalized(link.label, `${path}.label`, problems, { required: true, maxLength: 60 });
      const url = readUrl(link.url, `${path}.url`, problems);
      if (!url) {
        if (link.url === undefined) problems.error(`${path}.url`, "is required");
        return;
      }
      links.push({ label, url });
    });
  }

  // Features
  const features: HotelFeatures = { ...DEFAULT_FEATURES };
  if (raw.features !== undefined) {
    if (!isObject(raw.features)) problems.error("features", "must be an object of true/false switches");
    else {
      checkKnownKeys(raw.features, Object.keys(DEFAULT_FEATURES), "features", problems);
      for (const key of Object.keys(DEFAULT_FEATURES) as Array<keyof HotelFeatures>) {
        features[key] = readBoolean(raw.features[key], `features.${key}`, problems, DEFAULT_FEATURES[key]);
      }
    }
  }
  if (features.booking && !contact.bookingUrl && !contact.whatsapp) features.booking = false;
  if (features.feedback && !contact.whatsapp && !contact.email) features.feedback = false;

  // Map
  const map: HotelConfig["map"] = {
    surroundingsRadiusMeters: DEFAULT_SURROUNDINGS_RADIUS_METERS,
    featuredPlaceIds: [...DEFAULT_FEATURED_PLACE_IDS],
    tileUrls: [...DEFAULT_TILE_URLS],
    tileAttribution: DEFAULT_TILE_ATTRIBUTION,
    styleUrl: DEFAULT_STYLE_URL,
  };
  if (raw.map !== undefined) {
    if (!isObject(raw.map)) problems.error("map", "must be an object");
    else {
      checkKnownKeys(raw.map, ["surroundingsRadiusMeters", "featuredPlaceIds", "tileUrls", "tileAttribution", "styleUrl"], "map", problems);
      if (raw.map.styleUrl === false || raw.map.styleUrl === null || raw.map.styleUrl === "") {
        // Raster tiles only.
        map.styleUrl = null;
      } else if (raw.map.styleUrl !== undefined) {
        const styleUrl = readUrl(raw.map.styleUrl, "map.styleUrl", problems);
        if (styleUrl && !styleUrl.startsWith("https://")) problems.error("map.styleUrl", "must start with https:// (or false for raster tiles only)");
        else if (styleUrl) map.styleUrl = styleUrl;
      } else if (raw.map.tileUrls !== undefined) {
        // A hotel that chose its own raster provider keeps using it.
        map.styleUrl = null;
      }
      if (raw.map.tileUrls !== undefined) {
        const urls = raw.map.tileUrls;
        const valid = Array.isArray(urls)
          && urls.length > 0
          && urls.length <= 8
          && urls.every((url) => typeof url === "string" && /^https:\/\/[^\s"'<>]+$/.test(url) && url.includes("{z}") && url.includes("{x}") && url.includes("{y}"));
        if (!valid) problems.error("map.tileUrls", "must be a list of https tile addresses containing {z}, {x} and {y}");
        else map.tileUrls = urls as string[];
      }
      if (raw.map.tileAttribution !== undefined) {
        if (typeof raw.map.tileAttribution !== "string" || !raw.map.tileAttribution.trim() || raw.map.tileAttribution.length > 300) {
          problems.error("map.tileAttribution", "must be the map data credit text (at most 300 characters)");
        } else {
          map.tileAttribution = raw.map.tileAttribution.trim();
        }
      } else if (raw.map.tileUrls !== undefined) {
        problems.warn("map.tileAttribution", "is not set; add the credit text required by your map tile provider");
      }
      map.surroundingsRadiusMeters = readNumber(raw.map.surroundingsRadiusMeters, "map.surroundingsRadiusMeters", problems, {
        min: 100, max: 5000, integer: true, fallback: DEFAULT_SURROUNDINGS_RADIUS_METERS,
      });
      map.featuredPlaceIds = readIdList(raw.map.featuredPlaceIds, "map.featuredPlaceIds", problems, map.featuredPlaceIds);
    }
  }

  // Around-the-hotel walking tour
  const aroundHotelTour: HotelConfig["aroundHotelTour"] = { enabled: true, placeIds: [], maxStops: 8, radiusMeters: 700 };
  if (raw.aroundHotelTour !== undefined) {
    if (!isObject(raw.aroundHotelTour)) problems.error("aroundHotelTour", "must be an object");
    else {
      const tour = raw.aroundHotelTour;
      checkKnownKeys(tour, ["enabled", "placeIds", "maxStops", "radiusMeters"], "aroundHotelTour", problems);
      aroundHotelTour.enabled = readBoolean(tour.enabled, "aroundHotelTour.enabled", problems, true);
      aroundHotelTour.placeIds = readIdList(tour.placeIds, "aroundHotelTour.placeIds", problems, []);
      aroundHotelTour.maxStops = readNumber(tour.maxStops, "aroundHotelTour.maxStops", problems, { min: 2, max: 15, integer: true, fallback: 8 });
      aroundHotelTour.radiusMeters = readNumber(tour.radiusMeters, "aroundHotelTour.radiusMeters", problems, { min: 100, max: 5000, integer: true, fallback: 700 });
      if (aroundHotelTour.placeIds.length > 15) problems.error("aroundHotelTour.placeIds", "may contain at most 15 stops");
    }
  }

  // Extra emergency / useful numbers
  const emergencyContacts: HotelConfig["emergencyContacts"] = [];
  if (raw.emergencyContacts !== undefined) {
    if (!Array.isArray(raw.emergencyContacts)) problems.error("emergencyContacts", "must be a list");
    else raw.emergencyContacts.forEach((item, index) => {
      const path = `emergencyContacts[${index}]`;
      if (!isObject(item)) {
        problems.error(path, "must be an object with label and phone");
        return;
      }
      checkKnownKeys(item, ["label", "phone"], path, problems);
      const label = readLocalized(item.label, `${path}.label`, problems, { required: true, maxLength: 80 });
      const phone = parsePhone(item.phone, `${path}.phone`, problems);
      if (!phone && item.phone === undefined) problems.error(`${path}.phone`, "is required");
      if (phone) emergencyContacts.push({ label, phone });
    });
  }

  // AI (server only)
  let aiHotelFacts = "";
  if (raw.ai !== undefined) {
    if (!isObject(raw.ai)) problems.error("ai", "must be an object");
    else {
      checkKnownKeys(raw.ai, ["hotelFacts"], "ai", problems);
      if (raw.ai.hotelFacts !== undefined) {
        if (typeof raw.ai.hotelFacts !== "string" || raw.ai.hotelFacts.length > 3000) {
          problems.error("ai.hotelFacts", "must be text of at most 3000 characters");
        } else {
          aiHotelFacts = raw.ai.hotelFacts.trim();
        }
      }
    }
  }

  // Privacy (KVKK / GDPR): who answers guests' data questions.
  const privacy: HotelConfig["privacy"] = { controller: primaryName, email: contact.email, policyUrl: null };
  if (raw.privacy !== undefined) {
    if (!isObject(raw.privacy)) problems.error("privacy", "must be an object");
    else {
      checkKnownKeys(raw.privacy, ["controller", "email", "policyUrl"], "privacy", problems);
      if (raw.privacy.controller !== undefined) {
        if (typeof raw.privacy.controller !== "string" || !raw.privacy.controller.trim() || raw.privacy.controller.length > 160) {
          problems.error("privacy.controller", "must be the company name (at most 160 characters)");
        } else {
          privacy.controller = raw.privacy.controller.trim();
        }
      }
      if (raw.privacy.email !== undefined && raw.privacy.email !== "") {
        if (typeof raw.privacy.email !== "string" || !EMAIL.test(raw.privacy.email.trim())) {
          problems.error("privacy.email", "must be an e-mail address");
        } else {
          privacy.email = raw.privacy.email.trim();
        }
      }
      privacy.policyUrl = readUrl(raw.privacy.policyUrl, "privacy.policyUrl", problems);
    }
  }
  if (!privacy.email && !privacy.policyUrl) {
    problems.warn("privacy", "no e-mail or policyUrl; guests cannot see how to contact the hotel about their data (KVKK/GDPR)");
  }

  if (problems.errors.length > 0) return { hotel: null, problems };

  return {
    hotel: {
      config: {
        id,
        name,
        shortName,
        tagline,
        about,
        stars,
        defaultLanguage,
        languages,
        timezone,
        destination,
        city: destinationInfo.city,
        location,
        contact,
        branding,
        services,
        links,
        features,
        map,
        aroundHotelTour,
        emergencyContacts,
        privacy,
      },
      server: { hosts, aiHotelFacts, demo },
    },
    problems,
  };
}
