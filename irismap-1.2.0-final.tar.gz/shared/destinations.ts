import type { LocalizedText } from "./languages";

export interface DestinationInfo {
  id: string;
  city: LocalizedText;
  /** Search hint appended to Wikimedia Commons gallery queries. */
  commonsSearchHint: string;
  /** IANA time zone used when a hotel does not set one. */
  timezone: string;
  /** City centre and the area the content pack covers. */
  center: { lat: number; lng: number };
  areaRadiusKm: number;
}

/**
 * Content packs bundled with IrisMap. A hotel chooses one with the
 * `destination` field of its configuration.
 */
export const DESTINATIONS = {
  konya: {
    id: "konya",
    city: {
      TR: "Konya",
      EN: "Konya",
      DE: "Konya",
      ZH: "科尼亚",
      RU: "Конья",
      AR: "قونية",
    },
    commonsSearchHint: "Konya",
    timezone: "Europe/Istanbul",
    center: { lat: 37.8714, lng: 32.4846 },
    areaRadiusKm: 40,
  },
} satisfies Record<string, DestinationInfo>;

export type DestinationId = keyof typeof DESTINATIONS;

export const DESTINATION_IDS = Object.keys(DESTINATIONS) as DestinationId[];

export const isDestinationId = (value: unknown): value is DestinationId =>
  typeof value === "string" && Object.prototype.hasOwnProperty.call(DESTINATIONS, value);
