export const LANGUAGES = ["TR", "EN", "DE", "ZH", "RU", "AR"] as const;

export type Language = (typeof LANGUAGES)[number];

/** A text that can be written in any of the supported languages. */
export type LocalizedText = Partial<Record<Language, string>>;

export const isLanguage = (value: unknown): value is Language =>
  typeof value === "string" && (LANGUAGES as readonly string[]).includes(value);

/**
 * Picks the best available translation. Order: requested language, the
 * hotel's default language, English, Turkish, then any non-empty value.
 */
export function pickText(
  text: LocalizedText | undefined,
  language: Language,
  defaultLanguage: Language = "EN",
): string {
  if (!text) return "";
  const candidates: Language[] = [language, defaultLanguage, "EN", "TR"];
  for (const candidate of candidates) {
    const value = text[candidate]?.trim();
    if (value) return value;
  }
  for (const value of Object.values(text)) {
    if (value?.trim()) return value.trim();
  }
  return "";
}

/** Replaces `{name}` placeholders. Unknown placeholders are left untouched. */
export function formatText(template: string, values: Record<string, string | number> = {}): string {
  return template.replace(/\{([a-zA-Z]+)\}/g, (match, key: string) =>
    Object.prototype.hasOwnProperty.call(values, key) ? String(values[key]) : match,
  );
}
