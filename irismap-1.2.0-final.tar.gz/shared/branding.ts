import type { BrandVariant, HotelConfig, SpecialDayRule } from "./hotelConfig";

export interface CalendarDay {
  year: number;
  month: number;
  day: number;
}

/** Calendar date of `date` in the given IANA time zone. */
export function calendarDayIn(timeZone: string, date: Date = new Date()): CalendarDay {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "numeric",
    day: "numeric",
  }).formatToParts(date);
  const read = (type: Intl.DateTimeFormatPartTypes) =>
    Number(parts.find((part) => part.type === type)?.value);
  return { year: read("year"), month: read("month"), day: read("day") };
}

const monthDayValue = (value: string) => {
  const [month, day] = value.split("-").map(Number);
  return month * 100 + day;
};

export function matchesSpecialDay(rule: SpecialDayRule, { month, day }: CalendarDay): boolean {
  const today = month * 100 + day;
  if (rule.dates.some((date) => monthDayValue(date) === today)) return true;
  if (!rule.range) return false;
  const from = monthDayValue(rule.range.from);
  const to = monthDayValue(rule.range.to);
  // Ranges such as 12-20 → 01-05 wrap over the new year.
  return from <= to ? today >= from && today <= to : today >= from || today <= to;
}

/**
 * Chooses today's look: a special-day palette first, otherwise the base
 * palette, alternating daily with the optional alternate palette.
 */
export function resolveBrandVariant(
  branding: HotelConfig["branding"],
  timeZone: string,
  date: Date = new Date(),
): BrandVariant {
  const today = calendarDayIn(timeZone, date);
  const special = branding.specialDays.find((rule) => matchesSpecialDay(rule, today));
  if (special) return special;
  if (!branding.alternate) return branding.base;
  // UTC is only used as a stable day counter; the calendar day itself is local.
  const dayNumber = Math.floor(Date.UTC(today.year, today.month - 1, today.day) / 86_400_000);
  return dayNumber % 2 === 0 ? branding.base : branding.alternate;
}
