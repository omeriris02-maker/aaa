import type { BrandPalette } from "./hotelConfig";
import type { LocalizedText } from "./languages";

/*
 * Ready-made designs a hotel can choose with `branding.design`. A design
 * sets the typefaces, corner shapes, the pattern on the coloured banners and
 * default colours; the hotel's own palette (and logo) still win.
 */

export const DESIGN_IDS = ["modern", "klasik", "luks", "doga", "deniz"] as const;
export type DesignId = (typeof DESIGN_IDS)[number];

export const isDesignId = (value: unknown): value is DesignId =>
  typeof value === "string" && (DESIGN_IDS as readonly string[]).includes(value);

export interface DesignPreset {
  id: DesignId;
  name: LocalizedText;
  description: LocalizedText;
  palette: BrandPalette;
  /** Heading and body typefaces (self-hosted, see src/fonts.ts). */
  headingFont: string;
  bodyFont: string;
  /** Corner radii for Tailwind's rounded-lg … rounded-3xl. */
  radius: { lg: string; xl: string; "2xl": string; "3xl": string };
  /** Pattern drawn over the coloured banners (white lines, any brand colour). */
  pattern: string | null;
  /** Spacing of heading letters; formal designs use a little more. */
  headingTracking: string;
}

const svg = (body: string, size: number) =>
  `url("data:image/svg+xml,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' width='${size}' height='${size}' viewBox='0 0 ${size} ${size}'>${body}</svg>`)}")`;

/** Eight-pointed Seljuk star lattice. */
const STAR_PATTERN = svg(
  "<g fill='none' stroke='white' stroke-opacity='0.13' stroke-width='1.2'><path d='M28 6 L34 22 L50 28 L34 34 L28 50 L22 34 L6 28 L22 22 Z'/><rect x='16' y='16' width='24' height='24' transform='rotate(45 28 28)'/><rect x='16' y='16' width='24' height='24'/></g>",
  56,
);
const LINE_PATTERN = svg(
  "<g stroke='white' stroke-opacity='0.09' stroke-width='1'><path d='M0 40 L40 0'/><path d='M-10 10 L10 -10'/><path d='M30 50 L50 30'/></g>",
  40,
);
const LEAF_PATTERN = svg(
  "<g fill='white' fill-opacity='0.08'><path d='M18 40 C18 26 28 16 42 14 C40 28 32 38 18 40 Z'/><path d='M46 58 C44 48 50 40 60 38 C60 48 54 56 46 58 Z'/></g><path d='M18 40 L36 22' stroke='white' stroke-opacity='0.1' stroke-width='1'/>",
  64,
);
const WAVE_PATTERN = svg(
  "<g fill='none' stroke='white' stroke-opacity='0.11' stroke-width='1.4'><path d='M0 16 Q12 6 24 16 T48 16'/><path d='M0 36 Q12 26 24 36 T48 36'/></g>",
  48,
);
const DOT_PATTERN = svg("<circle cx='4' cy='4' r='1.2' fill='white' fill-opacity='0.12'/>", 18);

export const DESIGNS: Record<DesignId, DesignPreset> = {
  modern: {
    id: "modern",
    name: { TR: "Modern", EN: "Modern", DE: "Modern", ZH: "现代", RU: "Модерн", AR: "عصري" },
    description: {
      TR: "Sade, ferah ve çağdaş: yumuşak köşeler, net yazılar.",
      EN: "Clean, airy and contemporary: soft corners, crisp type.",
      DE: "Klar, luftig und zeitgemäß: weiche Ecken, klare Schrift.",
      ZH: "简洁、通透、现代：圆润的边角，清晰的字体。",
      RU: "Чистый, лёгкий и современный: мягкие углы, чёткий шрифт.",
      AR: "بسيط وعصري: زوايا ناعمة وخطوط واضحة.",
    },
    palette: {
      primary: "#2F5D62", primaryInk: "#2F5D62", primaryDeep: "#1C3A3E", accent: "#C9A46A", accentSoft: "#E7D3AE",
      page: "#FFFFFF", card: "#FFFFFF", soft: "#F7F7F4", ink: "#2E2E2E", line: "#E6E6E3", logoFrame: "#2F5D62",
    },
    headingFont: "Poppins",
    bodyFont: "Inter",
    radius: { lg: "0.5rem", xl: "0.75rem", "2xl": "1rem", "3xl": "1.5rem" },
    pattern: DOT_PATTERN,
    headingTracking: "0",
  },
  klasik: {
    id: "klasik",
    name: { TR: "Klasik", EN: "Classic", DE: "Klassisch", ZH: "经典", RU: "Классика", AR: "كلاسيكي" },
    description: {
      TR: "Selçuklu yıldız motifleri, bordo ve altın: tarihî otellere yakışan zarafet.",
      EN: "Seljuk star motifs in burgundy and gold: elegance for historic hotels.",
      DE: "Seldschukische Sternmotive in Bordeaux und Gold: Eleganz für historische Häuser.",
      ZH: "塞尔柱星纹搭配酒红与金色：适合历史酒店的优雅风格。",
      RU: "Сельджукские звёзды, бордо и золото: элегантность для исторических отелей.",
      AR: "زخارف النجمة السلجوقية بالعنابي والذهبي: أناقة تليق بالفنادق التاريخية.",
    },
    palette: {
      primary: "#8C2F39", primaryInk: "#8C2F39", primaryDeep: "#4A1A20", accent: "#C8A15A", accentSoft: "#E8D3A9",
      page: "#FFFDF9", card: "#FFFFFF", soft: "#FBF6EE", ink: "#2B2222", line: "#EADFCF", logoFrame: "#8C2F39",
    },
    headingFont: "Playfair Display",
    bodyFont: "Inter",
    radius: { lg: "0.375rem", xl: "0.5rem", "2xl": "0.625rem", "3xl": "0.875rem" },
    pattern: STAR_PATTERN,
    headingTracking: "0.01em",
  },
  luks: {
    id: "luks",
    name: { TR: "Lüks", EN: "Luxury", DE: "Luxus", ZH: "奢华", RU: "Люкс", AR: "فاخر" },
    description: {
      TR: "Antrasit ve altın, keskin hatlar ve ince serif yazılar: butik ve 5 yıldızlı oteller için.",
      EN: "Charcoal and gold with sharp lines and fine serif type: for boutique and five-star hotels.",
      DE: "Anthrazit und Gold, klare Linien und feine Serifen: für Boutique- und Fünf-Sterne-Hotels.",
      ZH: "炭黑与金色、利落线条与精致衬线字体：适合精品与五星级酒店。",
      RU: "Антрацит и золото, строгие линии и изящные засечки: для бутик-отелей и пяти звёзд.",
      AR: "الفحمي والذهبي مع خطوط حادة وحروف رشيقة: للفنادق البوتيك وفنادق الخمس نجوم.",
    },
    palette: {
      primary: "#26262B", primaryInk: "#26262B", primaryDeep: "#111114", accent: "#B8945A", accentSoft: "#E2CFA6",
      page: "#FAF8F4", card: "#FFFFFF", soft: "#F3EFE7", ink: "#1C1C1E", line: "#E4DED2", logoFrame: "#26262B",
    },
    headingFont: "Cormorant Garamond",
    bodyFont: "Inter",
    radius: { lg: "0.125rem", xl: "0.25rem", "2xl": "0.375rem", "3xl": "0.5rem" },
    pattern: LINE_PATTERN,
    headingTracking: "0.02em",
  },
  doga: {
    id: "doga",
    name: { TR: "Doğa", EN: "Nature", DE: "Natur", ZH: "自然", RU: "Природа", AR: "طبيعة" },
    description: {
      TR: "Orman yeşili ve sıcak toprak tonları, yumuşak hatlar: termal, bağ ve butik oteller için.",
      EN: "Forest green and warm earth tones with soft shapes: for spa, vineyard and boutique hotels.",
      DE: "Waldgrün und warme Erdtöne, sanfte Formen: für Thermal-, Weingut- und Boutiquehotels.",
      ZH: "森林绿与温暖大地色、柔和造型：适合温泉、庄园与精品酒店。",
      RU: "Лесной зелёный и тёплые земляные тона: для термальных, загородных и бутик-отелей.",
      AR: "أخضر الغابة ودرجات ترابية دافئة بأشكال ناعمة: لفنادق المنتجعات والبوتيك.",
    },
    palette: {
      primary: "#2F5E3A", primaryInk: "#2F5E3A", primaryDeep: "#1B3A23", accent: "#C08A4D", accentSoft: "#E8CFA7",
      page: "#FBFBF7", card: "#FFFFFF", soft: "#F1F5EC", ink: "#24302A", line: "#DDE5D6", logoFrame: "#2F5E3A",
    },
    headingFont: "Lora",
    bodyFont: "Inter",
    radius: { lg: "0.75rem", xl: "1rem", "2xl": "1.375rem", "3xl": "2rem" },
    pattern: LEAF_PATTERN,
    headingTracking: "0",
  },
  deniz: {
    id: "deniz",
    name: { TR: "Deniz", EN: "Coastal", DE: "Küste", ZH: "海岸", RU: "Морской", AR: "ساحلي" },
    description: {
      TR: "Lacivert ve mercan, dalga deseni: ferah, enerjik ve güler yüzlü.",
      EN: "Navy and coral with a wave pattern: fresh, lively and welcoming.",
      DE: "Marineblau und Koralle mit Wellenmuster: frisch, lebendig und einladend.",
      ZH: "海军蓝与珊瑚色搭配波浪纹：清新、活力、亲切。",
      RU: "Тёмно-синий и коралловый с волнами: свежо, живо и приветливо.",
      AR: "الكحلي والمرجاني مع نقش الأمواج: منعش وحيوي ومرحّب.",
    },
    palette: {
      primary: "#1E4E79", primaryInk: "#1E4E79", primaryDeep: "#0F2C47", accent: "#E07A5F", accentSoft: "#F4C7B8",
      page: "#FFFFFF", card: "#FFFFFF", soft: "#F1F6FA", ink: "#1F2D3A", line: "#DCE6EE", logoFrame: "#1E4E79",
    },
    headingFont: "Montserrat",
    bodyFont: "Inter",
    radius: { lg: "0.625rem", xl: "0.875rem", "2xl": "1.25rem", "3xl": "1.75rem" },
    pattern: WAVE_PATTERN,
    headingTracking: "0",
  },
};

/** Fallbacks after the design typeface: Arabic and Chinese use dedicated or system fonts. */
export const FONT_FALLBACKS = `"Noto Sans Arabic", "PingFang SC", "Hiragino Sans GB", "Noto Sans SC", "Noto Sans CJK SC", "Microsoft YaHei"`;
