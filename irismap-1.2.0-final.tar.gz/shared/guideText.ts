import type { Language, LocalizedText } from "./languages";
import { formatText, pickText } from "./languages";
import type { HotelConfig } from "./hotelConfig";

/** Page title and description templates shared by the server and the app. */
const GUIDE_TITLE: Record<Language, string> = {
  TR: "{hotel} · {city} Misafir Rehberi",
  EN: "{hotel} · {city} Guest Guide",
  DE: "{hotel} · Gästeführer {city}",
  ZH: "{hotel} · {city}宾客指南",
  RU: "{hotel} · гид для гостей: {city}",
  AR: "{hotel} · دليل الضيوف في {city}",
};

const GUIDE_DESCRIPTION: Record<Language, string> = {
  TR: "{hotel} misafirleri için harita, yürüyüş rotaları, kültür takvimi ve pratik bilgiler.",
  EN: "Maps, walking routes, cultural events and practical tips for {hotel} guests.",
  DE: "Karten, Fußrouten, Kulturkalender und praktische Hinweise für Gäste von {hotel}.",
  ZH: "为{hotel}宾客提供地图、步行路线、文化日历和实用信息。",
  RU: "Карта, пешие маршруты, культурный календарь и полезные советы для гостей: {hotel}.",
  AR: "خرائط ومسارات مشي وتقويم ثقافي ومعلومات عملية لضيوف {hotel}.",
};

const GUIDE_LABEL: Record<Language, string> = {
  TR: "{city} Misafir Rehberi",
  EN: "{city} Guest Guide",
  DE: "Gästeführer {city}",
  ZH: "{city}宾客指南",
  RU: "Гид для гостей: {city}",
  AR: "دليل الضيوف في {city}",
};

export const hotelName = (config: Pick<HotelConfig, "name" | "defaultLanguage">, language: Language) =>
  pickText(config.name, language, config.defaultLanguage);

export const cityName = (config: Pick<HotelConfig, "city" | "defaultLanguage">, language: Language) =>
  pickText(config.city, language, config.defaultLanguage);

export const localized = (
  config: Pick<HotelConfig, "defaultLanguage">,
  text: LocalizedText | undefined,
  language: Language,
) => pickText(text, language, config.defaultLanguage);

export function guideTitle(config: HotelConfig, language: Language): string {
  return formatText(GUIDE_TITLE[language], {
    hotel: hotelName(config, language),
    city: cityName(config, language),
  });
}

export function guideDescription(config: HotelConfig, language: Language): string {
  return formatText(GUIDE_DESCRIPTION[language], {
    hotel: hotelName(config, language),
    city: cityName(config, language),
  });
}

/** "Konya Guest Guide" without the hotel name (QR posters, cards). */
export function guideLabel(config: HotelConfig, language: Language): string {
  return formatText(GUIDE_LABEL[language], { city: cityName(config, language) });
}
