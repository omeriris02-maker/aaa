import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig, type Plugin } from "vite";

const projectDirectory = path.dirname(fileURLToPath(import.meta.url));

/** Emits sw.js with a unique build id so each deployment gets a fresh cache. */
function serviceWorker(): Plugin {
  return {
    name: "irismap-service-worker",
    apply: "build",
    generateBundle() {
      const template = readFileSync(path.join(projectDirectory, "src/sw.template.js"), "utf8");
      const buildId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
      this.emitFile({
        type: "asset",
        fileName: "sw.js",
        source: template.replace(/__IRISMAP_BUILD_ID__/g, buildId),
      });
    },
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), serviceWorker()],
  // MapLibre's tile worker is an ES module (loaded with { type: "module" }).
  worker: { format: "es" },
  build: {
    // The MapLibre engine is large by nature and loads only on the map screen.
    chunkSizeWarningLimit: 1200,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (
            id.includes("placeTranslations.v31")
            || id.includes("nearby-heritage.json")
            || id.includes("destinations-100.json")
            || id.includes("destination-media.json")
          ) {
            return "place-content";
          }
          if (id.includes("node_modules/maplibre-gl")) return "maplibre";
          return undefined;
        },
      },
    },
  },
  server: {
    // HMR can be switched off (e.g. in hosted editors) with DISABLE_HMR=true.
    hmr: process.env.DISABLE_HMR !== "true",
    watch: process.env.DISABLE_HMR === "true" ? null : {},
  },
});
