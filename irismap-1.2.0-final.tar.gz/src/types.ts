export type { Language, LocalizedText } from "../shared/languages";

export type AccessibilityOptions = {
  elevator: boolean;
  wheelchair: boolean;
  disabledToilet: boolean;
  guideService: boolean;
};

export interface PhotoItem {
  url: string;
  caption_tr: string;
  caption_en: string;
  caption_de?: string;
  caption_zh: string;
  caption_ru?: string;
  caption_ar: string;
  source: string;
  license: string;
  sourceUrl?: string;
  /** Tried when `url` cannot be loaded (e.g. the original of a thumbnail). */
  fallbackUrl?: string;
}

export interface Place {
  id: number;
  isim_tr: string;
  isim_en: string;
  isim_de?: string;
  isim_zh: string;
  isim_ru?: string;
  isim_ar: string;
  kategori: 'UNESCO' | 'Müze' | 'Cami' | 'Türbe' | 'Medrese' | 'Tarihi Yapı' | 'Park' | 'Otel';
  aciklama_kisa_tr: string;
  aciklama_kisa_en: string;
  aciklama_kisa_de?: string;
  aciklama_kisa_zh: string;
  aciklama_kisa_ru?: string;
  aciklama_kisa_ar: string;
  tarihce_tr: string;
  tarihce_en: string;
  tarihce_de?: string;
  tarihce_zh: string;
  tarihce_ru?: string;
  tarihce_ar: string;
  koordinatlar: {
    lat: number;
    lng: number;
  };
  adres: string;
  telefon?: string;
  web?: string;
  email?: string;
  calisma_saatleri: {
    [key: string]: string;
  };
  giris_ucreti: {
    tr: string;
    en: string;
    zh: string;
    ar: string;
  };
  ziyaret_suresi_dk: number;
  fotograf_url: string[];
  fotograf?: PhotoItem[];
  etiketler: string[];
  erisilebilirlik: AccessibilityOptions;
  puan: number;
  yorum_sayisi: number;
  is_major?: boolean;
}

export interface Tour {
  id: number;
  isim_tr: string;
  isim_en: string;
  isim_de?: string;
  isim_zh: string;
  isim_ru?: string;
  isim_ar: string;
  aciklama_tr: string;
  aciklama_en: string;
  aciklama_de?: string;
  aciklama_zh: string;
  aciklama_ru?: string;
  aciklama_ar: string;
  duraklar: number[]; // Place IDs
  mesafe_km: number;
  sure_saat: number;
  briefing_tr?: string;
  briefing_en?: string;
  briefing_de?: string;
  briefing_zh?: string;
  briefing_ru?: string;
  briefing_ar?: string;
  gorsel_icon?: string;
}

export interface EventItem {
  id: number;
  isim_tr: string;
  isim_en: string;
  isim_de: string;
  isim_zh: string;
  isim_ru: string;
  isim_ar: string;
  aciklama_tr: string;
  aciklama_en: string;
  aciklama_de: string;
  aciklama_zh: string;
  aciklama_ru: string;
  aciklama_ar: string;
  tarih: string;
  tarih_tr: string;
  tarih_en: string;
  tarih_de: string;
  tarih_zh: string;
  tarih_ru: string;
  tarih_ar: string;
  saat: string;
  yer_tr: string;
  yer_en: string;
  yer_de: string;
  yer_zh: string;
  yer_ru: string;
  yer_ar: string;
  ucret_tr: string;
  ucret_en: string;
  ucret_de: string;
  ucret_zh: string;
  ucret_ru: string;
  ucret_ar: string;
  fotograf_url: string;
  fotograf_kaynak?: string;
  fotograf_kaynak_url?: string;
  fotograf_lisans?: string;
  baslangic_yil: number;
  baslangic_ay: number;
  baslangic_gun: number;
  bitis_yil: number;
  bitis_ay: number;
  bitis_gun: number;
  yillik: boolean;
  recurrence: "fixed-annual" | "manual";
  dateStatus: "confirmed" | "tentative";
  kaynak: string;
  kaynak_url?: string;
  son_dogrulama: string;
  aktif: boolean;
}
