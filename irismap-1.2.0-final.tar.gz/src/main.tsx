import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { resolveBrandVariant } from "../shared/branding";
import App from "./App";
import AppErrorBoundary, { FullPageError } from "./components/AppErrorBoundary";
import { loadHotelConfig } from "./config/hotel";
import { isLanguage } from "../shared/languages";
import { applyBrandVariant, applyDesign } from "./theme/brand";
import type { HotelConfig } from "../shared/hotelConfig";
import { saveStoredRoomNumber } from "./utils/guest";
import { migrateLegacyStorage, readString } from "./utils/storage";
import "./fonts";
import "./index.css";

if ("scrollRestoration" in window.history) {
  window.history.scrollRestoration = "manual";
}

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element is missing");
const root = createRoot(rootElement);

const startupLanguage = () => {
  const saved = readString("lang");
  return isLanguage(saved) ? saved : "TR";
};

const LINK_PARAMS = ["place", "room", "otel", "hotel"];

/**
 * Opens a shared place link (/?place=12), stores the room number of a room
 * QR card (/?room=204) and then cleans the address bar. Demo links
 * (/?otel=<id>) are handled by the server and only removed here.
 */
function applyDeepLink(hotel: HotelConfig) {
  const params = new URLSearchParams(window.location.search);
  if (!LINK_PARAMS.some((name) => params.has(name))) return;
  const room = params.get("room");
  if (room && hotel.features.roomNumber) saveStoredRoomNumber(room);
  const placeId = Number(params.get("place"));
  const state = Number.isInteger(placeId) && placeId > 0
    ? { irismap: { tab: "HOME", subView: null, placeId }, irismapIndex: 0 }
    : window.history.state;
  LINK_PARAMS.forEach((name) => params.delete(name));
  const query = params.toString();
  window.history.replaceState(state, "", `${window.location.pathname}${query ? `?${query}` : ""}${window.location.hash}`);
}

async function start() {
  migrateLegacyStorage();
  let hotel: HotelConfig;
  try {
    hotel = await loadHotelConfig();
    applyDesign(hotel.branding.design);
    applyBrandVariant(resolveBrandVariant(hotel.branding, hotel.timezone));
  } catch (error) {
    console.error("IrisMap could not load the hotel configuration", error);
    root.render(<FullPageError language={startupLanguage()} onReload={() => window.location.reload()} />);
    return;
  }
  applyDeepLink(hotel);
  root.render(
    <StrictMode>
      <AppErrorBoundary>
        <App />
      </AppErrorBoundary>
    </StrictMode>,
  );
}

void start();

if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((error) => {
      console.warn("Service worker registration failed", error);
    });
  });
}
