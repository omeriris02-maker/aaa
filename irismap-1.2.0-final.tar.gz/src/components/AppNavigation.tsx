import type { ComponentType, RefObject } from "react";
import { Calendar, Compass, Heart, Home, Landmark, Map, Settings, Sparkles } from "lucide-react";
import { ui } from "../i18n";
import type { Language } from "../types";
import HotelLogo from "./HotelLogo";
import LanguageMenu from "./LanguageMenu";

export type Tab = "HOME" | "MAP" | "PERSONAL" | "SETTINGS";
export type SubView = "PLACES" | "TOURS" | "EVENTS" | "PRACTICAL" | "AI_GUIDE" | "HOTEL" | "PRIVACY";

export interface NavTarget {
  id: Tab | SubView;
  isSub: boolean;
}

interface NavItem extends NavTarget {
  label: string;
  shortLabel: string;
  icon: ComponentType<{ className?: string }>;
}

const mainItems = (language: Language): NavItem[] => [
  { id: "HOME", isSub: false, label: ui(language, "Anasayfa", "Home"), shortLabel: ui(language, "Anasayfa", "Home"), icon: Home },
  { id: "MAP", isSub: false, label: ui(language, "İnteraktif Harita", "Interactive Map"), shortLabel: ui(language, "Harita", "Map"), icon: Map },
  { id: "TOURS", isSub: true, label: ui(language, "Hazır Rotalar", "Curated Routes"), shortLabel: ui(language, "Rotalar", "Routes"), icon: Compass },
  { id: "PERSONAL", isSub: false, label: ui(language, "Kişisel Planım", "Personal Planner"), shortLabel: ui(language, "Planım", "Planner"), icon: Heart },
  { id: "SETTINGS", isSub: false, label: ui(language, "Ayarlar", "Settings"), shortLabel: ui(language, "Ayarlar", "Settings"), icon: Settings },
];

interface NavigationProps {
  language: Language;
  activeTab: Tab;
  activeSubView: SubView | null;
  onNavigate: (target: NavTarget) => void;
}

const isSelected = (item: NavTarget, activeTab: Tab, activeSubView: SubView | null) =>
  item.isSub ? activeSubView === item.id : activeTab === item.id && activeSubView === null;

interface SidebarProps extends NavigationProps {
  hotelName: string;
  cityName: string;
  logoUrl: string;
  eventsEnabled: boolean;
  aiEnabled: boolean;
  languages: Language[];
  languageMenuOpen: boolean;
  onToggleLanguageMenu: () => void;
  onCloseLanguageMenu: () => void;
  onSelectLanguage: (language: Language) => void;
  languageMenuRef: RefObject<HTMLDivElement | null>;
}

export function DesktopSidebar(props: SidebarProps) {
  const { language, activeTab, activeSubView, onNavigate } = props;
  const quickAccess: NavItem[] = [
    { id: "PLACES", isSub: true, label: ui(language, "Gezilecek Yerler", "Historical Places"), shortLabel: "", icon: Landmark },
    ...(props.eventsEnabled
      ? [{ id: "EVENTS" as const, isSub: true, label: ui(language, "Kültür Takvimi", "Culture Calendar"), shortLabel: "", icon: Calendar }]
      : []),
    ...(props.aiEnabled
      ? [{ id: "AI_GUIDE" as const, isSub: true, label: ui(language, "Yapay Zeka Rehberi", "AI Concierge Guide"), shortLabel: "", icon: Sparkles }]
      : []),
  ];

  return (
    <aside className="hidden shrink-0 flex-col justify-between border-e border-line bg-soft md:flex md:w-64">
      <div className="space-y-6 p-5">
        <div className="flex items-center gap-3 border-b border-line pb-4">
          <HotelLogo src={props.logoUrl} alt={props.hotelName} frameClassName="h-16 w-11 rounded-xl p-1" />
          <div className="min-w-0 text-start">
            <h1 className="font-serif text-sm font-bold uppercase leading-tight tracking-widest text-brand-ink">
              {props.hotelName}
            </h1>
            <span className="block text-[8px] font-bold uppercase tracking-widest text-[#999999]">
              {ui(language, "{city} Ziyaretçi Rehberi", "{city} Visitor Guide", { city: props.cityName })}
            </span>
          </div>
        </div>

        <LanguageMenu
          language={language}
          languages={props.languages}
          open={props.languageMenuOpen}
          onToggle={props.onToggleLanguageMenu}
          onClose={props.onCloseLanguageMenu}
          onSelect={props.onSelectLanguage}
          containerRef={props.languageMenuRef}
        />

        <nav className="space-y-1 text-start" aria-label={ui(language, "Ana menü", "Main menu")}>
          {mainItems(language).map((item) => {
            const Icon = item.icon;
            const selected = isSelected(item, activeTab, activeSubView);
            return (
              <button
                type="button"
                key={item.id}
                onClick={() => onNavigate(item)}
                aria-current={selected ? "page" : undefined}
                className={`flex w-full items-center gap-3.5 rounded-xl px-3.5 py-3 text-xs font-bold tracking-wide transition-all ${
                  selected ? "border-s-4 border-accent bg-brand text-white" : "text-ink hover:bg-line/55"
                }`}
              >
                <Icon className={`h-4 w-4 ${selected ? "text-accent" : "text-brand-ink"}`} />
                <span>{item.label}</span>
              </button>
            );
          })}

          <div className="my-3 border-t border-line" />
          <span className="mb-1.5 block px-3 text-[9px] font-bold uppercase tracking-widest text-[#999999]">
            {ui(language, "HIZLI ERİŞİM", "QUICK ACCESS")}
          </span>
          {quickAccess.map((item) => {
            const Icon = item.icon;
            const selected = activeSubView === item.id;
            return (
              <button
                type="button"
                key={item.id}
                onClick={() => onNavigate(item)}
                aria-current={selected ? "page" : undefined}
                className={`flex w-full items-center gap-3.5 rounded-xl px-3.5 py-2.5 text-[11px] font-semibold transition-all ${
                  selected ? "bg-accent text-ink" : "text-ink hover:bg-line/40"
                }`}
              >
                <Icon className="h-3.5 w-3.5 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="space-y-1 border-t border-line p-4 text-[10px] font-medium tracking-wide text-[#999999]">
        <div>© {new Date().getFullYear()} {props.hotelName}</div>
        <div className="flex items-center gap-1.5">
          <img src="/irismap.svg" alt="" aria-hidden="true" className="h-3.5 w-3.5" />
          <span>{ui(language, "IrisMap ile hazırlandı", "Powered by IrisMap")}</span>
        </div>
      </div>
    </aside>
  );
}

export function MobileNavigation({ language, activeTab, activeSubView, onNavigate }: NavigationProps) {
  return (
    <nav
      aria-label={ui(language, "Ana menü", "Main menu")}
      className="fixed inset-x-0 bottom-0 z-50 flex h-[calc(70px+env(safe-area-inset-bottom))] items-start justify-around border-t border-line bg-soft px-2 pt-1 pb-[env(safe-area-inset-bottom)] shadow-2xl md:hidden"
    >
      {mainItems(language).map((item) => {
        const Icon = item.icon;
        const selected = isSelected(item, activeTab, activeSubView);
        return (
          <button
            type="button"
            key={item.id}
            onClick={() => onNavigate(item)}
            aria-current={selected ? "page" : undefined}
            className={`flex min-h-[62px] min-w-[55px] flex-col items-center justify-center gap-1 py-1 transition-all ${
              selected ? "text-brand-ink" : "text-[#8A8A8A]"
            }`}
          >
            <Icon className={`h-5 w-5 ${selected ? "text-brand-ink" : "text-[#8A8A8A]"}`} />
            <span className="max-w-[68px] truncate text-[8px] font-bold uppercase tracking-wider">{item.shortLabel}</span>
            <span className={`h-0.5 w-4 rounded-full ${selected ? "bg-brand" : "bg-transparent"}`} />
          </button>
        );
      })}
    </nav>
  );
}
