import React, { type ErrorInfo, type ReactNode } from "react";
import { ui } from "../i18n";
import { isLanguage } from "../../shared/languages";
import type { Language } from "../types";
import { readString } from "../utils/storage";

interface Props {
  children: ReactNode;
  /** Shown instead of the full-page message, for errors inside one section. */
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
}

const storedLanguage = (): Language => {
  const value = readString("lang");
  return isLanguage(value) ? value : "TR";
};

export function FullPageError({ language, onReload }: { language: Language; onReload: () => void }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-soft p-5 text-ink">
      <section className="w-full max-w-md rounded-3xl border border-accent/40 bg-card p-6 text-center shadow-xl">
        <img src="/irismap.svg" alt="IrisMap" className="mx-auto h-16 w-16 object-contain" />
        <h1 className="mt-4 font-serif text-xl font-bold text-brand-ink">
          {ui(language, "Rehber geçici olarak görüntülenemiyor", "The guide is temporarily unavailable")}
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-[#666666]">
          {ui(language, "Bilgileriniz kaybolmadı. Sayfayı yenileyerek tekrar deneyebilirsiniz.", "Your saved information is safe. Reload the page to try again.")}
        </p>
        <button
          type="button"
          onClick={onReload}
          className="mt-5 min-h-11 w-full rounded-xl bg-brand px-4 py-3 text-sm font-bold text-white"
        >
          {ui(language, "Sayfayı Yenile", "Reload Page")}
        </button>
      </section>
    </main>
  );
}

export default class AppErrorBoundary extends React.Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("IrisMap rendering error", error, info.componentStack);
  }

  render() {
    if (!this.state.hasError) return this.props.children;
    if (this.props.fallback !== undefined) return this.props.fallback;
    return <FullPageError language={storedLanguage()} onReload={() => window.location.reload()} />;
  }
}
