import { useEffect, useMemo, useRef, useState, type SyntheticEvent } from "react";
import { isRtlLanguage, localeForLanguage, ui } from "../i18n";
import { categoryLabel, photoCaption, placeHistory, placeName, placeSummary } from "../i18n/content";
import { visitDuration, visitHours, visitNote } from "../i18n/visit";
import type { Place, Language, PhotoItem } from "../types";
import { showToast } from "../utils/toast";
import PlacePhoto, { getPlaceStructuredPhotos } from "./PlacePhoto";
import visitDataJson from "../visit-data.json";
import { 
  X, Heart, Volume2, Share2, MapPin, Navigation, 
  Accessibility, Globe, Phone, Sparkles, ShieldCheck, 
  CheckCircle, ArrowLeft, HeartOff, Info, ChevronLeft, ChevronRight, Camera,
  CalendarClock, Route, CircleHelp
} from "lucide-react";

interface PlaceDetailProps {
  place: Place;
  language: Language;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
  hotelName: string;
  onShowOnMap: (place: Place) => void;
  places?: Place[];
  onSelectPlace?: (place: Place) => void;
}

interface VisitData {
  hours: string;
  hoursNote: string;
  fee: string;
  durationMin: number | null;
  durationMax: number | null;
  visitNote: string;
  source: string | null;
}

const VISIT_DATA = visitDataJson as Record<string, VisitData>;

export default function PlaceDetail({
  place,
  language,
  onClose,
  isFavorite,
  onToggleFavorite,
  hotelName,
  onShowOnMap,
  places = [],
  onSelectPlace,
}: PlaceDetailProps) {
  const rtl = isRtlLanguage(language);
  const [activePhotoIndex, setActivePhotoIndex] = useState(0);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [fullscreenIndex, setFullscreenIndex] = useState<number | null>(null);
  const touchStartXRef = useRef<number | null>(null);
  const visitData = VISIT_DATA[String(place.id)];

  useEffect(() => {
    setActivePhotoIndex(0);
    setFullscreenIndex(null);
    return () => {
      if ("speechSynthesis" in window) window.speechSynthesis.cancel();
      setIsSpeaking(false);
    };
  }, [place.id]);

  useEffect(() => {
    if (fullscreenIndex === null) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setFullscreenIndex(null);
      const forward = rtl ? "ArrowLeft" : "ArrowRight";
      const backward = rtl ? "ArrowRight" : "ArrowLeft";
      if (event.key === forward) setFullscreenIndex((index) => (index === null ? index : Math.min(index + 1, structuredPhotosLength.current - 1)));
      if (event.key === backward) setFullscreenIndex((index) => (index === null ? index : Math.max(index - 1, 0)));
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [fullscreenIndex, rtl]);

  const localPhotos = useMemo(() => getPlaceStructuredPhotos(place), [place]);
  const [commonsPhotos, setCommonsPhotos] = useState<PhotoItem[]>([]);
  const [isGalleryLoading, setIsGalleryLoading] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    setCommonsPhotos([]);
    setIsGalleryLoading(true);

    fetch(`/api/commons-photos?place=${encodeURIComponent(place.isim_tr)}&english=${encodeURIComponent(place.isim_en)}&limit=8`, {
      signal: controller.signal
    })
      .then((response) => response.ok ? response.json() : Promise.reject(new Error("Gallery service unavailable")))
      .then((data) => setCommonsPhotos(Array.isArray(data.photos) ? data.photos : []))
      .catch((error) => {
        if (error.name !== "AbortError") console.warn("Additional gallery photos could not be loaded:", error);
      })
      .finally(() => {
        if (!controller.signal.aborted) setIsGalleryLoading(false);
      });

    return () => controller.abort();
  }, [place.id, place.isim_tr, place.isim_en]);

  // Photos that could not be loaded (even from their fallback address) leave the gallery.
  const [failedPhotos, setFailedPhotos] = useState<string[]>([]);
  useEffect(() => setFailedPhotos([]), [place.id]);
  const handlePhotoError = (event: SyntheticEvent<HTMLImageElement>, photo: PhotoItem) => {
    const image = event.currentTarget;
    if (photo.fallbackUrl && image.dataset.fallback !== "1") {
      image.dataset.fallback = "1";
      image.src = photo.fallbackUrl;
      return;
    }
    setFailedPhotos((current) => (current.includes(photo.url) ? current : [...current, photo.url]));
  };

  const structuredPhotos = useMemo(() => {
    const seen = new Set<string>();
    return [...localPhotos, ...commonsPhotos].filter((photo) => {
      const normalized = photo.url.split("?")[0].toLocaleLowerCase();
      if (seen.has(normalized) || failedPhotos.includes(photo.url)) return false;
      seen.add(normalized);
      return true;
    });
  }, [localPhotos, commonsPhotos, failedPhotos]);

  const nearbyPlaces = useMemo(() => {
    const toRadians = (value: number) => value * Math.PI / 180;
    const distanceBetween = (candidate: Place) => {
      const earthRadiusKm = 6371;
      const latDelta = toRadians(candidate.koordinatlar.lat - place.koordinatlar.lat);
      const lngDelta = toRadians(candidate.koordinatlar.lng - place.koordinatlar.lng);
      const startLat = toRadians(place.koordinatlar.lat);
      const endLat = toRadians(candidate.koordinatlar.lat);
      const a = Math.sin(latDelta / 2) ** 2
        + Math.cos(startLat) * Math.cos(endLat) * Math.sin(lngDelta / 2) ** 2;
      return earthRadiusKm * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };

    return places
      .filter((candidate) => candidate.id !== place.id)
      .map((candidate) => ({ place: candidate, distanceKm: distanceBetween(candidate) }))
      .sort((a, b) => a.distanceKm - b.distanceKm)
      .slice(0, 4);
  }, [place, places]);

  const structuredPhotosLength = useRef(0);
  structuredPhotosLength.current = structuredPhotos.length;

  useEffect(() => {
    if (activePhotoIndex >= structuredPhotos.length) setActivePhotoIndex(0);
  }, [activePhotoIndex, structuredPhotos.length]);

  const getName = () => placeName(place, language);

  const getDesc = () => {
    return placeHistory(place, language);
  };

  const getShortDescription = () => {
    return placeSummary(place, language);
  };

  const getVisitingHours = () => {
    const raw = visitData?.hours || Object.values(place.calisma_saatleri)[0];
    return visitHours(raw, language);
  };

  const getVisitDuration = () =>
    visitDuration(visitData?.durationMin, visitData?.durationMax, place.ziyaret_suresi_dk, language);

  // Text-To-Speech function using Web Speech API
  const handleSpeak = () => {
    if ("speechSynthesis" in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }

      const textToSpeak = `${getName()}. ${getDesc()}`;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);

      // Attempt to pick an appropriate language voice
      utterance.lang = localeForLanguage[language];

      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    } else {
      showToast(ui(language, "Sesli anlatım bu tarayıcıda desteklenmiyor.", "Text-to-speech is not supported in this browser."));
    }
  };

  const getDirections = () => {
    const url = new URL("https://www.google.com/maps/dir/");
    url.searchParams.set("api", "1");
    url.searchParams.set("destination", `${place.koordinatlar.lat},${place.koordinatlar.lng}`);
    url.searchParams.set("travelmode", "walking");
    window.open(url.toString(), "_blank", "noopener,noreferrer");
  };

  // Share a link that opens this place directly.
  const handleShare = async () => {
    const url = `${window.location.origin}/?place=${place.id}`;
    const title = `${getName()} · ${hotelName}`;
    if (typeof navigator.share === "function") {
      try {
        await navigator.share({ title, text: title, url });
        return;
      } catch (error) {
        if ((error as DOMException)?.name === "AbortError") return;
      }
    }
    try {
      await navigator.clipboard.writeText(`${title}: ${url}`);
      showToast(ui(language, "Paylaşım bağlantısı panoya kopyalandı!", "Share link copied to the clipboard!"), 2500);
    } catch {
      showToast(ui(language, "Bağlantı kopyalanamadı.", "The link could not be copied."));
    }
  };

  return (
    <div id="place-detail-modal" className={`flex flex-col h-full rounded-2xl border overflow-hidden shadow-2xl transition-all bg-card text-ink border-line`}>
      {/* Photo Gallery & Hero */}
      <div className="relative w-full md:max-w-[600px] md:mx-auto bg-line overflow-hidden rounded-t-2xl">
        <PlacePhoto
          place={place}
          photos={structuredPhotos}
          photoIndex={activePhotoIndex}
          alt={getName()}
          language={language}
          className="w-full h-[220px] md:h-[320px] object-cover opacity-95 transition-all duration-500"
        />
        {/* Soft elegant shadow overlay (no pure black) */}
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-800/80 via-transparent to-neutral-800/30" />

        {/* Buttons on top of image */}
        <div className="absolute inset-x-4 top-4 z-10 flex items-center justify-between">
          <button
            onClick={onClose}
            aria-label={ui(language, "Geri dön", "Go back")}
            className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-neutral-800/45 text-white backdrop-blur-sm transition-all hover:bg-brand cursor-pointer"
          >
            <ArrowLeft className={`h-4.5 w-4.5 ${rtl ? "rotate-180" : ""}`} />
          </button>
          
          <div className="flex gap-2">
            <button
              onClick={() => onToggleFavorite(place.id)}
              aria-label={isFavorite ? ui(language, "Favorilerden çıkar", "Remove from favorites") : ui(language, "Favorilere ekle", "Add to favorites")}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-neutral-800/45 text-white backdrop-blur-sm transition-all hover:bg-brand cursor-pointer"
            >
              {isFavorite ? (
                <Heart className="w-4.5 h-4.5 fill-white text-white" />
              ) : (
                <HeartOff className="w-4.5 h-4.5 text-gray-200" />
              )}
            </button>
            <button
              onClick={() => void handleShare()}
              aria-label={ui(language, "Paylaş", "Share")}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-neutral-800/45 text-white backdrop-blur-sm transition-all hover:bg-brand cursor-pointer"
            >
              <Share2 className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Place Title in Hero */}
        <div className="absolute inset-x-4 bottom-4 text-start">
          <span className="bg-brand text-white text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md border border-accent/20">
            {categoryLabel(place.kategori, language)}
          </span>
          <h2 className="font-serif font-bold text-lg md:text-2xl text-white mt-2 drop-shadow-md leading-tight">
            {getName()}
          </h2>
          {language !== "TR" && getName() !== place.isim_tr && (
            <p className="mt-1 text-[10px] font-medium text-white/80">
              {ui(language, "Resmî Türkçe adı", "Official Turkish name")}: {place.isim_tr}
            </p>
          )}
        </div>

        {/* Multi-Photo Dots selection */}
        {structuredPhotos.length > 1 && (
          <div className="absolute bottom-0 end-2 z-10 flex">
            {structuredPhotos.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActivePhotoIndex(idx)}
                className="flex h-11 w-11 items-center justify-center rounded-full"
                aria-label={`${ui(language, "Galeri fotoğrafı", "Gallery photo")} ${idx + 1}`}
              >
                <span className={`h-2 w-2 rounded-full border border-white/40 transition-all ${
                  activePhotoIndex === idx ? "scale-125 bg-accent" : "bg-white/40"
                }`} />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Detail Content Section */}
      <div className="flex-1 space-y-6 overflow-y-auto p-4 text-start md:p-6">
        {/* Quick Action bar */}
        <div className={`flex flex-col sm:flex-row gap-3 pb-4 border-b border-line`}>
          <button
            onClick={() => onShowOnMap(place)}
            className="flex min-h-11 flex-1 items-center justify-center gap-2 rounded-xl border border-accent/20 bg-brand px-4 py-3 text-xs font-bold uppercase tracking-wider text-white shadow-sm transition-all hover:bg-opacity-95 cursor-pointer"
          >
            <MapPin className="w-4 h-4 text-accent" />
            {ui(language, "Uygulama Haritasında Gör", "View on App Map")}
          </button>

          <button
            onClick={getDirections}
            className={`flex min-h-11 items-center justify-center gap-2 rounded-xl border px-4 py-3 text-xs font-bold transition-all cursor-pointer bg-card text-brand-ink border-accent`}
          >
            <Navigation className="w-4 h-4" />
            {ui(language, "Google Haritalar ile Git", "Go with Google Maps")}
          </button>

          <button
            onClick={handleSpeak}
            className={`flex min-h-11 items-center justify-center gap-2 rounded-xl border px-4 py-3 text-xs font-bold transition-all cursor-pointer ${
              isSpeaking 
                ? "bg-accent border-accent text-white" 
                : "bg-card hover:bg-gray-50 text-ink border-line"
            }`}
          >
            <Volume2 className={`w-4 h-4 ${isSpeaking ? "animate-pulse text-white" : "text-accent"}`} />
            {isSpeaking 
              ? ui(language, "Durdur", "Stop")
              : ui(language, "Sesli Dinle", "Listen")}
          </button>
        </div>

        {/* Short, guest-friendly introduction */}
        <div className={`rounded-xl border p-4 flex items-start gap-3 bg-brand/5 border-brand/10`}>
          <div className="w-8 h-8 rounded-lg bg-brand text-white flex items-center justify-center shrink-0 shadow-sm">
            <Info className="w-4 h-4" />
          </div>
          <div className="space-y-1">
            <h3 className="text-[10px] font-bold uppercase tracking-widest text-brand-ink">
              {ui(language, "Kısaca", "At a Glance")}
            </h3>
            <p className={`text-xs md:text-sm leading-relaxed font-semibold text-ink`}>
              {getShortDescription()}
            </p>
          </div>
        </div>

        {/* History / Description */}
        <div className="space-y-2.5">
          <h3 className="font-serif font-bold text-sm text-brand-ink tracking-wider uppercase flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-accent" />
            {ui(language, "TARİHÇE VE KÜLTÜR", "HISTORY & HERITAGE")}
          </h3>
          <p className={`text-xs md:text-sm leading-relaxed font-sans font-medium text-ink`}>
            {getDesc()}
          </p>
        </div>

        {/* Compact visit summary */}
        <div className={`flex flex-col gap-3 rounded-xl border p-4 shadow-sm sm:flex-row sm:items-center bg-soft border-line`}>
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand text-white shadow-sm">
            <CalendarClock className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <h4 className="text-[10px] font-bold uppercase tracking-wide text-[#999999]">
              {ui(language, "Ziyaret Saatleri", "Visiting Hours")}
            </h4>
            <p className={`mt-1 text-sm font-bold text-ink`}>
              {getVisitingHours()}
            </p>
          </div>
          <div className={`sm:border-s sm:ps-4 border-line`}>
            <span className="block text-[9px] font-bold uppercase tracking-wide text-[#999999]">
              {ui(language, "Önerilen süre", "Suggested time")}
            </span>
            <span className={`mt-1 block whitespace-nowrap text-xs font-bold text-brand-ink`}>
              {getVisitDuration()}
            </span>
          </div>
          <span className={`w-fit rounded-full px-2.5 py-1 text-[9px] font-semibold bg-accent/15 text-[#777777]`}>
            {ui(language, "Önceden teyit edin", "Confirm ahead")}
          </span>
        </div>

        {visitData?.visitNote && (
          <div className={`flex items-start gap-2.5 rounded-xl border px-4 py-3 border-accent/20 bg-accent/8`}>
            <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
            <div>
              <span className="text-[9px] font-bold uppercase tracking-widest text-brand-ink">{ui(language, "Ziyaret Notu", "Visit note")}</span>
              <p className={`mt-1 text-[11px] leading-relaxed text-[#666666]`}>
                {visitNote(visitData.visitNote, language)}
              </p>
            </div>
          </div>
        )}

        {/* Accessibility Features */}
        <div className={`border p-4 rounded-xl space-y-2.5 bg-soft border-line`}>
          <h4 className="text-xs font-serif font-bold text-brand-ink tracking-wide flex items-center gap-1.5">
            <Accessibility className="w-4 h-4 text-accent" />
            {ui(language, "Erişilebilirlik Olanakları", "Accessibility Features")}
          </h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            {[
              { available: place.erisilebilirlik.wheelchair, label: ui(language, "Tekerlekli Sandalye", "Wheelchair access") },
              { available: place.erisilebilirlik.elevator, label: ui(language, "Asansör / Rampa", "Elevator / Ramp") },
              { available: place.erisilebilirlik.disabledToilet, label: ui(language, "Erişilebilir Tuvalet", "Accessible restroom") },
              { available: place.erisilebilirlik.guideService, label: ui(language, "Rehber Hizmeti", "Guide service") },
            ].map((item) => {
              const StatusIcon = item.available ? CheckCircle : CircleHelp;
              return (
                <div key={item.label} className="flex items-start gap-1.5">
                  <StatusIcon className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${item.available ? "text-green-600" : "text-accent"}`} />
                  <span className={item.available ? "text-ink font-bold" : "text-[#777777] font-medium"}>
                    {item.label}
                    {!item.available && (
                      <span className="block text-[9px] font-normal text-[#999999]">
                        {ui(language, "Ziyaret öncesi teyit edin", "Confirm before visiting")}
                      </span>
                    )}
                  </span>
                </div>
              );
            })}
          </div>
          <div className={`mt-3 pt-2.5 border-t flex items-start gap-2 text-[10px] font-medium leading-relaxed border-line text-gray-500`}>
            <Info className="w-3.5 h-3.5 text-accent shrink-0 mt-0.5" />
            <p>
              {ui(language, "Not: Tarihî ve dini yapıların mimari özellikleri nedeniyle basamaksız erişim sınırlı olabilir veya talep üzerine sağlanabilir. Ziyaret öncesinde ilgili kurumdan teyit alın.", "Note: Step-free access may be limited at historic and religious sites or available on request. Please confirm with the venue before visiting.")}
            </p>
          </div>
        </div>

        {/* Contact and Location details */}
        <div className={`border p-4 rounded-xl space-y-3 text-xs font-medium bg-soft border-line text-ink`}>
          <div className="flex items-start gap-2">
            <MapPin className="w-4 h-4 text-accent shrink-0 mt-0.5" />
            <span>{place.adres}</span>
          </div>
          {place.telefon && (
            <div className="flex items-center gap-2">
              <Phone className="w-4 h-4 text-accent shrink-0" />
              <a href={`tel:${place.telefon}`} className="flex min-h-11 items-center transition-colors hover:text-brand-ink">{place.telefon}</a>
            </div>
          )}
          {place.web && (
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-accent shrink-0" />
              <a href={place.web} target="_blank" rel="noopener noreferrer" className="flex min-h-11 items-center break-all transition-colors hover:text-brand-ink">
                {place.web}
              </a>
            </div>
          )}
        </div>

        {/* Culture etiquette is shown before the gallery */}
        {(place.kategori === "UNESCO" || place.kategori === "Cami") && (
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex gap-2.5">
            <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-800 font-bold">
              {ui(language, "Dini ve mukaddes mekânları ziyaret ederken omuzların ve dizlerin kapalı olmasına ve cami girişlerinde ayakkabıların çıkarılmasına özen gösteriniz.", "When visiting holy sites, cover shoulders and knees and remove shoes at mosque entrances.")}
            </p>
          </div>
        )}

        {/* Photo Gallery (Horizontal Scroll) or Elegant Placeholder */}
        {structuredPhotos.length > 0 ? (
          <div className="space-y-2.5">
            <h4 className="text-xs font-serif font-bold text-brand-ink tracking-wide uppercase">
              {ui(language, "Fotoğraf Galerisi", "Photo Gallery")}
            </h4>
            {isGalleryLoading && (
              <p className="text-[10px] text-[#999999]">
                {ui(language, "Arşiv fotoğrafları yükleniyor…", "Loading archive photos…")}
              </p>
            )}
            <div 
              className="w-full overflow-x-auto flex gap-3 pb-2 select-none touch-pan-x"
              style={{ WebkitOverflowScrolling: "touch" }}
            >
              {structuredPhotos.map((item, idx) => (
                <button
                  type="button"
                  key={item.url}
                  onClick={() => setFullscreenIndex(idx)}
                  className="group flex w-[200px] flex-shrink-0 flex-col space-y-1.5 text-start"
                >
                  <div className={`w-[200px] h-[200px] rounded-[12px] overflow-hidden border relative shadow-sm group-hover:shadow-md transition-shadow border-line bg-line`}>
                    <img
                      src={item.url}
                      alt={photoCaption(item, language)}
                      referrerPolicy="no-referrer"
                      onError={(event) => handlePhotoError(event, item)}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      loading="lazy"
                    />
                  </div>
                  <span className={`block truncate px-1 text-start text-[10px] font-medium text-ink/80`}>
                    {photoCaption(item, language)}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-2.5">
            <h4 className="text-xs font-serif font-bold text-brand-ink tracking-wide uppercase">
              {ui(language, "Fotoğraf Galerisi", "Photo Gallery")}
            </h4>
            <div className={`border rounded-xl p-6 text-center flex flex-col items-center justify-center space-y-2 bg-soft border-line`}>
              <Camera className="w-6 h-6 text-accent opacity-80" />
              <p className={`text-xs font-bold text-ink/70`}>
                {ui(language, "Arşiv fotoğrafları henüz bulunmuyor", "Archive photos are not available yet")}
              </p>
              <p className="text-[10px] text-gray-400 font-sans max-w-[280px]">
                {ui(language, "Bu mekân için doğrulanmış görsel bulunamadı. Uygun kaynak doğrulandığında galeriye eklenecektir.", "No verified image is available for this place. It will be added when a suitable source is verified.")}
              </p>
            </div>
          </div>
        )}

        {nearbyPlaces.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-end justify-between gap-3">
              <div>
                <h4 className="flex items-center gap-2 text-xs font-serif font-bold text-brand-ink tracking-wide uppercase">
                  <Route className="h-4 w-4 text-accent" />
                  {ui(language, "Yakındaki Mekânlar", "Nearby Places")}
                </h4>
                <p className="mt-1 text-[10px] text-[#999999]">
                  {ui(language, "Bu durağa en yakın öneriler", "Closest recommendations to this stop")}
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {nearbyPlaces.map(({ place: nearby, distanceKm }) => (
                <button
                  key={nearby.id}
                  type="button"
                  onClick={() => onSelectPlace?.(nearby)}
                  className={`group flex min-w-0 items-center gap-3 rounded-xl border p-2.5 text-start transition-all border-line bg-soft hover:border-accent hover:bg-card`}
                >
                  <PlacePhoto
                    place={nearby}
                    alt={placeName(nearby, language)}
                    language={language}
                    compact
                    className="h-16 w-20 shrink-0 rounded-lg object-cover"
                  />
                  <span className="min-w-0">
                    <span className={`block truncate text-xs font-bold text-ink`}>
                      {placeName(nearby, language)}
                    </span>
                    <span className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-brand-ink">
                      <MapPin className="h-3 w-3" />
                      {distanceKm < 1 ? `${Math.round(distanceKm * 1000)} m` : `${distanceKm.toFixed(1)} km`}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* Full-Screen Photo Viewer Overlay */}
      {fullscreenIndex !== null && structuredPhotos[fullscreenIndex] && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={ui(language, "Fotoğraf Galerisi", "Photo Gallery")}
          className="fixed inset-0 bg-black/95 z-50 flex flex-col justify-between p-4 md:p-6 select-none animate-fade-in"
          onTouchStart={(e) => {
            touchStartXRef.current = e.touches[0].clientX;
          }}
          onTouchEnd={(e) => {
            const touchStartX = touchStartXRef.current ?? e.changedTouches[0].clientX;
            const diffX = e.changedTouches[0].clientX - touchStartX;
            touchStartXRef.current = null;
            const towardsPrevious = rtl ? diffX < -50 : diffX > 50;
            const towardsNext = rtl ? diffX > 50 : diffX < -50;
            if (towardsPrevious && fullscreenIndex > 0) {
              setFullscreenIndex(fullscreenIndex - 1);
            } else if (towardsNext && fullscreenIndex < structuredPhotos.length - 1) {
              setFullscreenIndex(fullscreenIndex + 1);
            }
          }}
        >
          {/* Top Bar with counter & close button */}
          <div className="flex justify-between items-center text-white w-full max-w-4xl mx-auto">
            <span className="text-[10px] font-mono font-bold tracking-widest uppercase text-white/70">
              {fullscreenIndex + 1} / {structuredPhotos.length}
            </span>
            <button
              type="button"
              onClick={() => setFullscreenIndex(null)}
              aria-label={ui(language, "Kapat", "Close")}
              className="flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-white/10 text-white transition-all hover:bg-white/20"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Centered Image with touch swipe & Zoom indicators */}
          <div className="flex-1 flex items-center justify-center relative w-full max-w-4xl mx-auto">
            {/* Previous Photo Button */}
            {fullscreenIndex > 0 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFullscreenIndex(fullscreenIndex - 1);
                }}
                className="absolute start-2 z-10 rounded-full border border-white/10 bg-black/50 p-3 text-white transition-all hover:bg-black/80 cursor-pointer md:start-4"
                aria-label={ui(language, "Önceki fotoğraf", "Previous photo")}
              >
              <ChevronLeft className={`h-5 w-5 ${rtl ? "rotate-180" : ""}`} />
              </button>
            )}

            {/* Centered Img container */}
            <div className="max-w-full max-h-[70vh] flex items-center justify-center overflow-hidden rounded-lg shadow-2xl">
              <img
                key={structuredPhotos[fullscreenIndex].url}
                src={structuredPhotos[fullscreenIndex].url}
                alt={getName()}
                referrerPolicy="no-referrer"
                onError={(event) => handlePhotoError(event, structuredPhotos[fullscreenIndex])}
                className="max-w-full max-h-[70vh] object-contain transition-transform duration-300 hover:scale-105 active:scale-125 cursor-zoom-in"
              />
            </div>

            {/* Next Photo Button */}
            {fullscreenIndex < structuredPhotos.length - 1 && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setFullscreenIndex(fullscreenIndex + 1);
                }}
                className="absolute end-2 z-10 rounded-full border border-white/10 bg-black/50 p-3 text-white transition-all hover:bg-black/80 cursor-pointer md:end-4"
                aria-label={ui(language, "Sonraki fotoğraf", "Next photo")}
              >
              <ChevronRight className={`h-5 w-5 ${rtl ? "rotate-180" : ""}`} />
              </button>
            )}
          </div>

          {/* Bottom details with a guest-friendly caption and source */}
          <div className="bg-black/60 backdrop-blur-md border border-white/10 rounded-2xl p-4 text-center w-full max-w-2xl mx-auto space-y-1.5 mb-2 shadow-lg">
            <p className="text-xs font-bold text-white leading-normal">
              {photoCaption(structuredPhotos[fullscreenIndex], language)}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 text-[10px] text-gray-400 font-mono font-medium">
              {structuredPhotos[fullscreenIndex].sourceUrl ? (
                <a
                  href={structuredPhotos[fullscreenIndex].sourceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline underline-offset-2 hover:text-white"
                >
                  {ui(language, "Kaynak", "Source")}: {structuredPhotos[fullscreenIndex].source}
                </a>
              ) : (
                <span>{ui(language, "Kaynak", "Source")}: {structuredPhotos[fullscreenIndex].source}</span>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
