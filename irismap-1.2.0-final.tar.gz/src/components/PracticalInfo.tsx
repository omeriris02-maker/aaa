import { PRACTICAL_INFO } from "../data";
import type { Language } from "../types";
import type { HotelConfig } from "../../shared/hotelConfig";
import { pickText } from "../../shared/languages";
import { ui } from "../i18n";
import { Phone, ShieldAlert, Sparkles, Lightbulb, HeartHandshake } from "lucide-react";

interface PracticalInfoProps {
  language: Language;
  hotel: HotelConfig;
  hotelName: string;
}

interface ContactRow {
  label: string;
  display: string;
  dial: string;
}

export default function PracticalInfo({ language, hotel, hotelName }: PracticalInfoProps) {
  const currentData = PRACTICAL_INFO[language] || PRACTICAL_INFO.EN;
  const contacts: ContactRow[] = [
    ...currentData.emergency.map((item) => ({ label: item.ad, display: item.no, dial: item.no.replace(/[^\d+]/g, "") })),
    ...(hotel.contact.phone
      ? [{ label: ui(language, "{hotel} Resepsiyon", "{hotel} Reception", { hotel: hotelName }), display: hotel.contact.phone.display, dial: hotel.contact.phone.dial }]
      : []),
    ...(hotel.contact.whatsapp
      ? [{ label: ui(language, "{hotel} Resepsiyon (WhatsApp)", "{hotel} Reception (WhatsApp)", { hotel: hotelName }), display: hotel.contact.whatsapp.display, dial: hotel.contact.whatsapp.dial }]
      : []),
    ...hotel.emergencyContacts.map((item) => ({
      label: pickText(item.label, language, hotel.defaultLanguage),
      display: item.phone.display,
      dial: item.phone.dial,
    })),
  ];

  return (
    <div className="space-y-6 text-start">
      {/* Header */}
      <div className={`flex items-center gap-2 border-b pb-3 border-line`}>
        <HeartHandshake className="w-5 h-5 text-brand-ink" />
        <h2 className={`font-serif font-bold text-lg md:text-xl text-brand-ink`}>
          {ui(language, "Pratik Gezi Rehberi", "Practical Guest Guide")}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left: Emergency Numbers */}
        <div className="space-y-4">
          <h3 className={`font-serif font-bold text-sm tracking-wider uppercase flex items-center gap-1.5 border-b pb-2 text-brand-ink border-line`}>
            <Phone className="w-4 h-4 text-accent" />
            {ui(language, "ÖNEMLİ TELEFONLAR", "IMPORTANT CONTACTS")}
          </h3>

          <div className={`border p-4 rounded-2xl space-y-3 shadow-sm bg-soft border-line`}>
            {contacts.map((item, idx) => (
              <div key={idx} className="flex items-center justify-between gap-3 border-b border-line py-1.5 text-xs last:border-0">
                <span className="font-bold text-ink">{item.label}</span>
                <a
                  href={`tel:${item.dial}`}
                  dir="ltr"
                  className="flex min-h-10 shrink-0 items-center font-mono font-bold text-brand-ink hover:text-accent hover:underline"
                >
                  {item.display}
                </a>
              </div>
            ))}
          </div>

          {/* Quick Cultural banner */}
          <div className={`border p-4 rounded-2xl flex gap-3 shadow-sm bg-brand/5 border-brand/20`}>
            <ShieldAlert className="w-5 h-5 text-brand-ink shrink-0" />
            <div className="space-y-1 text-xs">
              <span className="font-bold text-brand-ink">
                {ui(language, "Sağlık ve Güvence", "Safety and Emergency Help")}
              </span>
              <p className={`leading-relaxed font-medium text-ink`}>
                {ui(language, "Acil durumda resepsiyonu arayabilirsiniz. Türkiye’de ambulans, polis ve itfaiye için ortak acil çağrı numarası 112’dir.", "Call reception in an emergency. In Türkiye, 112 is the single emergency number for ambulance, police, and fire services.")}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Cultural Rules and Local tips */}
        <div className="space-y-6">
          {/* Rules */}
          <div className="space-y-3">
            <h3 className={`font-serif font-bold text-sm tracking-wider uppercase flex items-center gap-1.5 border-b pb-2 text-brand-ink border-line`}>
              <Sparkles className="w-4 h-4 text-accent" />
              {ui(language, "KÜLTÜREL ETİKET", "CULTURAL ETIQUETTE")}
            </h3>

            <div className="space-y-2">
              {currentData.rules.map((rule, idx) => (
                <div key={idx} className={`border p-3 rounded-xl flex items-start gap-2 text-xs shadow-sm bg-soft border-line`}>
                  <div className="w-2 h-2 rounded-full bg-accent shrink-0 mt-1.5" />
                  <p className={`leading-relaxed font-medium text-ink`}>{rule}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Local Tips */}
          <div className="space-y-3">
            <h3 className={`font-serif font-bold text-sm tracking-wider uppercase flex items-center gap-1.5 border-b pb-2 text-brand-ink border-line`}>
              <Lightbulb className="w-4 h-4 text-accent" />
              {ui(language, "YEREL İPUÇLARI", "LOCAL TRAVEL TIPS")}
            </h3>

            <div className="space-y-2">
              {currentData.tips.map((tip, idx) => (
                <div key={idx} className={`border p-3 rounded-xl flex items-start gap-2 text-xs shadow-sm bg-soft border-line`}>
                  <div className="w-2 h-2 rounded-full bg-brand shrink-0 mt-1.5" />
                  <p className={`leading-relaxed font-medium text-ink`}>{tip}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Accuracy Disclaimer */}
      <div className={`mt-6 pt-4 border-t text-center text-[10px] text-gray-400 font-medium leading-relaxed border-line`}>
        <p>
          {ui(language, "Bilgilendirme: Ziyaret saatleri, erişilebilirlik ve diğer bilgiler zaman içinde değişebilir. Ziyaret öncesinde güncel bilgileri ilgili kurumdan doğrulamanız önerilir.", "Information: Visiting hours, accessibility, and other details may change. Please confirm current information with the venue before visiting.")}
        </p>
      </div>
    </div>
  );
}
