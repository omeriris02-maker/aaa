import { useState, type FormEvent } from "react";
import { BedDouble, ChevronRight, Compass, Languages, MapPin, Send, Settings, ShieldCheck, Trash2 } from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import { LANGUAGE_LABELS, ui } from "../i18n";
import { trackEvent } from "../services/analytics";
import type { Language } from "../types";
import { createMailtoUrl, createWhatsAppUrl, getStoredRoomNumber, openExternal, saveStoredRoomNumber } from "../utils/guest";
import { showToast } from "../utils/toast";
import HotelLogo from "./HotelLogo";

interface SettingsViewProps {
  hotel: HotelConfig;
  hotelName: string;
  cityName: string;
  tagline: string;
  about: string;
  translate: (text: HotelConfig["links"][number]["label"]) => string;
  logoUrl: string;
  language: Language;
  showAllPlaces: boolean;
  onChangeLanguage: (language: Language) => void;
  onChangeShowAllPlaces: (value: boolean) => void;
  onStartTutorial: () => void;
  onClearDeviceData: () => void;
  onOpenPrivacy: () => void;
}

export default function SettingsView(props: SettingsViewProps) {
  const { hotel, language, hotelName } = props;
  const [roomDraft, setRoomDraft] = useState(getStoredRoomNumber);
  const [feedbackText, setFeedbackText] = useState("");
  const [feedbackEmail, setFeedbackEmail] = useState("");
  const [feedbackOpened, setFeedbackOpened] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);
  const { whatsapp, email } = hotel.contact;

  const saveRoom = (event: FormEvent) => {
    event.preventDefault();
    const saved = saveStoredRoomNumber(roomDraft);
    setRoomDraft(saved);
    showToast(saved
      ? ui(language, "Oda numaranız bu cihaza kaydedildi.", "Your room number is saved on this device.")
      : ui(language, "Oda numarası silindi.", "Room number removed."));
  };

  const sendFeedback = (event: FormEvent) => {
    event.preventDefault();
    const message = feedbackText.trim();
    if (!message) return;
    trackEvent("feedback_start", { language });
    const intro = ui(language, "Merhaba! {hotel} misafir rehberinden geri bildirim gönderiyorum:", "Hello! I am sending feedback from the {hotel} guest guide:", { hotel: hotelName });
    const emailLine = feedbackEmail.trim() ? `\n${ui(language, "E-posta", "E-mail")}: ${feedbackEmail.trim()}` : "";
    const body = `${intro}${emailLine}\n${ui(language, "Mesaj", "Message")}: ${message}`;
    if (whatsapp) {
      openExternal(createWhatsAppUrl(whatsapp.number, body, language));
    } else if (email) {
      openExternal(createMailtoUrl(email, ui(language, "Misafir geri bildirimi", "Guest feedback"), body));
    }
    setFeedbackOpened(true);
  };

  const links = [
    ...(hotel.contact.website ? [{ label: ui(language, "Otel Web Sitesi", "Hotel Website"), url: hotel.contact.website, primary: true }] : []),
    ...hotel.links.map((link) => ({ label: props.translate(link.label), url: link.url, primary: false })),
  ];

  return (
    <div className="max-w-4xl space-y-5 text-start">
      <section className="relative overflow-hidden rounded-3xl border border-accent/25 bg-gradient-to-br from-soft to-accent/15 p-5 md:p-7">
        <div className="absolute -end-8 -top-10 h-36 w-36 rounded-full border-[24px] border-accent/10" />
        <div className="relative max-w-xl">
          <span className="text-[10px] font-bold uppercase tracking-[0.24em] text-accent">
            {hotelName} · {props.cityName}
          </span>
          <h2 className="mt-2 font-serif text-2xl font-bold md:text-3xl">{ui(language, "Rehber ayarlarınız", "Your guide settings")}</h2>
          <p className="mt-2 text-xs leading-relaxed text-[#666666]">
            {ui(language, "Uygulama dilini ve haritada gösterilecek mekân kapsamını seçin. Tercihleriniz bu cihazda saklanır.", "Choose the app language and which places appear on the map. Your preferences are saved on this device.")}
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-[1.08fr_0.92fr]">
        {/* Preferences */}
        <section className="rounded-2xl border border-line bg-card p-5 shadow-sm">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand/10">
              <Settings className="h-5 w-5 text-brand-ink" />
            </span>
            <div>
              <h3 className="font-serif text-base font-bold">{ui(language, "Tercihler", "Preferences")}</h3>
              <p className="text-[10px] text-[#888888]">{ui(language, "Seçimleriniz bu cihazda saklanır", "Your choices are saved on this device")}</p>
            </div>
          </div>

          <div className="mt-5 space-y-5">
            {hotel.languages.length > 1 && (
              <div>
                <div className="mb-2 flex items-center gap-2">
                  <Languages className="h-4 w-4 text-accent" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#777777]">{ui(language, "Uygulama dili", "App language")}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {hotel.languages.map((option) => (
                    <button
                      type="button"
                      key={option}
                      lang={option.toLowerCase()}
                      aria-pressed={language === option}
                      onClick={() => props.onChangeLanguage(option)}
                      className={`min-h-11 rounded-xl border px-3 py-3 text-[11px] font-bold transition-all ${
                        language === option ? "border-brand bg-brand text-white shadow-sm" : "border-line bg-soft text-ink hover:border-accent"
                      }`}
                    >
                      {LANGUAGE_LABELS[option]}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between gap-4 rounded-xl border border-line bg-soft p-3">
              <div className="flex min-w-0 items-center gap-3">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand/10">
                  <MapPin className="h-4 w-4 text-brand-ink" />
                </span>
                <span>
                  <span className="block text-[11px] font-bold" id="show-all-label">{ui(language, "Tüm mekânları göster", "Show all places")}</span>
                  <span className="block text-[9px] leading-relaxed text-[#888888]">
                    {ui(language, "Kapalıyken yalnızca otele yakın duraklar görünür.", "When off, only places near the hotel are shown.")}
                  </span>
                </span>
              </div>
              <button
                type="button"
                dir="ltr"
                role="switch"
                aria-checked={props.showAllPlaces}
                aria-labelledby="show-all-label"
                onClick={() => props.onChangeShowAllPlaces(!props.showAllPlaces)}
                className="relative h-11 w-14 shrink-0 rounded-full"
              >
                <span className={`absolute inset-x-1 top-1/2 h-6 -translate-y-1/2 rounded-full transition-colors ${props.showAllPlaces ? "bg-brand" : "bg-[#D8D8D8]"}`} />
                <span className={`absolute left-1.5 top-1/2 h-5 w-5 -translate-y-1/2 rounded-full bg-white shadow-sm transition-transform ${props.showAllPlaces ? "translate-x-6" : "translate-x-0"}`} />
              </button>
            </div>

            {hotel.features.roomNumber && whatsapp && (
              <form onSubmit={saveRoom} className="space-y-2 rounded-xl border border-line bg-soft p-3">
                <label htmlFor="settings-room" className="flex items-center gap-2 text-[11px] font-bold">
                  <BedDouble className="h-4 w-4 text-brand-ink" />
                  {ui(language, "Oda numaranız (isteğe bağlı)", "Your room number (optional)")}
                </label>
                <div className="flex gap-2">
                  <input
                    id="settings-room"
                    value={roomDraft}
                    onChange={(event) => setRoomDraft(event.target.value)}
                    placeholder={ui(language, "Örn. 204", "e.g. 204")}
                    maxLength={12}
                    autoComplete="off"
                    inputMode="text"
                    className="min-h-11 w-full rounded-xl border border-line bg-card px-3 text-base font-bold outline-none focus:border-accent md:text-sm"
                  />
                  <button type="submit" className="min-h-11 shrink-0 rounded-xl bg-brand px-4 text-[11px] font-bold text-white">
                    {ui(language, "Kaydet", "Save")}
                  </button>
                </div>
                <p className="flex items-start gap-1.5 text-[10px] leading-relaxed text-[#888888]">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />
                  {ui(language, "Oda numarası yalnızca bu cihazda saklanır; WhatsApp mesajına siz bağlantıyı açtığınızda eklenir.", "Your room number stays on this device and is added only when you open a WhatsApp message.")}
                </p>
              </form>
            )}

            <button
              type="button"
              onClick={props.onStartTutorial}
              className="flex w-full items-center justify-between gap-3 rounded-xl border border-line bg-card p-3 text-start transition-colors hover:border-accent"
            >
              <span className="flex min-w-0 items-center gap-3">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand/10">
                  <Compass className="h-4 w-4 text-brand-ink" />
                </span>
                <span>
                  <span className="block text-[11px] font-bold">{ui(language, "Kısa başlangıç rehberini göster", "Show quick start guide")}</span>
                  <span className="block text-[9px] text-[#888888]">{ui(language, "Üç adımlı tanıtımı istediğiniz zaman yeniden açın.", "Replay the three-step introduction at any time.")}</span>
                </span>
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-accent rtl:rotate-180" />
            </button>

            <button
              type="button"
              onClick={props.onOpenPrivacy}
              className="flex w-full items-center justify-between gap-3 rounded-xl border border-line bg-card p-3 text-start transition-colors hover:border-accent"
            >
              <span className="flex min-w-0 items-center gap-3">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-brand/10">
                  <ShieldCheck className="h-4 w-4 text-brand-ink" />
                </span>
                <span>
                  <span className="block text-[11px] font-bold">{ui(language, "Gizlilik ve kişisel veriler", "Privacy and personal data")}</span>
                  <span className="block text-[9px] text-[#888888]">{ui(language, "Hangi bilgilerin nasıl kullanıldığını okuyun (KVKK).", "Read what information is used and how (KVKK/GDPR).")}</span>
                </span>
              </span>
              <ChevronRight className="h-4 w-4 shrink-0 text-accent rtl:rotate-180" />
            </button>

            <div className="rounded-xl border border-line bg-card p-3">
              {!confirmClear ? (
                <button type="button" onClick={() => setConfirmClear(true)} className="flex w-full items-center gap-3 text-start">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-red-50">
                    <Trash2 className="h-4 w-4 text-red-600" />
                  </span>
                  <span>
                    <span className="block text-[11px] font-bold">{ui(language, "Bu cihazdaki verilerimi sil", "Delete my data on this device")}</span>
                    <span className="block text-[9px] text-[#888888]">{ui(language, "Favoriler, plan, oda numarası ve tercihler silinir.", "Removes favourites, plan, room number and preferences.")}</span>
                  </span>
                </button>
              ) : (
                <div className="space-y-2" role="alertdialog" aria-label={ui(language, "Bu cihazdaki verilerimi sil", "Delete my data on this device")}>
                  <p className="text-[11px] font-bold">{ui(language, "Tüm kayıtlı bilgileriniz bu cihazdan silinsin mi?", "Delete all your saved information from this device?")}</p>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        setConfirmClear(false);
                        setRoomDraft("");
                        props.onClearDeviceData();
                      }}
                      className="min-h-11 flex-1 rounded-xl bg-red-600 px-3 text-[11px] font-bold text-white"
                    >
                      {ui(language, "Evet, sil", "Yes, delete")}
                    </button>
                    <button type="button" onClick={() => setConfirmClear(false)} className="min-h-11 flex-1 rounded-xl border border-line px-3 text-[11px] font-bold">
                      {ui(language, "Vazgeç", "Cancel")}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Hotel identity */}
        <section className="rounded-2xl border border-accent/25 bg-soft p-5 shadow-sm">
          <div className="flex items-center gap-3 border-b border-accent/15 pb-4">
            <HotelLogo src={props.logoUrl} alt={hotelName} frameClassName="h-16 w-14 rounded-xl p-2" />
            <div>
              <h3 className="font-serif text-base font-bold">{hotelName}</h3>
              {props.tagline && <p className="text-[9px] uppercase tracking-widest text-accent">{props.tagline}</p>}
            </div>
          </div>
          <div className="pt-4 text-xs">
            {props.about && (
              <>
                <h3 className="mb-2 text-[10px] font-bold uppercase tracking-widest text-brand-ink">{ui(language, "Otel hakkında", "About the hotel")}</h3>
                <p className="leading-relaxed">{props.about}</p>
              </>
            )}
            {links.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-4">
                {links.map((link) => (
                  <a
                    key={link.url}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={link.primary
                      ? "flex min-h-11 items-center rounded-lg bg-brand px-3 py-2 text-[10px] font-bold text-white"
                      : "flex min-h-11 items-center rounded-lg border border-accent/40 px-3 py-2 text-[10px] font-bold text-brand-ink"}
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Feedback */}
        {hotel.features.feedback && (whatsapp || email) && (
          <section className="col-span-1 space-y-4 rounded-2xl border border-line bg-soft p-5 shadow-sm md:col-span-2">
            <h3 className="border-b border-accent/10 pb-1 font-serif text-xs font-bold uppercase tracking-widest text-accent">
              {ui(language, "GERİ BİLDİRİM GÖNDERİN", "SHARE YOUR EXPERIENCE / FEEDBACK")}
            </h3>
            <p className="text-[11px] leading-relaxed text-[#777777]">
              {whatsapp
                ? ui(language, "Form, mesajınızı otelin resmî WhatsApp hattında hazırlar. Gönderimi tamamlamak için açılan WhatsApp ekranında Gönder düğmesine basmanız gerekir.", "This form prepares your message in the hotel's official WhatsApp chat. Complete the process by pressing Send in WhatsApp.")
                : ui(language, "Form, mesajınızı e-posta uygulamanızda hazırlar. Gönderimi tamamlamak için e-postayı göndermeniz gerekir.", "This form prepares your message in your e-mail app. Send the e-mail to complete the process.")}
            </p>
            <form onSubmit={sendFeedback} className="space-y-3">
              <div className="space-y-1 text-xs md:max-w-sm">
                <label htmlFor="feedback-email" className="text-[10px] font-bold uppercase text-[#888888]">
                  {ui(language, "E-POSTA ADRESİNİZ (İSTEĞE BAĞLI)", "EMAIL ADDRESS (OPTIONAL)")}
                </label>
                <input
                  id="feedback-email"
                  type="email"
                  autoComplete="email"
                  value={feedbackEmail}
                  onChange={(event) => {
                    setFeedbackEmail(event.target.value);
                    setFeedbackOpened(false);
                  }}
                  placeholder="name@example.com"
                  className="min-h-11 w-full rounded-lg border border-line bg-card p-2.5 text-base text-ink outline-none focus:border-accent md:text-xs"
                />
              </div>
              <div className="space-y-1 text-xs">
                <label htmlFor="feedback-message" className="text-[10px] font-bold uppercase text-[#888888]">
                  {ui(language, "DÜŞÜNCELERİNİZ VEYA TALEPLERİNİZ", "YOUR THOUGHTS OR CONCIERGE REQUESTS")}
                </label>
                <textarea
                  id="feedback-message"
                  rows={3}
                  maxLength={1500}
                  required
                  value={feedbackText}
                  onChange={(event) => {
                    setFeedbackText(event.target.value);
                    setFeedbackOpened(false);
                  }}
                  placeholder={ui(language, "Görüş, öneri veya özel rehberlik talebinizi buraya yazabilirsiniz...", "Write your thoughts, suggestions or specific local tour guide requests here...")}
                  className="w-full resize-none rounded-lg border border-line bg-card p-3 text-base text-ink outline-none focus:border-accent md:text-xs"
                />
              </div>
              <button
                type="submit"
                className="flex min-h-11 items-center justify-center gap-2 rounded-xl border border-accent/30 bg-brand px-5 py-3 text-xs font-bold uppercase tracking-widest text-white shadow-md transition-all hover:opacity-95"
              >
                <Send className="h-3.5 w-3.5 rtl:-scale-x-100" />
                <span>
                  {whatsapp
                    ? ui(language, "WHATSAPP'TA GERİ BİLDİRİM HAZIRLA", "PREPARE FEEDBACK IN WHATSAPP")
                    : ui(language, "E-POSTA İLE GERİ BİLDİRİM HAZIRLA", "PREPARE FEEDBACK BY E-MAIL")}
                </span>
              </button>
              {feedbackOpened && (
                <p className="text-[11px] font-semibold text-[#198F45]" role="status" aria-live="polite">
                  {whatsapp
                    ? ui(language, "WhatsApp görüşmesi açıldı. Mesajınızı WhatsApp üzerinden göndererek işlemi tamamlayabilirsiniz.", "WhatsApp opened. Send the prepared message there to complete your feedback.")
                    : ui(language, "E-posta uygulamanız açıldı. E-postayı göndererek işlemi tamamlayabilirsiniz.", "Your e-mail app opened. Send the e-mail to complete your feedback.")}
                </p>
              )}
            </form>
          </section>
        )}
      </div>
    </div>
  );
}
