import { ExternalLink, Mail, ShieldCheck } from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import { ui } from "../i18n";
import { getPrivacyNotice, mapHostNames } from "../i18n/privacy";
import type { Language } from "../types";

interface PrivacyNoticeProps {
  hotel: HotelConfig;
  hotelName: string;
  language: Language;
}

/** "&copy; OpenStreetMap contributors &copy; CARTO" → "© OpenStreetMap contributors © CARTO" */
function plainAttribution(html: string): string {
  return html
    .replace(/<[^>]*>/g, "")
    .replace(/&copy;/gi, "©")
    .replace(/&amp;/gi, "&")
    .replace(/&nbsp;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Plain-language KVKK / GDPR information for guests. */
export default function PrivacyNotice({ hotel, hotelName, language }: PrivacyNoticeProps) {
  const notice = getPrivacyNotice(language, {
    hotel: hotelName,
    controller: hotel.privacy.controller,
    deleteLabel: ui(language, "Bu cihazdaki verilerimi sil", "Delete my data on this device"),
    mapHosts: mapHostNames(hotel.map.styleUrl ? [hotel.map.styleUrl, ...hotel.map.tileUrls] : hotel.map.tileUrls),
    aiGuide: hotel.features.aiGuide,
    weather: hotel.features.weather,
  });
  const { email, policyUrl } = hotel.privacy;
  const credits = [
    { label: ui(language, "Harita verileri", "Map data"), text: "© OpenStreetMap contributors (ODbL)", url: "https://www.openstreetmap.org/copyright" },
    {
      label: ui(language, "Harita görüntüleri", "Map images"),
      text: !hotel.map.styleUrl
        ? plainAttribution(hotel.map.tileAttribution)
        : hotel.map.styleUrl.includes("openfreemap.org")
          ? `OpenFreeMap · © OpenMapTiles · ${ui(language, "yedek", "fallback")}: ${plainAttribution(hotel.map.tileAttribution)}`
          : mapHostNames([hotel.map.styleUrl]),
      url: null,
    },
    { label: ui(language, "Mekân fotoğrafları", "Place photos"), text: `Wikimedia Commons · ${ui(language, "Her fotoğrafın lisansı fotoğrafla birlikte gösterilir.", "Each photo shows its own licence.")}`, url: "https://commons.wikimedia.org/" },
    ...(hotel.features.weather
      ? [{ label: ui(language, "Hava durumu verileri", "Weather data"), text: "Open-Meteo.com (CC BY 4.0)", url: "https://open-meteo.com/" }]
      : []),
  ];

  return (
    <article className="max-w-3xl space-y-4 text-start" aria-labelledby="privacy-title">
      <header className="rounded-3xl border border-accent/25 bg-gradient-to-br from-soft to-accent/15 p-5 md:p-7">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-brand/10">
          <ShieldCheck className="h-6 w-6 text-brand-ink" aria-hidden="true" />
        </span>
        <h2 id="privacy-title" className="mt-3 font-serif text-2xl font-bold">{notice.title}</h2>
        <p className="mt-2 text-sm leading-relaxed text-[#555555]">{notice.intro}</p>
      </header>

      {notice.sections.map((section) => (
        <section key={section.id} className="rounded-2xl border border-line bg-card p-5 shadow-sm">
          <h3 className="font-serif text-base font-bold text-brand-ink">{section.title}</h3>
          {section.paragraphs.map((paragraph) => (
            <p key={paragraph} className="mt-2 text-[13px] leading-relaxed text-ink">{paragraph}</p>
          ))}
        </section>
      ))}

      <section className="rounded-2xl border border-line bg-card p-5 shadow-sm" aria-labelledby="credits-title">
        <h3 id="credits-title" className="font-serif text-base font-bold text-brand-ink">{ui(language, "Kaynaklar ve lisanslar", "Sources and licences")}</h3>
        <dl className="mt-2 space-y-2 text-[12px] leading-relaxed">
          {credits.map((credit) => (
            <div key={credit.label}>
              <dt className="font-bold">{credit.label}</dt>
              <dd>
                {credit.url
                  ? <a href={credit.url} target="_blank" rel="noopener noreferrer" className="underline decoration-accent/60 underline-offset-2"><bdi>{credit.text}</bdi></a>
                  : <bdi>{credit.text}</bdi>}
              </dd>
            </div>
          ))}
        </dl>
        <a href="/third-party-licenses.txt" target="_blank" rel="noopener" className="mt-3 inline-flex min-h-11 items-center gap-2 text-[12px] font-bold text-brand-ink underline decoration-accent/60 underline-offset-2">
          <ExternalLink className="h-4 w-4" aria-hidden="true" />
          {ui(language, "Açık kaynak yazılım lisansları", "Open-source software licences")}
        </a>
      </section>

      <section className="rounded-2xl border border-accent/25 bg-soft p-5 shadow-sm">
        <h3 className="font-serif text-base font-bold text-brand-ink">{notice.rightsTitle}</h3>
        <p className="mt-2 text-[13px] leading-relaxed">{notice.rights}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          {email && (
            <a
              href={`mailto:${email}`}
              className="flex min-h-11 items-center gap-2 rounded-xl bg-brand px-4 text-[12px] font-bold text-white"
            >
              <Mail className="h-4 w-4" aria-hidden="true" />
              <span>{notice.emailLabel}: <bdi>{email}</bdi></span>
            </a>
          )}
          {policyUrl && (
            <a
              href={policyUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-11 items-center gap-2 rounded-xl border border-accent/40 bg-card px-4 text-[12px] font-bold text-brand-ink"
            >
              <ExternalLink className="h-4 w-4" aria-hidden="true" />
              {notice.policyLabel}
            </a>
          )}
        </div>
      </section>
    </article>
  );
}
