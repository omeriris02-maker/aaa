import { Clock, Compass, Footprints, Info, Map as MapIcon, Navigation, Sparkles } from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import { ui } from "../i18n";
import { placeName, tourBriefing, tourName, tourSummary } from "../i18n/content";
import type { Language, Place, Tour } from "../types";
import { AROUND_HOTEL_TOUR_ID } from "../utils/tours";
import PlacePhoto from "./PlacePhoto";

interface ToursListProps {
  tours: Tour[];
  places: Place[];
  language: Language;
  hotel: HotelConfig;
  onSelectPlace: (place: Place) => void;
  onShowTourOnMap: (tour: Tour) => void;
}

const TOUR_EMOJI: Record<number, string> = {
  1: "🕌",
  2: "🏛️",
  3: "👑",
  4: "🏺",
  5: "✨",
  6: "📜",
  [AROUND_HOTEL_TOUR_ID]: "🏨",
};

export default function ToursList({ tours, places, language, hotel, onSelectPlace, onShowTourOnMap }: ToursListProps) {
  const placeById = new Map(places.map((place) => [place.id, place]));

  const badge = (tour: Tour) => {
    if (tour.id === AROUND_HOTEL_TOUR_ID) return ui(language, "OTEL SEÇKİSİ", "HOTEL SELECTION");
    if (tour.id === 1 || tour.id === 5) return ui(language, "MANEVİ YOLCULUK", "SPIRITUAL JOURNEY");
    return ui(language, "TARİHÎ ROTA", "HISTORIC ROUTE");
  };

  const openInGoogleMaps = (tour: Tour) => {
    const stops = tour.duraklar.map((id) => placeById.get(id)).filter((place): place is Place => Boolean(place));
    if (stops.length === 0) return;
    const destination = stops[stops.length - 1];
    const waypoints = stops.slice(0, -1).map((place) => `${place.koordinatlar.lat},${place.koordinatlar.lng}`).join("|");
    const url = new URL("https://www.google.com/maps/dir/");
    url.searchParams.set("api", "1");
    url.searchParams.set("origin", `${hotel.location.lat},${hotel.location.lng}`);
    url.searchParams.set("destination", `${destination.koordinatlar.lat},${destination.koordinatlar.lng}`);
    url.searchParams.set("travelmode", "walking");
    if (waypoints) url.searchParams.set("waypoints", waypoints);
    window.open(url.toString(), "_blank", "noopener,noreferrer");
  };

  return (
    <div className="space-y-6 text-start">
      <div className="flex items-center gap-2 border-b border-line pb-3">
        <Compass className="h-5 w-5 text-brand-ink" />
        <h2 className="font-serif text-lg font-bold text-brand-ink md:text-xl">
          {ui(language, "Hazır Tur Rotaları", "Curated Tour Routes")}
        </h2>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {tours.map((tour) => {
          const firstStop = placeById.get(tour.duraklar[0]);
          const briefing = tourBriefing(tour, language);
          return (
            <article key={tour.id} className="flex flex-col justify-between overflow-hidden rounded-2xl border border-accent/30 bg-soft shadow-sm transition-all hover:border-accent">
              <div className="relative h-[140px] w-full overflow-hidden border-b border-line bg-card">
                {firstStop ? (
                  <PlacePhoto
                    place={firstStop}
                    language={language}
                    className="h-full w-full object-cover opacity-90 transition-transform duration-500 hover:scale-105"
                  />
                ) : (
                  <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-soft to-accent/15">
                    <Compass className="h-8 w-8 text-brand-ink" />
                  </div>
                )}
                <span className="absolute start-3 top-3 flex items-center gap-1 rounded-md border border-accent/30 bg-brand px-2.5 py-1 text-[9px] font-bold uppercase tracking-widest text-white">
                  <Sparkles className="h-3 w-3 text-accent" />
                  {badge(tour)}
                </span>
              </div>

              <div className="flex flex-1 flex-col justify-between p-5">
                <div className="space-y-4">
                  <h3 className="flex items-center gap-2 font-serif text-base font-bold leading-snug text-brand-ink">
                    <span className="shrink-0 text-xl leading-none" aria-hidden="true">{TOUR_EMOJI[tour.id] ?? "🗺️"}</span>
                    <span>{tourName(tour, language)}</span>
                  </h3>
                  <p className="text-xs font-medium leading-relaxed text-ink">{tourSummary(tour, language)}</p>

                  <div className="flex gap-4 border-y border-line py-2 text-xs font-bold">
                    <span className="flex items-center gap-1 text-accent">
                      <Footprints className="h-4 w-4 text-brand-ink" />
                      <span>≈ {tour.mesafe_km} km</span>
                    </span>
                    <span className="flex items-center gap-1 text-ink">
                      <Clock className="h-4 w-4 text-accent" />
                      <span>≈ {tour.sure_saat} {ui(language, "saat", "hours")}</span>
                    </span>
                  </div>

                  <div className="space-y-3 pt-1">
                    <h4 className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-[#888888]">
                      <Sparkles className="h-3.5 w-3.5 text-accent" />
                      {ui(language, "ROTA DURAKLARI", "ROUTE STOPS")}
                    </h4>
                    <ol className="relative space-y-1 ps-7 before:absolute before:bottom-1 before:start-[7px] before:top-1 before:w-px before:bg-brand/30">
                      {tour.duraklar.map((stopId, index) => {
                        const stop = placeById.get(stopId);
                        if (!stop) return null;
                        return (
                          <li key={stopId} className="relative">
                            <span className="absolute -start-7 top-1/2 z-10 flex h-4 w-4 -translate-y-1/2 items-center justify-center rounded-full border border-accent bg-brand text-[8px] font-bold text-white">
                              {index + 1}
                            </span>
                            <button
                              type="button"
                              onClick={() => onSelectPlace(stop)}
                              className="flex min-h-10 w-full items-center text-start text-xs font-bold text-ink transition-colors hover:text-brand-ink"
                            >
                              <span className="underline decoration-accent decoration-dotted underline-offset-2">{placeName(stop, language)}</span>
                            </button>
                          </li>
                        );
                      })}
                    </ol>
                  </div>

                  {briefing && (
                    <p className="flex items-start gap-2 rounded-xl border border-accent/20 bg-accent/10 p-3 text-[11px] leading-relaxed text-ink">
                      <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />
                      <span>{briefing}</span>
                    </p>
                  )}
                </div>

                <div className="mt-5 grid grid-cols-1 gap-2 border-t border-line pt-4 sm:grid-cols-2">
                  <button
                    type="button"
                    onClick={() => onShowTourOnMap(tour)}
                    className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-brand/20 bg-brand/5 px-3 py-2.5 text-center text-[11px] font-bold leading-tight text-brand-ink shadow-sm transition-all hover:bg-brand/10"
                  >
                    <MapIcon className="h-4 w-4" />
                    {ui(language, "Rotayı uygulama haritasında aç", "Open route in app map")}
                  </button>
                  <button
                    type="button"
                    onClick={() => openInGoogleMaps(tour)}
                    className="flex min-h-12 items-center justify-center gap-2 rounded-xl border border-accent px-3 py-2.5 text-center text-[11px] font-bold leading-tight text-brand-ink transition-colors hover:bg-accent/10"
                  >
                    <Navigation className="h-4 w-4 shrink-0" />
                    {ui(language, "Google Haritalar’da Aç", "Open in Google Maps")}
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
