import { useState } from "react";
import { ui } from "../i18n";
import type { EventItem, Language } from "../types";
import type { HotelConfig } from "../../shared/hotelConfig";
import { calendarDayIn } from "../../shared/branding";
import { EVENTS } from "../data";
import { Calendar, Clock, MapPin, AlertCircle, Sparkles, Music, ExternalLink } from "lucide-react";
import { createWhatsAppUrl, openExternal } from "../utils/guest";
import { eventDate, eventLocation, eventName, eventSummary } from "../i18n/content";
import { trackEvent } from "../services/analytics";
import { eventOccurrenceStatus, resolveEventOccurrence } from "../utils/events";

interface EventsListProps {
  language: Language;
  hotel: HotelConfig;
  hotelName: string;
}

export default function EventsList({ language, hotel, hotelName }: EventsListProps) {
  const [failedImages, setFailedImages] = useState<Record<number, boolean>>({});
  const { year: currentYear, month: currentMonth, day: currentDay } = calendarDayIn(hotel.timezone);
  const currentOrdinal = currentYear * 10_000 + currentMonth * 100 + currentDay;
  const occurrenceFor = (event: EventItem) =>
    resolveEventOccurrence(event, currentYear, currentOrdinal);
  const getStatus = (event: EventItem) => {
    const occurrence = occurrenceFor(event);
    return occurrence ? eventOccurrenceStatus(occurrence, currentOrdinal) : "past";
  };
  const sortedEvents = EVENTS.filter((event) => event.aktif && occurrenceFor(event)).sort((a, b) => {
    const order = { active: 0, upcoming: 1 };
    const statusOrder = order[getStatus(a) as keyof typeof order] - order[getStatus(b) as keyof typeof order];
    if (statusOrder !== 0) return statusOrder;
    const aStart = occurrenceFor(a)?.start ?? Number.MAX_SAFE_INTEGER;
    const bStart = occurrenceFor(b)?.start ?? Number.MAX_SAFE_INTEGER;
    return aStart - bStart;
  });

  return (
    <div className="space-y-6 text-start">
      {/* Header */}
      <div className={`flex items-center gap-2 border-b pb-3 border-line`}>
        <Calendar className="w-5 h-5 text-brand-ink" />
        <h2 className={`font-serif font-bold text-lg md:text-xl text-brand-ink`}>
          {ui(language, "Kültür ve Sanat Takvimi", "Culture and Arts Calendar")}
        </h2>
      </div>
      {sortedEvents.length === 0 ? (
        <div className={`rounded-2xl border p-6 text-center text-sm border-line bg-soft`}>
          {ui(language, "Şu anda doğrulanmış yaklaşan etkinlik bulunmuyor.", "There are no verified upcoming events at the moment.")}
        </div>
      ) : <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {sortedEvents.map((event) => {
          const status = getStatus(event);
          return (
          <div
            key={event.id}
            className={`border rounded-2xl overflow-hidden flex flex-col shadow-sm hover:border-accent transition-all bg-soft border-accent/30`}
          >
            {/* Banner */}
            <div className={`w-full h-[150px] relative border-b bg-card border-line`}>
              {failedImages[event.id] || !event.fotograf_url ? (
                <div className={`w-full h-full flex flex-col items-center justify-center p-4 relative overflow-hidden transition-all bg-gradient-to-br from-soft to-accent/15 text-ink`}>
                  <div className="absolute inset-0 opacity-[0.04] pointer-events-none transform scale-150 rotate-12">
                    <svg width="100%" height="100%" fill="none" viewBox="0 0 100 100" stroke="currentColor">
                      <circle cx="50" cy="50" r="40" strokeWidth="1" />
                      <path d="M50 10 L50 90 M10 50 L90 50" strokeWidth="1" />
                    </svg>
                  </div>
                  
                  {event.isim_tr.toLowerCase().includes("müzik") || event.isim_en.toLowerCase().includes("music") ? (
                    <Music className={`w-8 h-8 mb-2 animate-pulse text-brand-ink`} />
                  ) : (
                    <Calendar className={`w-8 h-8 mb-2 animate-pulse text-brand-ink`} />
                  )}
                  
                  <span className={`text-[10px] font-sans font-semibold tracking-widest uppercase text-center max-w-[85%] text-gray-400`}>
                    {event.id === 1
                      ? ui(language, "Sema ve Kültür", "Sema and Culture")
                      : ui(language, "Yerel Kültür Etkinliği", "Local Cultural Event")}
                  </span>
                </div>
              ) : (
                <img
                  src={event.fotograf_url}
                  alt={eventName(event, language)}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  loading="lazy"
                  onError={() => {
                    setFailedImages(prev => ({ ...prev, [event.id]: true }));
                  }}
                />
              )}
              <div className="absolute top-3 start-3 bg-brand text-white text-[9px] font-bold px-2.5 py-1 rounded-md border border-accent/30 uppercase tracking-widest flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-accent" />
                {status === "active"
                  ? ui(language, "ŞU ANDA", "HAPPENING NOW")
                  : ui(language, "YAKLAŞAN ETKİNLİK", "UPCOMING")}
              </div>
              {event.fotograf_kaynak_url && !failedImages[event.id] && (
                <a
                  href={event.fotograf_kaynak_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute bottom-2 end-2 flex items-center gap-1 rounded-md bg-black/60 px-2 py-1 text-[8px] font-semibold text-white/90 backdrop-blur-sm hover:bg-black/75"
                  title={`${event.fotograf_kaynak} · ${event.fotograf_lisans}`}
                >
                  <ExternalLink className="h-2.5 w-2.5" />
                  <span>{event.fotograf_kaynak?.split(" / ").pop() || ui(language, "Kaynak", "Source")}</span>
                </a>
              )}
            </div>

            {/* Content */}
            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-2.5">
                <h3 className={`font-serif font-bold text-base leading-snug text-brand-ink`}>
                  {eventName(event, language)}
                </h3>
                <p className={`text-xs leading-relaxed text-[#555555]`}>
                  {eventSummary(event, language)}
                </p>

                <div className={`grid grid-cols-2 gap-2 text-xs font-semibold text-ink`}>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-accent shrink-0" />
                    <span>{eventDate(event, language)}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-accent shrink-0" />
                    <span>{event.saat === "—" ? ui(language, "Programdan teyit edin", "Confirm in the program") : event.saat}</span>
                  </div>
                </div>

                <div className={`space-y-1.5 pt-1 text-xs font-medium text-ink`}>
                  <div className="flex items-start gap-1.5">
                    <MapPin className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                    <span>{eventLocation(event, language)}</span>
                  </div>
                  <p className="text-[9px] leading-relaxed text-[#888888]">
                    {ui(language, "Kaynak", "Source")}:{" "}
                    {event.kaynak_url ? (
                      <a
                        href={event.kaynak_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="underline decoration-accent underline-offset-2"
                      >
                        {event.kaynak}
                      </a>
                    ) : event.kaynak}
                    {" · "}{ui(language, "Son doğrulama", "Last verified")}: {event.son_dogrulama}
                  </p>
                </div>
              </div>

              {/* Action */}
              <div className={`pt-3 border-t flex justify-between items-center text-xs border-line`}>
                <span className={`font-semibold flex items-center gap-1 text-ink`}>
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                  {ui(language, "Rezervasyon Gerekebilir", "Booking may be required")}
                </span>

                {hotel.contact.whatsapp ? (
                  <button
                    type="button"
                    onClick={() => {
                      const message = ui(
                        language,
                        "Merhaba! {hotel} misafir rehberinden ulaşıyorum. \"{event}\" etkinliği için bilgi almak istiyorum.",
                        "Hello! I am contacting you from the {hotel} guest guide. I would like information about \"{event}\".",
                        { hotel: hotelName, event: eventName(event, language) },
                      );
                      trackEvent("whatsapp_click", { language, module: "events" });
                      openExternal(createWhatsAppUrl(hotel.contact.whatsapp!.number, message, language));
                    }}
                    className="min-h-11 rounded-xl border border-accent/20 bg-brand px-4 py-2.5 text-xs font-bold text-white shadow-sm transition-all hover:opacity-95"
                  >
                    {ui(language, "Resepsiyondan Bilgi Al", "Ask Reception")}
                  </button>
                ) : hotel.contact.phone ? (
                  <a
                    href={`tel:${hotel.contact.phone.dial}`}
                    onClick={() => trackEvent("reception_call", { language, module: "events" })}
                    className="flex min-h-11 items-center rounded-xl border border-accent/20 bg-brand px-4 py-2.5 text-xs font-bold text-white shadow-sm"
                  >
                    {ui(language, "Resepsiyondan Bilgi Al", "Ask Reception")}
                  </a>
                ) : null}
              </div>
            </div>
          </div>
        )})}
      </div>}
    </div>
  );
}
