import { lazy, Suspense } from "react";
import { ChevronRight } from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import { ui } from "../i18n";
import { categoryLabel, placeName, tourName } from "../i18n/content";
import { normalizePlaceIds } from "../data";
import type { Language, Place, Tour } from "../types";
import PlacePhoto from "./PlacePhoto";
import ErrorBoundary from "./AppErrorBoundary";

const MaplibreMap = lazy(() => import("./MaplibreMap"));

interface MapViewProps {
  hotel: HotelConfig;
  hotelName: string;
  logoUrl: string;
  language: Language;
  places: Place[];
  focusPlace: Place | null;
  selectedTour: Tour | null;
  nearHotelOnly: boolean;
  onFocusHandled: () => void;
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
  onClearTour: () => void;
  onNavigateToPlace: (place: Place) => void;
  onOpenAllPlaces: () => void;
}

export default function MapView(props: MapViewProps) {
  const { language, places, selectedTour, hotel } = props;
  const featuredIds = selectedTour ? selectedTour.duraklar : normalizePlaceIds(hotel.map.featuredPlaceIds);
  const featured = featuredIds
    .map((id) => places.find((place) => place.id === id))
    .filter((place): place is Place => Boolean(place));

  const loading = (
    <div className="flex h-full min-h-[520px] items-center justify-center rounded-2xl border border-line bg-soft">
      <div className="flex items-center gap-3 text-xs font-bold text-brand-ink" role="status">
        <span className="h-5 w-5 animate-spin rounded-full border-2 border-accent border-t-brand" />
        {ui(language, "Harita hazırlanıyor…", "Preparing the map…")}
      </div>
    </div>
  );

  const mapFailed = (
    <div className="flex h-full min-h-[520px] flex-col items-center justify-center gap-2 rounded-2xl border border-line bg-soft p-6 text-center">
      <p className="text-sm font-bold text-brand-ink">{ui(language, "Harita şu anda yüklenemedi.", "The map could not be loaded right now.")}</p>
      <p className="max-w-sm text-xs text-[#777777]">
        {ui(language, "İnternet bağlantınızı kontrol edip sayfayı yenileyin. Mekân listesi ve rotalar çalışmaya devam eder.", "Check your connection and reload the page. Place lists and routes keep working.")}
      </p>
    </div>
  );

  return (
    <div className="w-full space-y-5 pb-3">
      <div className="h-[68vh] min-h-[520px] w-full">
        <ErrorBoundary fallback={mapFailed}>
          <Suspense fallback={loading}>
            <MaplibreMap
              hotel={hotel}
              hotelName={props.hotelName}
              logoUrl={props.logoUrl}
              places={places}
              focusPlace={props.focusPlace}
              onSelectPlace={props.onSelectPlace}
              onFocusHandled={props.onFocusHandled}
              language={language}
              selectedTour={selectedTour}
              onClearTour={props.onClearTour}
              onNavigateToPlace={props.onNavigateToPlace}
              nearHotelOnly={props.nearHotelOnly}
            />
          </Suspense>
        </ErrorBoundary>
      </div>

      <section className="rounded-2xl border border-line bg-card p-4 md:p-5">
        <div className="mb-4">
          <span className="text-[9px] font-bold uppercase tracking-[0.22em] text-accent">
            {selectedTour
              ? ui(language, "Seçili Gezi Rotası", "Selected Tour Route")
              : ui(language, "{hotel} Konsiyerj", "{hotel} Concierge", { hotel: props.hotelName })}
          </span>
          <h2 className="mt-1 font-serif text-lg font-bold text-brand-ink">
            {selectedTour
              ? tourName(selectedTour, language)
              : ui(language, "{hotel} Önerileri", "{hotel} Recommendations", { hotel: props.hotelName })}
          </h2>
          <p className="mt-1 text-[11px] text-[#777777]">
            {selectedTour
              ? ui(language, "Harita tüm durakları gösterir. Yaya güzergâhı alınabildiğinde yol çizilir; alınamadığında yanıltıcı bir çizgi yerine duraklar düzgün biçimde çerçevelenir.", "The map shows every stop. A walking route is drawn when available; otherwise the stops are framed clearly without a misleading line.")
              : ui(language, "Şehre ilk kez gelen misafirlerimiz için seçtiğimiz öne çıkan duraklar.", "Essential stops selected for first-time visitors.")}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
          {featured.map((place) => {
            const name = placeName(place, language);
            return (
              <article key={place.id} className="group overflow-hidden rounded-xl border border-line bg-soft transition-all hover:border-accent">
                <button type="button" onClick={() => props.onShowOnMap(place)} className="w-full text-start">
                  <div className="relative h-28 overflow-hidden">
                    <PlacePhoto
                      place={place}
                      alt={name}
                      language={language}
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <span className="absolute start-2.5 top-2.5 rounded-md bg-brand px-2 py-1 text-[8px] font-bold uppercase tracking-wider text-white">
                      {categoryLabel(place.kategori, language)}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2 p-3">
                    <h3 className="line-clamp-2 text-xs font-bold text-ink">{name}</h3>
                    <ChevronRight className="h-4 w-4 shrink-0 text-accent rtl:rotate-180" />
                  </div>
                </button>
              </article>
            );
          })}
        </div>

        {!selectedTour && (
          <div className="mt-5 flex justify-center border-t border-accent/15 pt-4">
            <button
              type="button"
              onClick={props.onOpenAllPlaces}
              className="min-h-11 rounded-xl border border-accent/35 px-5 py-2.5 text-[10px] font-bold text-brand-ink transition-colors hover:bg-accent/10"
            >
              {ui(language, "Tüm Mekânları Gör", "View All Places")}
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
