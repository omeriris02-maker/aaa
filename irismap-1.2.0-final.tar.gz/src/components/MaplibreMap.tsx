import { useEffect, useMemo, useRef, useState } from "react";
import * as maplibregl from "maplibre-gl";
import maplibreWorkerUrl from "maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url";
import "maplibre-gl/dist/maplibre-gl.css";
import { Info, MapPin, Navigation, Search, X } from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import { ui } from "../i18n";
import { categoryLabel, placeName, placeSummary } from "../i18n/content";
import type { Language, Place, Tour } from "../types";
import { placeMatches } from "../utils/placeText";
import { showToast } from "../utils/toast";
import { distanceMeters } from "../utils/tours";
import PlacePhoto from "./PlacePhoto";

// MapLibre 6 runs its tile worker from a separate module; Vite bundles it and
// gives us its address.
maplibregl.setWorkerUrl(maplibreWorkerUrl);

/** Sources IrisMap adds itself; their tiles say nothing about the base map. */
const OVERLAY_SOURCES = new Set(["hotel-circle-source", "user-accuracy-source", "tour-route-source"]);
/** How long a base map may take to show its first tile before the next option is tried. */
const BASEMAP_CHECK_MS = 10_000;

type Category = Place["kategori"];

interface CategoryStyle {
  background: string;
  border: string;
  iconColor: string;
  /** SVG path data drawn with stroke="currentColor". */
  icon: string;
}

const CATEGORY_STYLES: Record<Category, CategoryStyle> = {
  Cami: {
    background: "bg-brand",
    border: "border-accent",
    iconColor: "text-accent",
    icon: "M12 2C9 6 8 10 8 14h8c0-4-1-8-4-12z M6 14h12v6H6z M12 14v6 M12 2v2",
  },
  Müze: {
    background: "bg-accent",
    border: "border-brand",
    iconColor: "text-white",
    icon: "M4 20h16M3 20v-2h18v2M4 18v-8h3v8M10 18v-8h3v8M16 18v-8h3v8M3 10l9-6 9 6Z",
  },
  Medrese: {
    background: "bg-[#B45309]",
    border: "border-accent",
    iconColor: "text-white",
    icon: "M4 19.5A2.5 2.5 0 0 1 6.5 17H20 M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z",
  },
  UNESCO: {
    background: "bg-[#312E81]",
    border: "border-white",
    iconColor: "text-white",
    icon: "M12 2a10 10 0 1 0 0 20a10 10 0 1 0 0-20z M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z M2 12h20",
  },
  Park: {
    background: "bg-[#059669]",
    border: "border-accent",
    iconColor: "text-white",
    icon: "M12 2L3 9h18z M12 6l-7 6h14z M12 10l-8 7h16z M12 17v5",
  },
  Türbe: {
    background: "bg-[#6B21A8]",
    border: "border-accent",
    iconColor: "text-white",
    icon: "M12 3a8 8 0 0 0-8 8v9h16v-9a8 8 0 0 0-8-8z M12 3v3 M9 20v-5h6v5",
  },
  "Tarihi Yapı": {
    background: "bg-[#7C5A3C]",
    border: "border-accent",
    iconColor: "text-white",
    icon: "M3 21h18M5 21V9l7-5 7 5v12M9 21v-6h6v6M8 11h.01M16 11h.01",
  },
  Otel: {
    background: "bg-[#1E293B]",
    border: "border-accent",
    iconColor: "text-accent",
    icon: "M2 4v16M2 11h20M22 4v16M2 17h20",
  },
};

const legendItems = (language: Language): Array<{ category: Category; label: string }> => [
  { category: "Cami", label: ui(language, "Cami / Mescit", "Mosque") },
  { category: "Müze", label: ui(language, "Müze", "Museum") },
  { category: "Medrese", label: ui(language, "Medrese / Külliye", "Madrasa / Complex") },
  { category: "UNESCO", label: ui(language, "UNESCO Eseri", "UNESCO Site") },
  { category: "Park", label: ui(language, "Doğal Alan / Park", "Park / Nature") },
  { category: "Türbe", label: ui(language, "Türbe / Kabir", "Tomb / Shrine") },
  { category: "Tarihi Yapı", label: ui(language, "Tarihî Yapı", "Historic Site") },
];

const escapeHtml = (value: string) =>
  value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

const brandColor = (variable: string, fallback: string) => {
  const value = getComputedStyle(document.documentElement).getPropertyValue(variable).trim();
  return value || fallback;
};

function geoJsonCircle(center: [number, number], radiusKm: number, points = 64) {
  const [longitude, latitude] = center;
  const distanceX = radiusKm / (111.32 * Math.cos((latitude * Math.PI) / 180));
  const distanceY = radiusKm / 110.574;
  const ring: [number, number][] = [];
  for (let index = 0; index < points; index += 1) {
    const theta = (index / points) * (2 * Math.PI);
    ring.push([longitude + distanceX * Math.cos(theta), latitude + distanceY * Math.sin(theta)]);
  }
  ring.push(ring[0]);
  return {
    type: "Feature" as const,
    geometry: { type: "Polygon" as const, coordinates: [ring] },
    properties: {},
  };
}

function CategoryIcon({ category, className }: { category: Category; className: string }) {
  const style = CATEGORY_STYLES[category];
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" className={`${className} ${style.iconColor}`} aria-hidden="true">
      <path d={style.icon} />
    </svg>
  );
}

interface MaplibreMapProps {
  hotel: HotelConfig;
  hotelName: string;
  logoUrl: string;
  places: Place[];
  focusPlace: Place | null;
  onSelectPlace: (place: Place) => void;
  onFocusHandled?: () => void;
  language: Language;
  selectedTour: Tour | null;
  onClearTour?: () => void;
  onNavigateToPlace?: (place: Place) => void;
  nearHotelOnly?: boolean;
}

export default function MaplibreMap({
  hotel,
  hotelName,
  logoUrl,
  places,
  focusPlace,
  onSelectPlace,
  onFocusHandled,
  language,
  selectedTour,
  onClearTour,
  onNavigateToPlace,
  nearHotelOnly = true,
}: MaplibreMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const markersRef = useRef<maplibregl.Marker[]>([]);
  const userMarkerRef = useRef<maplibregl.Marker | null>(null);
  const geolocationWatchRef = useRef<number | null>(null);
  const locationErrorShownRef = useRef(false);

  const [searchQuery, setSearchQuery] = useState("");
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const [mapLoaded, setMapLoaded] = useState(false);
  const [styleEpoch, setStyleEpoch] = useState(0);
  const [basemapUnavailable, setBasemapUnavailable] = useState(false);
  const [basemapKind, setBasemapKind] = useState<"vector" | "raster">(hotel.map.styleUrl ? "vector" : "raster");
  const [mapFailed, setMapFailed] = useState(false);
  const [activePreviewPlace, setActivePreviewPlace] = useState<Place | null>(null);
  const [legendOpen, setLegendOpen] = useState(false);
  const [routeInfo, setRouteInfo] = useState<{ distanceKm: number; mode: "walking" | "stops" } | null>(null);

  const hotelPoint = useMemo(() => ({ lat: hotel.location.lat, lng: hotel.location.lng }), [hotel.location.lat, hotel.location.lng]);
  const surroundingsRadius = hotel.map.surroundingsRadiusMeters;

  // Focus a place requested from another screen without opening its detail page.
  useEffect(() => {
    const map = mapRef.current;
    if (!focusPlace || !map || !mapLoaded) return;
    setActivePreviewPlace(focusPlace);
    map.flyTo({
      center: [focusPlace.koordinatlar.lng, focusPlace.koordinatlar.lat],
      zoom: 16.6,
      offset: [0, -70],
      essential: true,
      duration: 1400,
    });
    onFocusHandled?.();
  }, [focusPlace, mapLoaded, onFocusHandled]);

  const handleGetCurrentLocation = () => {
    if (!("geolocation" in navigator)) {
      showToast(ui(language, "Tarayıcınız konum özelliğini desteklemiyor.", "Geolocation is not supported by your browser."));
      return;
    }
    if (geolocationWatchRef.current !== null) navigator.geolocation.clearWatch(geolocationWatchRef.current);
    locationErrorShownRef.current = false;
    let centred = false;

    geolocationWatchRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        const map = mapRef.current;
        if (!map) return;
        if (!centred) {
          map.flyTo({ center: [longitude, latitude], zoom: 15, essential: true });
          centred = true;
        }
        if (userMarkerRef.current) {
          userMarkerRef.current.setLngLat([longitude, latitude]);
        } else {
          const element = document.createElement("div");
          element.className = "relative flex h-8 w-8 items-center justify-center";
          element.innerHTML = `
            <div class="absolute h-6 w-6 animate-ping rounded-full bg-blue-500/30"></div>
            <div class="h-4 w-4 rounded-full border-2 border-white bg-blue-600 shadow-lg"></div>
          `;
          element.setAttribute("aria-label", ui(language, "Konumunuz", "Your location"));
          userMarkerRef.current = new maplibregl.Marker({ element }).setLngLat([longitude, latitude]).addTo(map);
        }
        const accuracySource = map.getSource("user-accuracy-source") as maplibregl.GeoJSONSource | undefined;
        accuracySource?.setData(geoJsonCircle([longitude, latitude], Math.max(accuracy, 10) / 1000));
      },
      (error) => {
        console.warn("Location unavailable:", error.code);
        if (locationErrorShownRef.current) return;
        locationErrorShownRef.current = true;
        showToast(ui(language, "Konumunuz alınamadı. Lütfen tarayıcı izinlerini kontrol edin.", "Could not retrieve location. Please check browser permissions."), 4000);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 },
    );
  };

  // Create the map once.
  useEffect(() => {
    const container = mapContainerRef.current;
    if (!container) return;

    const rasterStyle: maplibregl.StyleSpecification = {
      version: 8,
      sources: {
        basemap: {
          type: "raster",
          tiles: hotel.map.tileUrls,
          tileSize: 256,
          attribution: hotel.map.tileAttribution,
        },
      },
      layers: [{ id: "basemap-layer", type: "raster", source: "basemap", minzoom: 0, maxzoom: 20 }],
    };

    let map: maplibregl.Map;
    try {
      map = new maplibregl.Map({
        container,
        style: hotel.map.styleUrl ?? rasterStyle,
        center: [hotelPoint.lng, hotelPoint.lat],
        zoom: 15,
        attributionControl: { compact: true },
      });
    } catch (error) {
      // WebGL unavailable (old device, disabled hardware acceleration).
      console.warn("Map could not be created:", error);
      setMapFailed(true);
      return;
    }
    mapRef.current = map;
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "bottom-left");

    // Our own layers sit on top of whichever base map is shown; a new style
    // (the fallback below) removes them, so they are added again on every style load.
    const addOverlays = () => {
      if (!map.getSource("hotel-circle-source")) {
        const primary = brandColor("--im-primary", "#2f5d62");
        map.addSource("hotel-circle-source", {
          type: "geojson",
          data: { type: "FeatureCollection", features: [geoJsonCircle([hotelPoint.lng, hotelPoint.lat], surroundingsRadius / 1000)] },
        });
        map.addLayer({
          id: "hotel-circle-layer",
          type: "fill",
          source: "hotel-circle-source",
          layout: { visibility: "none" },
          paint: { "fill-color": primary, "fill-opacity": 0.08, "fill-outline-color": primary },
        });
      }
      if (!map.getSource("user-accuracy-source")) {
        map.addSource("user-accuracy-source", { type: "geojson", data: { type: "FeatureCollection", features: [] } });
        map.addLayer({
          id: "user-accuracy-layer",
          type: "fill",
          source: "user-accuracy-source",
          paint: { "fill-color": "#2563EB", "fill-opacity": 0.12, "fill-outline-color": "#2563EB" },
        });
      }
    };

    // Base map fallback: vector style (map.styleUrl) → raster tiles → markers on a
    // plain background with a short notice. Decided once per style, when the
    // first tiles have loaded or failed.
    let usingRaster = !hotel.map.styleUrl;
    let basemapTileLoaded = false;
    let evaluatePending = true;
    let checkTimer: ReturnType<typeof setTimeout> | undefined;
    const switchToRaster = (reason: string) => {
      if (usingRaster) return;
      usingRaster = true;
      setBasemapKind("raster");
      console.warn(`Map style unavailable (${reason}); using the fallback map images.`);
      map.setStyle(rasterStyle);
    };
    // Runs when the map goes idle or, at the latest, a few seconds after a style
    // loads (failing tile servers can keep the map from ever becoming idle).
    const evaluateBasemap = () => {
      if (!evaluatePending) return;
      evaluatePending = false;
      clearTimeout(checkTimer);
      if (basemapTileLoaded) setBasemapUnavailable(false);
      else if (!usingRaster) switchToRaster("no tiles");
      else setBasemapUnavailable(true);
    };
    map.on("error", (event) => {
      if (!map.isStyleLoaded()) switchToRaster(event.error?.message ?? "style error");
    });
    map.on("sourcedata", (event) => {
      if (event.tile?.state !== "loaded" || OVERLAY_SOURCES.has(event.sourceId)) return;
      basemapTileLoaded = true;
      setBasemapUnavailable(false);
    });
    map.on("style.load", () => {
      basemapTileLoaded = false;
      evaluatePending = true;
      clearTimeout(checkTimer);
      checkTimer = setTimeout(evaluateBasemap, BASEMAP_CHECK_MS);
      addOverlays();
      setStyleEpoch((epoch) => epoch + 1);
      setMapLoaded(true);
    });
    map.on("idle", evaluateBasemap);

    map.on("load", () => {
      addOverlays();
      setMapLoaded(true);
    });

    const resizeObserver = new ResizeObserver(() => map.resize());
    resizeObserver.observe(container);

    return () => {
      clearTimeout(checkTimer);
      resizeObserver.disconnect();
      if (geolocationWatchRef.current !== null) {
        navigator.geolocation.clearWatch(geolocationWatchRef.current);
        geolocationWatchRef.current = null;
      }
      markersRef.current.forEach((marker) => marker.remove());
      markersRef.current = [];
      userMarkerRef.current = null;
      map.remove();
      mapRef.current = null;
      setMapLoaded(false);
    };
    // The map is created once; hotel settings do not change while the page is open.
  }, []);

  const filterMode: "SURROUNDINGS" | "ALL" = selectedTour || !nearHotelOnly ? "ALL" : "SURROUNDINGS";

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded || !map.getLayer("hotel-circle-layer")) return;
    map.setLayoutProperty("hotel-circle-layer", "visibility", filterMode === "SURROUNDINGS" ? "visible" : "none");
  }, [filterMode, mapLoaded, styleEpoch]);

  // Draw only a verified road-following walking route. When none is available
  // the stops are framed instead; no straight or dashed line is invented.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    const activeMap: maplibregl.Map = map;
    const controller = new AbortController();
    let animationFrame = 0;

    if (activeMap.getLayer("tour-route-layer")) activeMap.removeLayer("tour-route-layer");
    if (activeMap.getSource("tour-route-source")) activeMap.removeSource("tour-route-source");

    if (!selectedTour) {
      setRouteInfo(null);
      return;
    }

    const routeCoords: [number, number][] = [[hotelPoint.lng, hotelPoint.lat]];
    selectedTour.duraklar.forEach((stopId) => {
      const place = places.find((candidate) => candidate.id === stopId);
      if (place) routeCoords.push([place.koordinatlar.lng, place.koordinatlar.lat]);
    });
    if (routeCoords.length < 2) return;
    setRouteInfo(null);

    const frameStops = () => {
      const bounds = new maplibregl.LngLatBounds();
      routeCoords.forEach((coord) => bounds.extend(coord));
      activeMap.fitBounds(bounds, { padding: 80, maxZoom: 15.5, duration: 900 });
    };

    async function drawRoute() {
      let geometry: [number, number][];
      let distanceKm: number;
      try {
        const response = await fetch("/api/route", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ coordinates: routeCoords.slice(0, 25) }),
          signal: controller.signal,
        });
        if (!response.ok) throw new Error("Verified route is unavailable");
        const result = await response.json() as { coordinates?: unknown; distanceKm?: unknown; fallback?: unknown };
        if (result.fallback || !Array.isArray(result.coordinates) || result.coordinates.length < 2 || typeof result.distanceKm !== "number") {
          throw new Error("Invalid route geometry");
        }
        geometry = result.coordinates as [number, number][];
        distanceKm = result.distanceKm;
      } catch (error) {
        if ((error as Error).name === "AbortError" || controller.signal.aborted || !mapRef.current) return;
        frameStops();
        setRouteInfo({ distanceKm: 0, mode: "stops" });
        return;
      }
      if (controller.signal.aborted || !mapRef.current) return;

      const animatedGeometry: [number, number][] = [];
      geometry.forEach((coordinate, index) => {
        if (index === 0) {
          animatedGeometry.push(coordinate);
          return;
        }
        const previous = geometry[index - 1];
        const steps = Math.max(4, Math.min(18, Math.ceil(Math.hypot(coordinate[0] - previous[0], coordinate[1] - previous[1]) * 3500)));
        for (let step = 1; step <= steps; step += 1) {
          const progress = step / steps;
          animatedGeometry.push([
            previous[0] + (coordinate[0] - previous[0]) * progress,
            previous[1] + (coordinate[1] - previous[1]) * progress,
          ]);
        }
      });

      activeMap.addSource("tour-route-source", {
        type: "geojson",
        data: { type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: animatedGeometry.slice(0, 2) } },
      });
      activeMap.addLayer({
        id: "tour-route-layer",
        type: "line",
        source: "tour-route-source",
        layout: { "line-join": "round", "line-cap": "round" },
        paint: { "line-color": brandColor("--im-primary", "#2f5d62"), "line-width": 5, "line-opacity": 0.85 },
      });

      const bounds = new maplibregl.LngLatBounds();
      geometry.forEach((coord) => bounds.extend(coord));
      activeMap.fitBounds(bounds, { padding: 80, maxZoom: 15, duration: 1100 });

      const startedAt = performance.now();
      const animate = (now: number) => {
        if (controller.signal.aborted || !mapRef.current) return;
        const source = activeMap.getSource("tour-route-source") as maplibregl.GeoJSONSource | undefined;
        if (!source) return;
        const progress = Math.min(1, (now - startedAt) / 1200);
        const eased = 1 - Math.pow(1 - progress, 3);
        const visible = Math.max(2, Math.ceil(animatedGeometry.length * eased));
        source.setData({ type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: animatedGeometry.slice(0, visible) } });
        if (progress < 1) animationFrame = requestAnimationFrame(animate);
      };
      animationFrame = requestAnimationFrame(animate);
      setRouteInfo({ distanceKm, mode: "walking" });
    }

    void drawRoute();
    return () => {
      controller.abort();
      cancelAnimationFrame(animationFrame);
    };
  }, [selectedTour, mapLoaded, places, hotelPoint, styleEpoch]);

  // Hotel and place markers.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !mapLoaded) return;
    markersRef.current.forEach((marker) => marker.remove());
    markersRef.current = [];

    const hotelElement = document.createElement("div");
    hotelElement.className = "group relative flex cursor-pointer flex-col items-center justify-center";
    hotelElement.innerHTML = `
      <div class="relative flex items-center justify-center">
        <div class="flex h-14 w-10 items-center justify-center rounded-xl border-2 border-accent bg-logo-frame p-0.5 shadow-xl transition duration-300 hover:scale-110">
          <img src="${escapeHtml(logoUrl)}" class="h-full w-full object-contain" alt="" />
        </div>
        <div class="pointer-events-none absolute -inset-1 animate-ping rounded-xl border-2 border-brand/50"></div>
      </div>
    `;
    hotelElement.setAttribute("role", "img");
    hotelElement.setAttribute("aria-label", hotelName);
    const hotelPopup = new maplibregl.Popup({ offset: 25, closeButton: false }).setHTML(`
      <div class="p-2 text-center font-sans text-xs">
        <b class="block text-sm text-brand-ink">${escapeHtml(hotelName)}</b>
        <span class="text-[10px] font-medium text-gray-500">${escapeHtml(ui(language, "Konaklama Merkeziniz", "Your Accommodation"))}</span>
      </div>
    `);
    markersRef.current.push(new maplibregl.Marker({ element: hotelElement }).setLngLat([hotelPoint.lng, hotelPoint.lat]).setPopup(hotelPopup).addTo(map));

    const visiblePlaces = places.filter((place) => {
      if (selectedTour) return selectedTour.duraklar.includes(place.id);
      if (activePreviewPlace?.id === place.id) return true;
      if (!placeMatches(place, searchQuery)) return false;
      if (filterMode === "SURROUNDINGS") {
        return distanceMeters(hotelPoint, { lat: place.koordinatlar.lat, lng: place.koordinatlar.lng }) <= surroundingsRadius;
      }
      return true;
    });

    visiblePlaces.forEach((place) => {
      const style = CATEGORY_STYLES[place.kategori] ?? CATEGORY_STYLES.Otel;
      const name = placeName(place, language);
      const active = activePreviewPlace?.id === place.id;
      const element = document.createElement("button");
      element.type = "button";
      element.className = "group relative flex cursor-pointer flex-col items-center justify-center";
      element.innerHTML = `
        <div class="relative flex items-center justify-center">
          ${active ? `<div class="absolute h-14 w-14 animate-ping rounded-full border-2 border-brand/70 bg-accent/25"></div>` : ""}
          <div class="${active ? "h-11 w-11 scale-110 ring-4 ring-white/80" : "h-9 w-9"} flex items-center justify-center rounded-full border-2 ${style.background} ${style.border} shadow-lg transition duration-300 hover:scale-110">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" class="h-3.5 w-3.5 ${style.iconColor}"><path d="${style.icon}"></path></svg>
          </div>
          ${active ? `<div class="absolute top-12 max-w-[180px] truncate rounded-lg border border-accent/50 bg-white px-2.5 py-1 text-[10px] font-bold text-brand-ink shadow-xl">${escapeHtml(name)}</div>` : ""}
        </div>
      `;
      element.setAttribute("aria-label", name);
      element.addEventListener("click", () => {
        setActivePreviewPlace(place);
        map.flyTo({ center: [place.koordinatlar.lng, place.koordinatlar.lat], zoom: 16.6, offset: [0, -70], essential: true, duration: 1200 });
      });
      markersRef.current.push(new maplibregl.Marker({ element }).setLngLat([place.koordinatlar.lng, place.koordinatlar.lat]).addTo(map));
    });
  }, [places, searchQuery, filterMode, mapLoaded, language, selectedTour, activePreviewPlace?.id, hotelPoint, surroundingsRadius, hotelName, logoUrl]);

  const autocompleteResults = searchQuery.trim().length >= 2
    ? places.filter((place) => placeMatches(place, searchQuery)).slice(0, 5)
    : [];

  if (mapFailed) {
    return (
      <div className="flex h-full min-h-[500px] flex-col items-center justify-center gap-2 rounded-2xl border border-line bg-soft p-6 text-center">
        <p className="text-sm font-bold text-brand-ink">{ui(language, "Harita bu cihazda gösterilemiyor.", "The map cannot be shown on this device.")}</p>
        <p className="max-w-sm text-xs text-[#777777]">
          {ui(language, "Tarayıcınız harita için gereken grafik desteğini sunmuyor. Mekân listesi, rotalar ve Google Haritalar bağlantıları çalışmaya devam eder.", "Your browser lacks the graphics support the map needs. Place lists, routes and Google Maps links keep working.")}
        </p>
      </div>
    );
  }

  return (
    <div
      id="maplibre-tab-container"
      data-map-ready={mapLoaded ? "true" : "false"}
      data-basemap={basemapUnavailable ? "unavailable" : basemapKind}
      className="relative flex h-full min-h-[500px] w-full flex-col overflow-hidden rounded-2xl border border-line bg-white shadow-sm">
      <div className="absolute inset-x-4 top-4 z-10 flex max-w-lg flex-col gap-2.5">
        <div className="relative">
          <div className="flex items-center gap-2 rounded-xl border border-accent/40 bg-white/95 px-3.5 shadow-xl backdrop-blur-md">
            <Search className="h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
            <input
              id="map-search-bar"
              type="search"
              autoComplete="off"
              enterKeyHint="search"
              aria-label={ui(language, "Gezilecek yer veya kategori ara…", "Search places or categories…")}
              placeholder={ui(language, "Gezilecek yer veya kategori ara…", "Search places or categories…")}
              value={searchQuery}
              onChange={(event) => {
                setSearchQuery(event.target.value);
                setShowAutocomplete(true);
              }}
              onFocus={() => setShowAutocomplete(true)}
              className="min-h-11 w-full border-none bg-transparent text-base font-medium text-ink outline-none placeholder:text-[#999999] md:text-xs"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery("");
                  setShowAutocomplete(false);
                }}
                className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-[#999999] hover:text-ink"
                aria-label={ui(language, "Aramayı temizle", "Clear search")}
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {showAutocomplete && autocompleteResults.length > 0 && (
            <div className="absolute inset-x-0 top-full z-50 mt-1 max-h-60 divide-y divide-line overflow-y-auto rounded-xl border border-line bg-white shadow-2xl">
              {autocompleteResults.map((place) => (
                <button
                  type="button"
                  key={place.id}
                  onClick={() => {
                    setActivePreviewPlace(place);
                    setShowAutocomplete(false);
                    setSearchQuery("");
                    onClearTour?.();
                    mapRef.current?.flyTo({ center: [place.koordinatlar.lng, place.koordinatlar.lat], zoom: 15.5, essential: true });
                  }}
                  className="flex min-h-11 w-full items-center gap-3 px-4 py-2.5 text-start transition-colors hover:bg-soft"
                >
                  <MapPin className="h-4 w-4 shrink-0 text-brand-ink" />
                  <span>
                    <span className="block text-xs font-bold text-ink">{placeName(place, language)}</span>
                    <span className="block text-[10px] text-[#888888]">{categoryLabel(place.kategori, language)}</span>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {selectedTour && (
        <div className="absolute end-4 top-[112px] z-10 max-w-[230px] rounded-xl border border-accent/40 bg-white/95 px-3 py-2 text-start shadow-lg backdrop-blur-md">
          <div className="flex items-center justify-between gap-3">
            <span className="text-[10px] font-bold text-brand-ink">{ui(language, "Tur rotası etkin", "Tour route active")}</span>
            <button
              type="button"
              onClick={onClearTour}
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg text-[#999999] hover:bg-black/5 hover:text-ink"
              aria-label={ui(language, "Rotayı kapat", "Close route")}
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
          <p className="mt-1 text-[9px] font-medium text-[#666666]" role="status">
            {!routeInfo
              ? ui(language, "Yürüyüş rotası hesaplanıyor…", "Calculating the walking route…")
              : routeInfo.mode === "stops"
                ? ui(language, "Duraklar haritada işaretlendi", "Stops are marked on the map")
                : `${routeInfo.distanceKm.toFixed(1)} km · ${ui(language, "Yaya güzergâhı", "Walking route")}`}
          </p>
        </div>
      )}

      <div className="absolute start-4 top-[68px] z-10 flex flex-col gap-2">
        <button
          type="button"
          id="location-detect-btn"
          onClick={handleGetCurrentLocation}
          title={ui(language, "Şu an neredeyim?", "Where am I?")}
          aria-label={ui(language, "Şu an neredeyim?", "Where am I?")}
          className="flex h-11 w-11 items-center justify-center rounded-xl border border-line bg-white/95 text-brand-ink shadow-lg transition-all hover:bg-white"
        >
          <Navigation className="h-4 w-4 fill-brand/20" />
        </button>
      </div>

      {basemapUnavailable && (
        <div className="pointer-events-none absolute end-4 start-[4.25rem] top-[72px] z-10 flex">
          <p role="status" className="rounded-xl border border-accent/40 bg-white/95 px-3 py-2 text-[10px] font-semibold leading-snug text-ink shadow-lg backdrop-blur-md">
            {ui(language, "Harita görüntüsü şu anda yüklenemiyor; otel ve gezilecek yerler yine de gösteriliyor.", "The map images cannot be loaded right now; the hotel and places are still shown.")}
          </p>
        </div>
      )}

      <div ref={mapContainerRef} className="z-0 h-full min-h-[500px] w-full flex-1" />

      {activePreviewPlace && (
        <div
          id="map-bottom-sheet"
          className="animate-fade-in absolute inset-x-2 bottom-2 z-20 mx-auto flex max-w-md gap-3 rounded-xl border border-line bg-white/95 p-2.5 shadow-xl backdrop-blur-md sm:bottom-4 sm:p-3"
        >
          <div className="relative h-[88px] w-[92px] shrink-0 overflow-hidden rounded-lg bg-gray-100 sm:w-[110px]">
            <PlacePhoto place={activePreviewPlace} language={language} compact className="h-full w-full object-cover" />
            <span className="absolute start-2 top-2 rounded-md border border-accent/20 bg-brand px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest text-white">
              {categoryLabel(activePreviewPlace.kategori, language)}
            </span>
          </div>
          <div className="flex min-w-0 flex-1 flex-col justify-between gap-1.5 text-start">
            <div className="space-y-1">
              <div className="flex items-start justify-between gap-1">
                <h4 className="font-serif text-sm font-bold leading-tight text-brand-ink">{placeName(activePreviewPlace, language)}</h4>
                <button
                  type="button"
                  onClick={() => setActivePreviewPlace(null)}
                  className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-[#999999] transition-all hover:bg-gray-100 hover:text-ink"
                  aria-label={ui(language, "Mekân kartını kapat", "Close place card")}
                >
                  <X className="h-4 w-4" />
                </button>
              </div>
              <p className="line-clamp-2 text-[10px] font-medium leading-relaxed text-ink">{placeSummary(activePreviewPlace, language)}</p>
            </div>
            <div className="flex gap-1.5 border-t border-line pt-1.5">
              <button
                type="button"
                onClick={() => onSelectPlace(activePreviewPlace)}
                className="flex min-h-11 flex-1 items-center justify-center gap-1 rounded-lg bg-brand px-2.5 py-2 text-[10px] font-bold uppercase tracking-wide text-white shadow-sm transition-all hover:opacity-95"
              >
                <Info className="h-3.5 w-3.5" />
                <span>{ui(language, "Detayları Gör", "View Details")}</span>
              </button>
              <button
                type="button"
                onClick={() => onNavigateToPlace?.(activePreviewPlace)}
                className="flex min-h-11 items-center justify-center gap-1 rounded-lg border border-accent bg-white px-2.5 py-2 text-[10px] font-bold uppercase tracking-wide text-brand-ink shadow-sm transition-all hover:bg-gray-50"
              >
                <Navigation className="h-3.5 w-3.5" />
                <span>{ui(language, "Yürüyüş Rotası", "Walking Route")}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {!activePreviewPlace && (
        <div id="map-legend-box" className="absolute bottom-4 end-4 z-10 flex flex-col items-end">
          {!legendOpen ? (
            <button
              type="button"
              onClick={() => setLegendOpen(true)}
              className="flex min-h-11 items-center gap-1.5 rounded-xl border border-accent/40 bg-white/95 px-3 py-2 text-[10px] font-bold text-brand-ink shadow-lg backdrop-blur-md transition-all hover:bg-white"
              aria-expanded={false}
            >
              <Info className="h-3.5 w-3.5 text-accent" />
              <span>{ui(language, "Harita Göstergesi", "Map Legend")}</span>
            </button>
          ) : (
            <div className="animate-fade-in flex w-52 flex-col gap-2 rounded-xl border border-accent/40 bg-white/95 p-3 text-start shadow-2xl backdrop-blur-md">
              <div className="flex items-center justify-between border-b border-line pb-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-brand-ink">{ui(language, "Harita Göstergesi", "Map Legend")}</span>
                <button
                  type="button"
                  onClick={() => setLegendOpen(false)}
                  className="flex h-9 w-9 items-center justify-center rounded-lg text-[#999999] hover:text-ink"
                  aria-label={ui(language, "Harita göstergesini kapat", "Close map legend")}
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
              <ul className="flex max-h-56 flex-col gap-1.5 overflow-y-auto">
                <li className="flex items-center gap-2">
                  <span className="flex h-9 w-6 shrink-0 items-center justify-center rounded-md border border-accent bg-logo-frame p-0.5 shadow-sm">
                    <img src={logoUrl} className="h-full w-full object-contain" alt="" />
                  </span>
                  <span className="text-[10px] font-bold text-brand-ink">{hotelName}</span>
                </li>
                {legendItems(language).map((item) => {
                  const style = CATEGORY_STYLES[item.category];
                  return (
                    <li key={item.category} className="flex items-center gap-2">
                      <span className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${style.background} ${style.border}`}>
                        <CategoryIcon category={item.category} className="h-3 w-3" />
                      </span>
                      <span className="text-[10px] font-medium text-ink">{item.label}</span>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
