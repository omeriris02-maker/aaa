import { useState, useEffect } from "react";
import { ui } from "../i18n";
import type { Place, Language } from "../types";
import { readIdList, writeIdList } from "../utils/storage";
import { normalizePlaceIds } from "../data";
import { getHotel } from "../config/hotel";
import { orderByNearestNeighbour } from "../utils/tours";
import { showToast } from "../utils/toast";
import PlacePhoto from "./PlacePhoto";
import { getWalkingRouteMetrics, WalkingRouteMetrics } from "../services/routing";
import { categoryLabel, placeName } from "../i18n/content";
import { 
  Heart, CheckSquare, Square, Trash2, Calendar, Compass, 
  MapPin, Plus, CheckCircle2, ArrowUp, ArrowDown, Shuffle
} from "lucide-react";

interface PersonalPlanProps {
  places: Place[];
  language: Language;
  cityName: string;
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
  onShowRouteOnMap: (placeIds: number[]) => void;
  favorites: number[];
  onToggleFavorite: (id: number) => void;
}

export default function PersonalPlan({
  places,
  language,
  cityName,
  onSelectPlace,
  onShowOnMap,
  onShowRouteOnMap,
  favorites,
  onToggleFavorite,
}: PersonalPlanProps) {
  // Checklist and custom route are kept on this device only.
  const [checklist, setChecklist] = useState<number[]>(() => normalizePlaceIds(readIdList("checklist")));
  const [customRoute, setCustomRoute] = useState<number[]>(() => normalizePlaceIds(readIdList("custom-route")));
  const [routeMetrics, setRouteMetrics] = useState<WalkingRouteMetrics | null>(null);
  const [routeMetricsLoading, setRouteMetricsLoading] = useState(false);
  const [routeMetricsError, setRouteMetricsError] = useState(false);

  const saveChecklist = (newChecklist: number[]) => {
    setChecklist(newChecklist);
    writeIdList("checklist", newChecklist);
  };

  const saveRoute = (newRoute: number[]) => {
    setCustomRoute(newRoute);
    writeIdList("custom-route", newRoute);
  };

  const toggleChecklistItem = (id: number) => {
    if (checklist.includes(id)) {
      saveChecklist(checklist.filter((item) => item !== id));
    } else {
      saveChecklist([...checklist, id]);
    }
  };

  const addToRoute = (id: number) => {
    if (!customRoute.includes(id) && customRoute.length < 25) {
      saveRoute([...customRoute, id]);
    }
  };

  const removeFromRoute = (id: number) => {
    saveRoute(customRoute.filter((item) => item !== id));
  };

  const clearRoute = () => {
    saveRoute([]);
  };

  const moveStop = (index: number, delta: -1 | 1) => {
    const target = index + delta;
    if (target < 0 || target >= customRoute.length) return;
    const next = [...customRoute];
    [next[index], next[target]] = [next[target], next[index]];
    saveRoute(next);
  };

  /** Re-orders the stops so that each next stop is the closest one, starting at the hotel. */
  const optimizeOrder = () => {
    const hotel = getHotel();
    const routePlaces = customRoute
      .map((id) => places.find((place) => place.id === id))
      .filter((place): place is Place => Boolean(place));
    saveRoute(orderByNearestNeighbour({ lat: hotel.location.lat, lng: hotel.location.lng }, routePlaces).map((place) => place.id));
    showToast(ui(language, "Duraklar otelden başlayarak en kısa yürüyüş sırasına dizildi.", "Stops were ordered for the shortest walk from the hotel."));
  };

  const importFavoritesToRoute = () => {
    saveRoute(favoritePlaces.map((place) => place.id).slice(0, 8));
  };

  const openRouteInGoogleMaps = () => {
    const routePlaces = customRoute
      .map((id) => places.find((place) => place.id === id))
      .filter((place): place is Place => Boolean(place));
    if (routePlaces.length === 0) return;
    const destination = routePlaces[routePlaces.length - 1];
    const waypoints = routePlaces.slice(0, -1)
      .map((place) => `${place.koordinatlar.lat},${place.koordinatlar.lng}`)
      .join("|");
    const url = new URL("https://www.google.com/maps/dir/");
    url.searchParams.set("api", "1");
    url.searchParams.set("destination", `${destination.koordinatlar.lat},${destination.koordinatlar.lng}`);
    url.searchParams.set("travelmode", "walking");
    if (waypoints) url.searchParams.set("waypoints", waypoints);
    window.open(url.toString(), "_blank", "noopener,noreferrer");
  };

  const favoritePlaces = places.filter((p) => favorites.includes(p.id));
  const checklistPlaces = (customRoute.length > 0
    ? customRoute.map((id) => places.find((place) => place.id === id)).filter((place): place is Place => Boolean(place))
    : favoritePlaces.length > 0
      ? favoritePlaces
      : places.slice(0, 6)
  ).slice(0, 8);

  const customRoutePlaces = customRoute
    .map((id) => places.find((place) => place.id === id))
    .filter((place): place is Place => Boolean(place));

  const routeKey = customRoutePlaces.map((place) => place.id).join(",");
  useEffect(() => {
    if (customRoutePlaces.length < 2) {
      setRouteMetrics(null);
      setRouteMetricsError(false);
      setRouteMetricsLoading(false);
      return;
    }

    const controller = new AbortController();
    setRouteMetricsLoading(true);
    setRouteMetricsError(false);

    getWalkingRouteMetrics(customRoutePlaces, controller.signal)
      .then((result) => {
        setRouteMetrics(result);
        setRouteMetricsError(false);
      })
      .catch((error) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        setRouteMetrics(null);
        setRouteMetricsError(true);
      })
      .finally(() => {
        if (!controller.signal.aborted) setRouteMetricsLoading(false);
      });

    return () => controller.abort();
    // customRoutePlaces is derived from routeKey; the key alone decides when to refetch.
  }, [routeKey]);

  return (
    <div className="space-y-8 text-start">
      {/* Tab Header */}
      <div className={`flex items-center gap-2 border-b pb-3 border-line`}>
        <Calendar className="w-5 h-5 text-brand-ink" />
        <h2 className={`font-serif font-bold text-lg md:text-xl text-brand-ink`}>
          {ui(language, "Kişisel Seyahat Planım", "My Personal Travel Plan")}
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Side: Favorites */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className={`font-serif font-bold text-sm tracking-wider uppercase flex items-center gap-1.5 border-b pb-2 text-brand-ink border-line`}>
            <Heart className="w-4 h-4 text-brand-ink fill-brand" />
            {ui(language, "FAVORİ MEKÂNLARIM", "MY SAVED PLACES")}
          </h3>

          {favoritePlaces.length === 0 ? (
            <div className={`border p-5 rounded-2xl text-center shadow-sm bg-soft border-line`}>
              <Heart className="w-8 h-8 text-[#999999] mx-auto mb-2" />
              <p className={`text-xs font-medium leading-relaxed text-ink`}>
                {ui(language, "Henüz favori mekân eklemediniz. Beğendiğiniz yerleri kalp simgesiyle buraya kaydedebilirsiniz.", "No saved places yet. Use the heart icon to save places here.")}
              </p>
            </div>
          ) : (
            <div className="max-h-[350px] space-y-2 overflow-y-auto pe-1">
              {favoritePlaces.map((p) => (
                <div
                  key={p.id}
                  className={`border p-3 rounded-xl flex justify-between items-center transition-all shadow-sm bg-soft border-accent/35 hover:border-accent`}
                >
                  <div className="min-w-0 flex-1">
                    <button
                      onClick={() => onSelectPlace(p)}
                      className="block w-full truncate text-start font-serif text-xs font-bold text-ink transition-colors hover:text-brand-ink"
                    >
                      {placeName(p, language)}
                    </button>
                    <span className={`text-[9px] font-bold uppercase tracking-wider text-brand-ink`}>{categoryLabel(p.kategori, language)}</span>
                  </div>

                  <div className="flex gap-1">
                    <button
                      type="button"
                      onClick={() => addToRoute(p.id)}
                      disabled={customRoute.includes(p.id)}
                      className="flex h-10 w-10 items-center justify-center rounded-lg text-brand-ink transition-all hover:bg-brand/10 disabled:opacity-30"
                      title={ui(language, "Rotaya ekle", "Add to route")}
                      aria-label={ui(language, "Rotaya ekle", "Add to route")}
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleFavorite(p.id)}
                      className="flex h-10 w-10 items-center justify-center rounded-lg text-red-500 transition-all hover:bg-gray-100"
                      aria-label={ui(language, "Favorilerden çıkar", "Remove from favorites")}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Center: Custom Route Planner */}
        <div className="lg:col-span-2 space-y-4">
          <div className={`flex justify-between items-center border-b pb-2 border-line`}>
            <h3 className={`font-serif font-bold text-sm tracking-wider uppercase flex items-center gap-1.5 text-brand-ink`}>
              <Compass className="w-4 h-4 text-accent" />
              {ui(language, "ÖZEL ROTA PLANLAYICIM", "MY CUSTOM ROUTE PLANNER")}
            </h3>
            {customRoute.length > 0 && (
              <button
                onClick={clearRoute}
                className="text-[10px] text-red-500 hover:underline font-bold cursor-pointer"
              >
                {ui(language, "Rotayı sıfırla", "Reset route")}
              </button>
            )}
          </div>

          {favoritePlaces.length > 0 && customRoute.length === 0 && (
            <button
              onClick={importFavoritesToRoute}
              className="w-full rounded-xl border border-accent/35 bg-accent/10 px-4 py-3 text-xs font-bold text-brand-ink transition-colors hover:bg-accent/15"
            >
              {ui(language, "Favorilerimi rotaya aktar", "Import favorites as a route")}
            </button>
          )}

          {customRoute.length === 0 ? (
            <div className={`border p-8 rounded-2xl text-center space-y-3 shadow-sm bg-soft border-line`}>
              <Compass className="w-10 h-10 text-[#999999] mx-auto" />
              <p className={`text-xs font-medium max-w-md mx-auto leading-relaxed text-ink`}>
                {ui(language, "Kendi {city} rotanızı oluşturun. Favorilerinizin yanındaki artı simgesiyle durak ekleyebilirsiniz.", "Build your own {city} route. Use the plus icon beside a saved place to add a stop.", { city: cityName })}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Route Summary Box */}
              <div className={`border p-4 rounded-xl flex justify-between items-center shadow-sm bg-brand/5 border-brand/25`}>
                <div className="space-y-1 text-xs">
                  {customRoutePlaces.length === 1 ? (
                    <p className={`font-bold text-brand-ink`}>
                      {ui(language, "Tek destinasyon seçildi; rota mesafesi hesaplanmaz.", "One destination selected; route distance is not calculated.")}
                    </p>
                  ) : routeMetricsLoading ? (
                    <p className="flex items-center gap-2 font-bold text-brand-ink" role="status">
                      <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-accent border-t-brand" />
                      {ui(language, "Gerçek yürüyüş rotası hesaplanıyor…", "Calculating the real walking route…")}
                    </p>
                  ) : routeMetricsError || !routeMetrics ? (
                    <p className="font-bold text-amber-700" role="status">
                      {ui(language, "Rota hesaplanamadı. Uygulama haritasında veya Google Haritalar’da yeniden deneyebilirsiniz.", "The route could not be calculated. Try again in the app map or Google Maps.")}
                    </p>
                  ) : (
                    <>
                      <div className="flex flex-wrap gap-x-4 gap-y-1">
                        <span className={`font-bold text-brand-ink`}>
                          {ui(language, "Toplam Yürüyüş Mesafesi", "Total Walking Distance")}: {routeMetrics.distanceKm} km
                        </span>
                        <span className={`font-bold text-ink`}>
                          {ui(language, "Yürüyüş Süresi", "Walking Duration")}: {routeMetrics.durationMinutes} {ui(language, "dk", "mins")}
                        </span>
                      </div>
                      <p className="text-[10px] text-[#999999] font-medium">
                        {ui(language, "Seçtiğiniz durak sırasına göre gerçek yaya güzergâhı kullanılmıştır.", "A real walking route is used in the selected stop order.")}
                      </p>
                    </>
                  )}
                </div>

              </div>

              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {customRoutePlaces.length > 2 && (
                  <button
                    type="button"
                    onClick={optimizeOrder}
                    className="flex min-h-11 items-center justify-center gap-2 rounded-xl border border-line bg-soft px-4 py-3 text-xs font-bold text-brand-ink sm:col-span-2"
                  >
                    <Shuffle className="h-4 w-4" />
                    {ui(language, "En kısa yürüyüş sırasına diz", "Order for the shortest walk")}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onShowRouteOnMap(customRoute)}
                  className="flex items-center justify-center gap-2 rounded-xl bg-brand px-4 py-3 text-xs font-bold text-white"
                >
                  <MapPin className="h-4 w-4" />
                  {ui(language, "Rotayı uygulama haritasında aç", "Open in app map")}
                </button>
                <button
                  onClick={openRouteInGoogleMaps}
                  className="flex items-center justify-center gap-2 rounded-xl border border-accent px-4 py-3 text-xs font-bold text-brand-ink"
                >
                  <Compass className="h-4 w-4" />
                  {ui(language, "Google Haritalar’da aç", "Open in Google Maps")}
                </button>
              </div>

              {/* Timeline stop-by-stop list */}
              <div className="plan-timeline relative space-y-4 ps-9 before:absolute before:bottom-2 before:start-[11px] before:top-2 before:w-0.5 before:bg-brand/35">
                {customRoute.map((id, index) => {
                  const rPlace = places.find((pl) => pl.id === id);
                  if (!rPlace) return null;
                  return (
                    <div key={id} className="relative flex items-center justify-between gap-2 rounded-xl border border-line bg-card p-3 shadow-sm transition-all hover:border-accent/40">
                      {/* Timeline Dot with number */}
                      <div className="plan-timeline-dot absolute -start-9 top-1/2 z-10 flex h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full border-2 border-accent bg-brand text-[9px] font-bold text-white shadow-sm">
                        {index + 1}
                      </div>

                      <div className="flex min-w-0 flex-1 items-center gap-3">
                        {/* Tiny image */}
                        <PlacePhoto
                          place={rPlace}
                          language={language}
                          compact
                          className="h-10 w-10 shrink-0 rounded-md border border-line object-cover"
                        />
                        <div className="min-w-0 text-start">
                          <button
                            type="button"
                            onClick={() => onSelectPlace(rPlace)}
                            className="block w-full truncate text-start font-serif text-xs font-bold text-ink hover:text-brand-ink"
                          >
                            {placeName(rPlace, language)}
                          </button>
                          <div className="flex gap-2 text-[9px] text-[#999999] font-semibold mt-0.5">
                            <span className={`uppercase tracking-wider font-bold text-brand-ink`}>{categoryLabel(rPlace.kategori, language)}</span>
                            <span>•</span>
                            <span className="whitespace-nowrap">
                              {rPlace.ziyaret_suresi_dk > 0
                                ? `${rPlace.ziyaret_suresi_dk} ${ui(language, "dk", "mins")}`
                                : (ui(language, "Esnek süre", "Flexible"))}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex shrink-0 items-center gap-0.5">
                        <button
                          type="button"
                          onClick={() => moveStop(index, -1)}
                          disabled={index === 0}
                          className="flex h-9 w-9 items-center justify-center rounded-lg text-brand-ink hover:bg-brand/10 disabled:opacity-25"
                          aria-label={ui(language, "Yukarı taşı", "Move up")}
                        >
                          <ArrowUp className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => moveStop(index, 1)}
                          disabled={index === customRoute.length - 1}
                          className="flex h-9 w-9 items-center justify-center rounded-lg text-brand-ink hover:bg-brand/10 disabled:opacity-25"
                          aria-label={ui(language, "Aşağı taşı", "Move down")}
                        >
                          <ArrowDown className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onShowOnMap(rPlace)}
                          className="flex h-9 items-center px-1.5 text-[10px] font-bold text-brand-ink hover:underline"
                        >
                          {ui(language, "HARİTA", "MAP")}
                        </button>
                        <button
                          type="button"
                          onClick={() => removeFromRoute(id)}
                          className="flex h-9 w-9 items-center justify-center rounded-lg text-red-500 hover:bg-gray-100"
                          aria-label={ui(language, "Rotadan çıkar", "Remove from route")}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Today's Checklist */}
          <div className={`pt-6 border-t space-y-3 border-line`}>
            <h3 className={`font-serif font-bold text-sm tracking-wider uppercase flex items-center gap-1.5 pb-1 text-brand-ink`}>
              <CheckCircle2 className="w-4 h-4 text-accent" />
              {ui(language, "BUGÜNKÜ GEZİ LİSTEM", "TODAY'S VISIT LIST")}
            </h3>

            <div className={`border p-4 rounded-xl space-y-3 shadow-sm bg-soft border-line`}>
              {checklistPlaces.map((p) => {
                const isChecked = checklist.includes(p.id);
                return (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => toggleChecklistItem(p.id)}
                    aria-pressed={isChecked}
                    className="group flex w-full items-center gap-3 text-start cursor-pointer"
                  >
                    {isChecked ? (
                      <CheckSquare className="w-4.5 h-4.5 text-brand-ink fill-brand/10" />
                    ) : (
                      <Square className="w-4.5 h-4.5 text-[#999999] group-hover:text-brand-ink transition-colors" />
                    )}
                    <span className={`text-xs transition-all font-medium ${isChecked ? "text-gray-400 line-through" : "text-ink"}`}>
                      {placeName(p, language)}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
