import { useEffect, useRef, useState, type FormEvent } from "react";
import { Compass, Heart, MapPin, ShieldCheck } from "lucide-react";
import { ui } from "../i18n";
import type { TutorialStep } from "../i18n/tutorial";
import type { Language } from "../types";
import { getStoredRoomNumber, saveStoredRoomNumber } from "../utils/guest";

interface GuestWelcomeProps {
  language: Language;
  hotelName: string;
  cityName: string;
  logoUrl: string;
  askRoomNumber: boolean;
  onDone: () => void;
}

/** First-visit dialog; optionally asks for the room number (kept on this device only). */
export function GuestWelcome({ language, hotelName, cityName, logoUrl, askRoomNumber, onDone }: GuestWelcomeProps) {
  const [roomDraft, setRoomDraft] = useState(getStoredRoomNumber);
  const dialogRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    dialogRef.current?.querySelector<HTMLElement>("input, button")?.focus();
  }, []);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (askRoomNumber) saveStoredRoomNumber(roomDraft);
    onDone();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm">
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="guest-welcome-title"
        className="w-full max-w-md overflow-hidden rounded-[28px] border border-accent/35 bg-soft shadow-2xl"
      >
        <div className="brand-radial relative overflow-hidden px-6 py-7 text-white">
          <img src={logoUrl} alt="" aria-hidden="true" className="absolute -bottom-10 -end-7 h-40 opacity-10" />
          <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-accent-soft">
            {hotelName} · {cityName}
          </span>
          <h2 id="guest-welcome-title" className="relative mt-2 font-serif text-2xl font-bold">
            {ui(language, "Hoş geldiniz", "Welcome")}
          </h2>
          <p className="relative mt-2 max-w-sm text-xs leading-relaxed text-white/80">
            {askRoomNumber
              ? ui(language, "Rehberi konaklamanıza göre kişiselleştirebilir ve resepsiyon mesajlarınıza oda bilginizi otomatik ekleyebiliriz.", "Personalize the guide and automatically include your room in reception messages.")
              : ui(language, "Harita, rotalar ve kişisel planınızla şehri keşfetmeye hazırsınız.", "You are ready to explore the city with the map, routes and your personal plan.")}
          </p>
        </div>
        <form onSubmit={submit} className="space-y-4 p-6">
          {askRoomNumber && (
            <div className="space-y-2">
              <label htmlFor="guest-room" className="text-[10px] font-bold uppercase tracking-widest text-brand-ink">
                {ui(language, "Oda numaranız (isteğe bağlı)", "Your room number (optional)")}
              </label>
              <input
                id="guest-room"
                value={roomDraft}
                onChange={(event) => setRoomDraft(event.target.value)}
                placeholder={ui(language, "Örn. 204", "e.g. 204")}
                maxLength={12}
                autoComplete="off"
                className="w-full rounded-2xl border border-line bg-card px-4 py-3 text-base font-bold text-ink outline-none transition focus:border-accent"
              />
              <p className="flex items-start gap-1.5 text-[10px] leading-relaxed text-[#777777]">
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-accent" />
                {ui(language, "Oda numarası yalnızca bu cihazda saklanır; WhatsApp mesajına siz bağlantıyı açtığınızda eklenir.", "Your room number stays on this device and is added only when you open a WhatsApp message.")}
              </p>
            </div>
          )}
          <div className={`grid grid-cols-1 gap-2 ${askRoomNumber ? "sm:grid-cols-2" : ""}`}>
            <button type="submit" className="min-h-11 rounded-xl bg-brand px-4 py-3 text-xs font-bold text-white shadow-sm">
              {ui(language, "Rehbere Devam Et", "Continue to Guide")}
            </button>
            {askRoomNumber && (
              <button
                type="button"
                onClick={onDone}
                className="min-h-11 rounded-xl border border-line bg-card px-4 py-3 text-xs font-bold text-[#666666]"
              >
                {ui(language, "Şimdilik Atla", "Skip for Now")}
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

interface QuickStartProps {
  language: Language;
  steps: TutorialStep[];
  onClose: (openMap: boolean) => void;
}

/** Three-step introduction shown after the welcome dialog and from Settings. */
export function QuickStart({ language, steps, onClose }: QuickStartProps) {
  const [index, setIndex] = useState(0);
  const step = steps[Math.min(index, steps.length - 1)];
  const Icon = index === 0 ? Compass : index === 1 ? MapPin : Heart;
  const last = index >= steps.length - 1;

  return (
    <div className="pointer-events-none fixed inset-0 z-[90] flex items-end justify-center p-3 pb-[calc(5.25rem+env(safe-area-inset-bottom))] md:items-center md:pb-3">
      <div
        role="dialog"
        aria-modal="false"
        aria-labelledby="quick-start-title"
        className="pointer-events-auto w-full max-w-sm overflow-hidden rounded-2xl border border-accent/60 bg-white text-ink shadow-[0_18px_60px_rgba(0,0,0,0.3)]"
      >
        <div className="brand-tutorial flex items-center gap-3 px-4 py-3 text-white">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10">
            <Icon className="h-4 w-4 text-accent-soft" />
          </span>
          <div className="min-w-0 flex-1">
            <span className="block text-[8px] font-bold uppercase tracking-[0.2em] text-accent-soft">
              {ui(language, "Kısa Başlangıç Rehberi", "Quick Start Guide")}
            </span>
            <span className="mt-0.5 block text-xs font-bold">
              {index + 1}/{steps.length}
            </span>
          </div>
          <button
            type="button"
            onClick={() => onClose(false)}
            className="min-h-11 rounded-lg px-3 py-2 text-[10px] font-bold text-white/80 hover:bg-white/10 hover:text-white"
          >
            {ui(language, "Atla", "Skip")}
          </button>
        </div>
        <div className="px-4 py-3.5">
          <h3 id="quick-start-title" className="font-serif text-base font-bold text-brand-ink">{step.title}</h3>
          <p className="mt-1.5 text-[11px] leading-relaxed text-[#666666]">{step.text}</p>
          <div className="mt-4 flex items-center gap-2">
            {index > 0 && (
              <button
                type="button"
                onClick={() => setIndex((value) => Math.max(0, value - 1))}
                className="min-h-11 rounded-xl border border-brand/20 px-4 py-2.5 text-[10px] font-bold text-brand-ink"
              >
                {ui(language, "Geri", "Back")}
              </button>
            )}
            <button
              type="button"
              onClick={() => (last ? onClose(true) : setIndex((value) => value + 1))}
              className="min-h-11 flex-1 rounded-xl bg-brand px-4 py-2.5 text-[10px] font-bold text-white shadow-sm"
            >
              {last ? ui(language, "Keşfetmeye Başla", "Start Exploring") : ui(language, "Devam", "Next")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

interface ContextTipProps {
  language: Language;
  kind: "MAP" | "PERSONAL";
  onDismiss: () => void;
}

export function ContextTip({ language, kind, onDismiss }: ContextTipProps) {
  return (
    <div className="fixed inset-x-3 bottom-[calc(82px+env(safe-area-inset-bottom))] z-[55] mx-auto max-w-md rounded-2xl border border-accent/50 bg-brand-deep p-3 text-white shadow-xl md:bottom-6" role="status">
      <div className="flex items-start gap-3">
        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-white/10 text-accent-soft">
          {kind === "MAP" ? <MapPin className="h-4 w-4" /> : <Heart className="h-4 w-4" />}
        </span>
        <p className="flex-1 text-[11px] leading-relaxed text-white/90">
          {kind === "MAP"
            ? ui(language, "İşaretçiye dokunarak ayrıntıları ve yürüyüş rotasını görün.", "Tap a marker to see details and a walking route.")
            : ui(language, "Kalp simgesiyle kaydettiğiniz yerleri sıralayıp gerçek bir yürüyüş rotasına dönüştürebilirsiniz.", "Arrange saved places and turn them into a real walking route.")}
        </p>
        <button
          type="button"
          onClick={onDismiss}
          className="min-h-11 rounded-lg bg-white/10 px-3 py-2 text-[10px] font-bold text-accent-soft"
        >
          {ui(language, "Anladım", "Got it")}
        </button>
      </div>
    </div>
  );
}
