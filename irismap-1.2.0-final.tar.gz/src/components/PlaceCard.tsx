import { ui } from "../i18n";
import { categoryLabel, placeName } from "../i18n/content";
import type { Language, Place } from "../types";
import { placeCardDescription } from "../utils/placeText";
import PlacePhoto from "./PlacePhoto";

interface PlaceCardProps {
  place: Place;
  language: Language;
  onShowOnMap: (place: Place) => void;
  onSelect: (place: Place) => void;
  compact?: boolean;
}

export default function PlaceCard({ place, language, onShowOnMap, onSelect, compact = false }: PlaceCardProps) {
  const name = placeName(place, language);
  return (
    <article className="flex flex-col justify-between overflow-hidden rounded-2xl border border-line bg-soft shadow-sm transition-all hover:border-accent">
      <div className={`relative bg-brand-deep ${compact ? "h-[130px]" : "h-[150px]"}`}>
        <PlacePhoto place={place} language={language} alt={name} className="h-full w-full object-cover opacity-90" />
        <span className="absolute start-3 top-3 rounded border border-accent/20 bg-brand px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-widest text-white">
          {categoryLabel(place.kategori, language)}
        </span>
      </div>
      <div className={`flex flex-1 flex-col justify-between p-4 text-start ${compact ? "space-y-3" : "space-y-4"}`}>
        <div className="space-y-1.5">
          <h3 className={`font-serif font-bold leading-tight ${compact ? "text-xs" : "text-sm"}`}>{name}</h3>
          <p className={`line-clamp-3 leading-relaxed ${compact ? "text-[11px] font-medium text-[#666666]" : "text-xs text-ink"}`}>
            {placeCardDescription(place, language)}
          </p>
        </div>
        <div className="flex items-center justify-between border-t border-accent/15 pt-2 text-xs">
          <button
            type="button"
            onClick={() => onShowOnMap(place)}
            className="min-h-11 px-1 font-bold text-accent hover:underline"
          >
            {ui(language, "Haritada Gör", "Show Map")}
          </button>
          <button
            type="button"
            onClick={() => onSelect(place)}
            className="min-h-11 rounded-lg border border-accent/20 bg-brand px-3 py-2 text-[10px] font-bold uppercase tracking-wider text-white"
          >
            {ui(language, "Detayları Gör", "Explore Detail")}
          </button>
        </div>
      </div>
    </article>
  );
}
