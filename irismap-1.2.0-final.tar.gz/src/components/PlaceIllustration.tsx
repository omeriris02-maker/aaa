import type { JSX } from "react";
import type { Place } from "../types";

/*
 * Illustrated scene for a place without a usable photo. Each category has its
 * own silhouette (mosque, madrasa portal, kümbet, museum, ancient mound,
 * caravanserai, park) drawn in the hotel's palette, so a missing photo looks
 * designed rather than broken. The scene varies slightly by place.
 */

const C = {
  deep: "var(--im-primary-deep)",
  primary: "var(--im-primary)",
  accent: "var(--im-accent)",
  accentSoft: "var(--im-accent-soft)",
  page: "var(--im-page)",
  skyTop: "color-mix(in oklab, var(--im-accent-soft) 55%, var(--im-page))",
  skyBottom: "color-mix(in oklab, var(--im-primary) 10%, var(--im-page))",
  hill: "color-mix(in oklab, var(--im-primary) 22%, var(--im-page))",
  hillFar: "color-mix(in oklab, var(--im-primary) 12%, var(--im-page))",
};

const fill = (color: string, opacity?: number) => ({ fill: color, ...(opacity === undefined ? {} : { fillOpacity: opacity }) });

function Mosque() {
  return (
    <g>
      <rect x="118" y="182" width="164" height="40" style={fill(C.deep)} />
      <path d="M128 182 a24 24 0 0 1 48 0 Z M224 182 a24 24 0 0 1 48 0 Z" style={fill(C.deep)} />
      <rect x="160" y="160" width="80" height="24" style={fill(C.deep)} />
      <path d="M160 160 a40 40 0 0 1 80 0 Z" style={fill(C.deep)} />
      <path d="M198 120 h4 v-10 h-4 Z" style={fill(C.accent)} />
      <circle cx="200" cy="106" r="4" style={fill(C.accent)} />
      <rect x="296" y="96" width="12" height="126" style={fill(C.deep)} />
      <rect x="291" y="128" width="22" height="5" rx="2" style={fill(C.accent)} />
      <path d="M296 96 L302 66 L308 96 Z" style={fill(C.deep)} />
      <path d="M186 222 v-22 a14 14 0 0 1 28 0 v22 Z" style={fill(C.accent, 0.85)} />
    </g>
  );
}

function Madrasa() {
  return (
    <g>
      <rect x="92" y="166" width="216" height="56" style={fill(C.deep)} />
      <path d="M252 166 a26 26 0 0 1 52 0 Z" style={fill(C.deep)} />
      <rect x="160" y="112" width="80" height="110" style={fill(C.deep)} />
      <path d="M160 112 h80 v8 h-80 Z" style={fill(C.accent)} />
      <path d="M176 222 v-58 q24 -40 48 0 v58 Z" style={fill(C.accent, 0.85)} />
      <path d="M186 222 v-50 q14 -24 28 0 v50 Z" style={fill(C.deep, 0.55)} />
      <g style={fill(C.accent, 0.7)}>
        {[100, 118, 136, 254, 272, 290].map((x) => <rect key={x} x={x} y="180" width="8" height="14" rx="4" />)}
      </g>
    </g>
  );
}

function Tomb() {
  return (
    <g>
      <rect x="164" y="132" width="72" height="90" style={fill(C.deep)} />
      <path d="M156 134 L200 64 L244 134 Z" style={fill(C.deep)} />
      <path d="M164 132 h72 v6 h-72 Z" style={fill(C.accent)} />
      <path d="M188 222 v-30 a12 12 0 0 1 24 0 v30 Z" style={fill(C.accent, 0.85)} />
      <path d="M176 172 v-14 a5 5 0 0 1 10 0 v14 Z M214 172 v-14 a5 5 0 0 1 10 0 v14 Z" style={fill(C.accent, 0.6)} />
      <rect x="150" y="214" width="100" height="8" style={fill(C.deep)} />
    </g>
  );
}

function Museum() {
  return (
    <g>
      <path d="M96 132 L200 92 L304 132 Z" style={fill(C.deep)} />
      <rect x="104" y="132" width="192" height="10" style={fill(C.accent)} />
      <g style={fill(C.deep)}>
        {[116, 146, 176, 210, 240, 270].map((x) => <rect key={x} x={x} y="146" width="14" height="60" />)}
      </g>
      <rect x="98" y="206" width="204" height="8" style={fill(C.deep)} />
      <rect x="90" y="214" width="220" height="8" style={fill(C.deep)} />
      <circle cx="200" cy="118" r="7" style={fill(C.accent)} />
    </g>
  );
}

function Ancient() {
  return (
    <g>
      <path d="M40 222 Q120 150 200 148 Q290 146 360 222 Z" style={fill(C.deep, 0.92)} />
      <g style={fill(C.accent, 0.85)}>
        <rect x="140" y="166" width="34" height="22" />
        <rect x="178" y="158" width="44" height="30" />
        <rect x="226" y="166" width="34" height="22" />
        <rect x="160" y="192" width="40" height="18" />
        <rect x="204" y="192" width="40" height="18" />
      </g>
      <g style={fill(C.deep)}>
        <rect x="194" y="166" width="12" height="12" />
        <rect x="150" y="172" width="8" height="8" />
        <rect x="240" y="172" width="8" height="8" />
      </g>
      <path d="M262 150 l10 -28 M270 150 l10 -28 M265 142 h9 M268 134 h9" style={{ stroke: C.accent, strokeWidth: 2.5, fill: "none" }} />
    </g>
  );
}

function Caravanserai() {
  return (
    <g>
      <rect x="70" y="160" width="260" height="62" style={fill(C.deep)} />
      <g style={fill(C.deep)}>
        {Array.from({ length: 13 }, (_, index) => <rect key={index} x={72 + index * 20} y="150" width="12" height="12" />)}
      </g>
      <rect x="60" y="140" width="30" height="82" style={fill(C.deep)} />
      <rect x="310" y="140" width="30" height="82" style={fill(C.deep)} />
      <rect x="166" y="126" width="68" height="96" style={fill(C.deep)} />
      <path d="M166 126 h68 v7 h-68 Z" style={fill(C.accent)} />
      <path d="M180 222 v-48 q20 -34 40 0 v48 Z" style={fill(C.accent, 0.85)} />
      <g style={fill(C.accent, 0.65)}>
        {[100, 128, 260, 288].map((x) => <rect key={x} x={x} y="182" width="6" height="18" rx="3" />)}
      </g>
    </g>
  );
}

function Park() {
  return (
    <g>
      <ellipse cx="236" cy="214" rx="120" ry="14" style={fill(C.accentSoft, 0.9)} />
      <g style={fill(C.deep)}>
        <rect x="96" y="176" width="6" height="40" />
        <rect x="140" y="186" width="5" height="30" />
        <rect x="318" y="182" width="5" height="34" />
      </g>
      <circle cx="99" cy="164" r="26" style={fill(C.deep)} />
      <circle cx="142" cy="178" r="18" style={fill(C.primary)} />
      <circle cx="320" cy="170" r="20" style={fill(C.deep, 0.9)} />
      <path d="M210 190 q12 -10 24 0 q12 -10 24 0" style={{ stroke: C.page, strokeWidth: 2.5, fill: "none", strokeLinecap: "round" }} />
    </g>
  );
}

function Hotel() {
  return (
    <g>
      <rect x="150" y="96" width="100" height="126" style={fill(C.deep)} />
      <g style={fill(C.accent, 0.85)}>
        {[0, 1, 2, 3].flatMap((row) => [0, 1, 2].map((column) => (
          <rect key={`${row}-${column}`} x={164 + column * 26} y={110 + row * 24} width="14" height="12" rx="2" />
        )))}
      </g>
      <path d="M186 222 v-20 h28 v20 Z" style={fill(C.accent)} />
    </g>
  );
}

function Monument() {
  return (
    <g>
      <rect x="126" y="176" width="148" height="46" style={fill(C.deep)} />
      <path d="M134 176 a20 20 0 0 1 40 0 Z M226 176 a20 20 0 0 1 40 0 Z" style={fill(C.deep)} />
      <rect x="176" y="128" width="48" height="50" style={fill(C.deep)} />
      <path d="M172 130 L200 62 L228 130 Z" style={fill(C.primary)} />
      <path d="M186 130 L200 62 M200 130 L200 62 M214 130 L200 62" style={{ stroke: C.deep, strokeWidth: 2, opacity: 0.5 }} />
      <path d="M200 62 v-10" style={{ stroke: C.accent, strokeWidth: 3 }} />
      <circle cx="200" cy="48" r="4" style={fill(C.accent)} />
      <path d="M190 222 v-26 a10 10 0 0 1 20 0 v26 Z" style={fill(C.accent, 0.85)} />
    </g>
  );
}

function Bridge() {
  return (
    <g>
      <rect x="0" y="200" width="400" height="22" style={fill(C.accentSoft, 0.85)} />
      <path d="M40 176 H360 V188 H330 a40 40 0 0 0 -80 0 H230 a30 30 0 0 0 -60 0 H150 a40 40 0 0 0 -80 0 H40 Z" style={fill(C.deep)} />
      <path d="M40 176 H360 v-6 H40 Z" style={fill(C.accent)} />
      <path d="M90 206 q10 -6 20 0 M260 206 q10 -6 20 0" style={{ stroke: C.page, strokeWidth: 2, fill: "none", strokeLinecap: "round" }} />
    </g>
  );
}

function Bath() {
  return (
    <g>
      <rect x="96" y="176" width="208" height="46" style={fill(C.deep)} />
      <path d="M110 176 a34 34 0 0 1 68 0 Z M186 176 a44 44 0 0 1 88 0 Z" style={fill(C.deep)} />
      <path d="M270 176 a18 18 0 0 1 36 0 Z" style={fill(C.deep)} />
      <g style={fill(C.accentSoft, 0.9)}>
        {[[214, 152], [230, 146], [246, 152], [222, 162], [238, 162], [134, 160], [150, 156], [142, 168]].map(([x, y]) => <circle key={`${x}-${y}`} cx={x} cy={y} r="2.6" />)}
      </g>
      <path d="M188 222 v-24 a12 12 0 0 1 24 0 v24 Z" style={fill(C.accent, 0.85)} />
    </g>
  );
}

function Church() {
  return (
    <g>
      <rect x="130" y="160" width="140" height="62" style={fill(C.deep)} />
      <path d="M124 162 L200 120 L276 162 Z" style={fill(C.deep)} />
      <rect x="182" y="96" width="36" height="40" style={fill(C.deep)} />
      <path d="M182 98 a18 18 0 0 1 36 0 Z" style={fill(C.primary)} />
      <path d="M200 70 v14 M194 76 h12" style={{ stroke: C.accent, strokeWidth: 3 }} />
      <path d="M188 222 v-30 a12 12 0 0 1 24 0 v30 Z" style={fill(C.accent, 0.85)} />
      <path d="M150 196 v-16 a6 6 0 0 1 12 0 v16 Z M238 196 v-16 a6 6 0 0 1 12 0 v16 Z" style={fill(C.accent, 0.6)} />
    </g>
  );
}

const SCENES: Record<Place["kategori"], () => JSX.Element> = {
  Cami: Mosque,
  Medrese: Madrasa,
  Türbe: Tomb,
  Müze: Museum,
  UNESCO: Monument,
  "Tarihi Yapı": Caravanserai,
  Park,
  Otel: Hotel,
};

/** The name says more than the category for some places (a cave filed as a park, a bridge as a historic building). */
const NAME_SCENES: Array<[RegExp, () => JSX.Element]> = [
  [/höyük|antik|kabartma|anıtı|isaura/i, Ancient],
  [/köprü/i, Bridge],
  [/hamam|kaplıca/i, Bath],
  [/kilise/i, Church],
  [/mağara|obruk|göl|plaj|vadi|bahçe|tabiat|bağları|şelale|dağ/i, Park],
];

function sceneFor(place: Pick<Place, "kategori" | "isim_tr">) {
  const byName = NAME_SCENES.find(([pattern]) => pattern.test(place.isim_tr ?? ""));
  return byName?.[1] ?? SCENES[place.kategori] ?? Caravanserai;
}

/** Eight-pointed Seljuk star, used as a faint ornament. */
const STAR = "M0 -12 L3.5 -8.5 L8.5 -8.5 L8.5 -3.5 L12 0 L8.5 3.5 L8.5 8.5 L3.5 8.5 L0 12 L-3.5 8.5 L-8.5 8.5 L-8.5 3.5 L-12 0 L-8.5 -3.5 L-8.5 -8.5 L-3.5 -8.5 Z";

interface PlaceIllustrationProps {
  place: Pick<Place, "id" | "kategori" | "isim_tr">;
  className?: string;
  label?: string;
}

export default function PlaceIllustration({ place, className = "", label }: PlaceIllustrationProps) {
  const Scene = sceneFor(place);
  const seed = Math.abs(place.id * 9301 + 49297) % 233280;
  const sunX = 60 + (seed % 280);
  const sunY = 54 + (seed % 30);
  const hillShift = (seed % 60) - 30;
  const gradientId = `im-sky-${place.id}`;
  return (
    <svg
      viewBox="0 0 400 260"
      preserveAspectRatio="xMidYMid slice"
      className={className}
      role="img"
      aria-label={label}
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" style={{ stopColor: C.skyTop }} />
          <stop offset="100%" style={{ stopColor: C.skyBottom }} />
        </linearGradient>
      </defs>
      <rect width="400" height="260" fill={`url(#${gradientId})`} />
      <circle cx={sunX} cy={sunY} r="22" style={fill(C.accentSoft, 0.9)} />
      <g transform="translate(40 40)" style={fill(C.accent, 0.12)}><path d={STAR} /></g>
      <g transform="translate(360 220)" style={fill(C.page, 0.18)}><path d={STAR} /></g>
      <path d={`M0 ${200 + hillShift / 3} Q${110 + hillShift} 150 220 190 T400 176 V260 H0 Z`} style={fill(C.hillFar)} />
      <path d={`M0 214 Q${140 - hillShift} 186 260 206 T400 200 V260 H0 Z`} style={fill(C.hill)} />
      <Scene />
      <rect y="222" width="400" height="38" style={fill(C.deep)} />
      <rect y="222" width="400" height="3" style={fill(C.accent, 0.8)} />
    </svg>
  );
}
