import { useEffect, useRef, type RefObject } from "react";
import { Check, ChevronDown, Globe2, X } from "lucide-react";
import { isRtlLanguage, LANGUAGE_LABELS, ui } from "../i18n";
import type { Language } from "../types";

interface LanguageMenuProps {
  language: Language;
  languages: Language[];
  open: boolean;
  onToggle: () => void;
  onClose: () => void;
  onSelect: (language: Language) => void;
  containerRef: RefObject<HTMLDivElement | null>;
}

export default function LanguageMenu({
  language,
  languages,
  open,
  onToggle,
  onClose,
  onSelect,
  containerRef,
}: LanguageMenuProps) {
  const rtl = isRtlLanguage(language);
  const selectedRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    if (open) selectedRef.current?.focus();
  }, [open]);

  if (languages.length < 2) return null;

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        aria-haspopup="dialog"
        aria-label={ui(language, "Dil seçin", "Choose language")}
        className="flex min-h-11 items-center gap-2 rounded-xl border border-line bg-card px-3 text-xs font-bold text-brand-ink shadow-sm transition-colors hover:bg-soft"
      >
        <Globe2 className="h-4 w-4" />
        <span>{language}</span>
        <ChevronDown className={`h-3.5 w-3.5 transition-transform ${open ? "rotate-180" : ""}`} />
      </button>

      {open && (
        <>
          <button
            type="button"
            tabIndex={-1}
            className="fixed inset-0 z-[70] bg-black/30 md:hidden"
            onClick={onClose}
            aria-label={ui(language, "Dil menüsünü kapat", "Close language menu")}
          />
          <section
            role="dialog"
            aria-modal="true"
            aria-label={ui(language, "Dil seçin", "Choose language")}
            dir={rtl ? "rtl" : "ltr"}
            className="fixed inset-x-0 bottom-0 z-[71] rounded-t-3xl border-t border-line bg-card p-4 pb-[max(1rem,env(safe-area-inset-bottom))] shadow-2xl md:absolute md:inset-x-auto md:bottom-auto md:start-0 md:top-[calc(100%+0.5rem)] md:z-50 md:w-56 md:rounded-2xl md:border md:p-3"
          >
            <div className="mb-2 flex items-center justify-between gap-3 px-1">
              <h2 className="text-sm font-bold text-ink">{ui(language, "Dil seçin", "Choose language")}</h2>
              <button
                type="button"
                onClick={onClose}
                className="flex h-11 w-11 items-center justify-center rounded-xl text-[#666666] hover:bg-black/5"
                aria-label={ui(language, "Kapat", "Close")}
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <div className="grid gap-1">
              {languages.map((option) => {
                const selected = option === language;
                return (
                  <button
                    key={option}
                    ref={selected ? selectedRef : undefined}
                    type="button"
                    lang={option.toLowerCase()}
                    aria-pressed={selected}
                    onClick={() => onSelect(option)}
                    className={`flex min-h-11 w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm transition-colors ${
                      selected ? "bg-brand font-bold text-white" : "text-ink hover:bg-soft"
                    }`}
                  >
                    <span>{LANGUAGE_LABELS[option]}</span>
                    <span className="flex items-center gap-2">
                      <span className="text-[10px] font-bold opacity-70">{option}</span>
                      {selected && <Check className="h-4 w-4" />}
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        </>
      )}
    </div>
  );
}
