import { useEffect, useState } from "react";
import { PhotoItem, Language, Place } from "../types";
import { categoryLabel, placeName as getLocalizedPlaceName } from "../i18n/content";
import PlaceIllustration from "./PlaceIllustration";

/** The place's checked photos (see placePhotos in data.ts); empty when it has none. */
export function getPlaceStructuredPhotos(place: Place): PhotoItem[] {
  return Array.isArray(place.fotograf) ? place.fotograf : [];
}

interface PlacePhotoProps {
  place: Place;
  className?: string;
  alt?: string;
  photoIndex?: number;
  language?: Language;
  photos?: PhotoItem[];
  /** Small thumbnails show only the category icon when no photo is available. */
  compact?: boolean;
}

export default function PlacePhoto({
  place,
  className = "",
  alt,
  photoIndex = 0,
  language = "TR",
  photos: suppliedPhotos,
  compact = false,
}: PlacePhotoProps) {
  const photos = suppliedPhotos || getPlaceStructuredPhotos(place);
  
  const [resolvedIndex, setResolvedIndex] = useState(photoIndex);
  const [hasFailedAll, setHasFailedAll] = useState(false);
  const [usingFallback, setUsingFallback] = useState(false);

  useEffect(() => {
    setResolvedIndex(photoIndex);
    setHasFailedAll(false);
    setUsingFallback(false);
  }, [place.id, photoIndex]);

  useEffect(() => {
    if (photos.length === 0) {
      setHasFailedAll(true);
    } else if (resolvedIndex >= photos.length) {
      setHasFailedAll(true);
    } else {
      setHasFailedAll(false);
    }
  }, [resolvedIndex, photos.length]);

  const placeName = getLocalizedPlaceName(place, language);

  const currentPhoto = photos[resolvedIndex] || photos[0];

  if (hasFailedAll || photos.length === 0 || !currentPhoto) {
    if (compact) {
      return (
        <div className={`overflow-hidden ${className}`}>
          <PlaceIllustration place={place} label={placeName} className="h-full w-full" />
        </div>
      );
    }
    return (
      <div className={`relative overflow-hidden select-none ${className}`}>
        <PlaceIllustration place={place} label={`${placeName} · ${categoryLabel(place.kategori, language)}`} className="absolute inset-0 h-full w-full" />
      </div>
    );
  }

  return (
    <img
      src={usingFallback && currentPhoto.fallbackUrl ? currentPhoto.fallbackUrl : currentPhoto.url}
      alt={alt || placeName}
      referrerPolicy="no-referrer"
      loading="lazy"
      className={`${className}`}
      onError={() => {
        if (!usingFallback && currentPhoto.fallbackUrl) {
          setUsingFallback(true);
          return;
        }
        setUsingFallback(false);
        const nextIndex = resolvedIndex + 1;
        if (nextIndex < photos.length) {
          setResolvedIndex(nextIndex);
        } else {
          setHasFailedAll(true);
        }
      }}
    />
  );
}
