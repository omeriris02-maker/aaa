import { useEffect, useState } from "react";
import { Cloud, CloudDrizzle, CloudFog, CloudLightning, CloudRain, CloudSun, Snowflake, Sun } from "lucide-react";
import type { Language } from "../types";

type Condition = "clear" | "partly-cloudy" | "fog" | "rain" | "snow" | "showers" | "storm" | "cloudy" | "unknown";

interface Weather {
  available: boolean;
  temp: number | null;
  condition: Condition;
}

const LABELS: Record<Exclude<Condition, "unknown">, Record<Language, string>> = {
  clear: { TR: "Açık", EN: "Clear", DE: "Klar", ZH: "晴朗", RU: "Ясно", AR: "صافٍ" },
  "partly-cloudy": { TR: "Parçalı bulutlu", EN: "Partly cloudy", DE: "Teilweise bewölkt", ZH: "多云", RU: "Переменная облачность", AR: "غائم جزئياً" },
  fog: { TR: "Sisli", EN: "Foggy", DE: "Nebelig", ZH: "有雾", RU: "Туман", AR: "ضبابي" },
  rain: { TR: "Yağmurlu", EN: "Rainy", DE: "Regnerisch", ZH: "下雨", RU: "Дождь", AR: "ممطر" },
  snow: { TR: "Karlı", EN: "Snowy", DE: "Schnee", ZH: "下雪", RU: "Снег", AR: "ثلجي" },
  showers: { TR: "Sağanak yağışlı", EN: "Showers", DE: "Regenschauer", ZH: "阵雨", RU: "Ливень", AR: "زخات مطر" },
  storm: { TR: "Gök gürültülü fırtına", EN: "Thunderstorm", DE: "Gewitter", ZH: "雷阵雨", RU: "Гроза", AR: "عاصفة رعدية" },
  cloudy: { TR: "Bulutlu", EN: "Cloudy", DE: "Bewölkt", ZH: "阴天", RU: "Облачно", AR: "غائم" },
};

const ICONS = {
  clear: Sun,
  "partly-cloudy": CloudSun,
  fog: CloudFog,
  rain: CloudRain,
  snow: Snowflake,
  showers: CloudDrizzle,
  storm: CloudLightning,
  cloudy: Cloud,
} as const;

const CACHE_MS = 10 * 60 * 1000;
let cached: { at: number; weather: Weather | null } | null = null;

/** Current weather at the hotel; renders nothing when the service is unavailable. */
export default function WeatherChip({ language, city }: { language: Language; city: string }) {
  const fresh = cached && Date.now() - cached.at < CACHE_MS ? cached : null;
  const [weather, setWeather] = useState<Weather | null>(fresh?.weather ?? null);

  useEffect(() => {
    if (cached && Date.now() - cached.at < CACHE_MS) return;
    const controller = new AbortController();
    fetch("/api/weather", { signal: controller.signal })
      .then((response) => (response.ok ? response.json() : null))
      .then((data: Weather | null) => {
        const usable = data?.available && typeof data.temp === "number" && data.condition !== "unknown" && data.condition in LABELS;
        cached = { at: Date.now(), weather: usable ? data : null };
        if (usable) setWeather(data);
      })
      .catch(() => undefined);
    return () => controller.abort();
  }, []);

  if (!weather || weather.condition === "unknown" || weather.temp === null) return null;
  const Icon = ICONS[weather.condition];
  return (
    <span title="Open-Meteo.com (CC BY 4.0)" className="inline-flex items-center gap-1.5 rounded-full border border-accent/35 bg-white/10 px-3 py-1.5 text-[10px] font-bold text-white/90">
      <Icon className="h-3.5 w-3.5 text-accent-soft" aria-hidden="true" />
      <span dir="auto">
        {city} · <bdi>{weather.temp}°C</bdi> · {LABELS[weather.condition][language]}
      </span>
    </span>
  );
}
