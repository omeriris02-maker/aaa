import { useMemo, useState } from "react";
import { Landmark } from "lucide-react";
import { ui } from "../i18n";
import { categoryLabel } from "../i18n/content";
import type { Language, Place } from "../types";
import PlaceCard from "./PlaceCard";

interface PlacesViewProps {
  places: Place[];
  language: Language;
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
}

const PAGE_SIZE = 24;

export default function PlacesView({ places, language, onSelectPlace, onShowOnMap }: PlacesViewProps) {
  const [category, setCategory] = useState<Place["kategori"] | "ALL">("ALL");
  const [visible, setVisible] = useState(PAGE_SIZE);

  const prioritized = useMemo(
    () => [...places].sort((a, b) => Number(Boolean(b.is_major)) - Number(Boolean(a.is_major))),
    [places],
  );
  const categories = useMemo(
    () => [...new Set(places.map((place) => place.kategori))],
    [places],
  );
  const filtered = category === "ALL" ? prioritized : prioritized.filter((place) => place.kategori === category);

  return (
    <div className="space-y-6 text-start">
      <h2 className="flex items-center gap-2 font-serif text-lg font-bold md:text-xl">
        <Landmark className="h-5 w-5 text-accent" />
        <span>{ui(language, "Gezilecek Yerler", "Historical Places")}</span>
        <span className="text-xs font-semibold text-[#999999]">({filtered.length})</span>
      </h2>

      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1" role="group" aria-label={ui(language, "Kategoriye göre süz", "Filter by category")}>
        {(["ALL", ...categories] as const).map((option) => {
          const selected = option === category;
          return (
            <button
              type="button"
              key={option}
              aria-pressed={selected}
              onClick={() => {
                setCategory(option);
                setVisible(PAGE_SIZE);
              }}
              className={`min-h-10 shrink-0 rounded-full border px-3.5 text-[11px] font-bold transition-colors ${
                selected ? "border-brand bg-brand text-white" : "border-line bg-card text-ink hover:border-accent"
              }`}
            >
              {option === "ALL" ? ui(language, "Tümü", "All") : categoryLabel(option, language)}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.slice(0, visible).map((place) => (
          <PlaceCard key={place.id} place={place} language={language} onSelect={onSelectPlace} onShowOnMap={onShowOnMap} />
        ))}
      </div>

      {visible < filtered.length && (
        <div className="flex justify-center">
          <button
            type="button"
            onClick={() => setVisible((count) => count + PAGE_SIZE)}
            className="min-h-11 rounded-xl border border-accent/40 px-5 py-2.5 text-xs font-bold text-brand-ink hover:bg-accent/10"
          >
            {ui(language, "Daha fazla göster", "Show more")} ({filtered.length - visible})
          </button>
        </div>
      )}
    </div>
  );
}
