import { useMemo, useState, type ComponentType } from "react";
import {
  AlertCircle, Calendar, ChevronRight, Compass, Landmark, Mail, MessageCircle,
  PhoneCall, Search, Sparkles, Star, X,
} from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import { ui } from "../i18n";
import { categoryLabel, placeName } from "../i18n/content";
import { trackEvent } from "../services/analytics";
import type { Language, Place } from "../types";
import { createWhatsAppUrl } from "../utils/guest";
import { placeMatches } from "../utils/placeText";
import type { SubView } from "./AppNavigation";
import PlaceCard from "./PlaceCard";
import WeatherChip from "./WeatherChip";

interface HomeViewProps {
  hotel: HotelConfig;
  hotelName: string;
  cityName: string;
  receptionHours: string;
  language: Language;
  places: Place[];
  logoUrl: string;
  onOpenSubView: (view: SubView) => void;
  onOpenMap: () => void;
  onSelectPlace: (place: Place) => void;
  onShowOnMap: (place: Place) => void;
}

interface ModuleTile {
  id: SubView;
  label: string;
  description: string;
  icon: ComponentType<{ className?: string }>;
}

export default function HomeView({
  hotel, hotelName, cityName, receptionHours, language, places, logoUrl,
  onOpenSubView, onOpenMap, onSelectPlace, onShowOnMap,
}: HomeViewProps) {
  const [query, setQuery] = useState("");
  const results = useMemo(
    () => (query.trim() ? places.filter((place) => placeMatches(place, query)) : []),
    [places, query],
  );
  const { phone, whatsapp, email } = hotel.contact;
  const features = hotel.features;

  const modules: ModuleTile[] = [
    { id: "PLACES", label: ui(language, "Gezilecek Yerler", "Historical Places"), description: ui(language, "Öne çıkan ve keşfedilecek yerler", "Featured places and more to discover"), icon: Landmark },
    { id: "TOURS", label: ui(language, "Hazır Rotalar", "Curated Routes"), description: ui(language, "Hazır gezi planları", "Curated routes"), icon: Compass },
    ...(features.events ? [{ id: "EVENTS" as const, label: ui(language, "Kültür Takvimi", "Culture Calendar"), description: ui(language, "Yaklaşan etkinlikler", "Upcoming events"), icon: Calendar }] : []),
    ...(features.aiGuide ? [{ id: "AI_GUIDE" as const, label: ui(language, "Yapay Zeka Rehberi", "AI Concierge Guide"), description: ui(language, "Sorularınız için dijital asistan", "Digital assistant for your questions"), icon: Sparkles }] : []),
    ...(features.practicalInfo ? [{ id: "PRACTICAL" as const, label: ui(language, "Pratik Bilgiler", "Practical Info"), description: ui(language, "Ziyaret ipuçları", "Visitor tips"), icon: AlertCircle }] : []),
    { id: "HOTEL", label: ui(language, "Otel Bilgileri", "Hotel Information"), description: ui(language, "Otel ve iletişim", "Hotel details"), icon: Star },
  ];

  const receptionMessage = ui(language, "Merhaba, {hotel} resepsiyonundan destek almak istiyorum.", "Hello, I would like assistance from {hotel} reception.", { hotel: hotelName });

  return (
    <div className="space-y-6 text-start">
      {/* Welcome banner */}
      <section className="brand-hero relative overflow-hidden rounded-2xl border border-accent/30 p-4 text-white shadow-md md:px-6 md:py-5">
        <img src={logoUrl} alt="" aria-hidden="true" className="pointer-events-none absolute -bottom-14 -end-10 h-72 w-auto object-contain opacity-[0.09]" />
        <div className="relative grid gap-4 lg:grid-cols-[1fr_auto] lg:items-center">
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-full border border-accent/35 bg-white/10 px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-accent-soft">
                {ui(language, "{hotel} · MİSAFİR REHBERİ", "{hotel} · GUEST GUIDE", { hotel: hotelName })}
              </span>
              {features.weather && <WeatherChip language={language} city={cityName} />}
            </div>
            <h2 className="max-w-2xl font-serif text-xl font-bold leading-tight text-white md:text-2xl">
              {ui(language, "{city} keşfiniz {hotel} ile başlıyor.", "Explore {city} as a guest of {hotel}.", { city: cityName, hotel: hotelName })}
            </h2>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <button
              type="button"
              onClick={onOpenMap}
              className="flex min-h-11 items-center justify-center gap-2 rounded-xl bg-accent px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider text-ink shadow-md transition-all hover:bg-white"
            >
              <Compass className="h-4 w-4" />
              <span>{ui(language, "Keşfetmeye Başla", "Start Exploring")}</span>
              <ChevronRight className="h-4 w-4 rtl:rotate-180" />
            </button>
          </div>
        </div>
      </section>

      {/* Reception card */}
      {(phone || whatsapp || email) && (
        <section className="flex min-h-[132px] items-center rounded-2xl border border-line bg-soft p-5 shadow-sm">
          <div className="w-full space-y-3 text-start">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand text-white shadow-sm">
                <PhoneCall className="h-5 w-5" />
              </span>
              <div className="space-y-0.5">
                <span className="block text-[10px] font-bold uppercase tracking-widest text-[#999999]">
                  {ui(language, "RESEPSİYON / MİSAFİR DESTEĞİ", "RECEPTION / GUEST SUPPORT")}
                </span>
                <span className="block font-serif text-sm font-bold">
                  {ui(language, "{hotel} Misafir Desteği", "{hotel} Guest Support", { hotel: hotelName })}
                </span>
                {receptionHours && <span className="text-[9px] font-semibold text-[#777777]">{receptionHours}</span>}
              </div>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {phone && (
                <a
                  href={`tel:${phone.dial}`}
                  onClick={() => trackEvent("reception_call", { language })}
                  className="flex min-h-11 items-center justify-center gap-1.5 rounded-xl border border-accent/25 px-3 py-2 text-[11px] font-bold text-brand-ink hover:bg-brand/5"
                >
                  <PhoneCall className="h-3.5 w-3.5" />
                  <span>{ui(language, "Resepsiyonu Ara", "Call Reception")}</span>
                </a>
              )}
              {whatsapp && (
                <a
                  href={createWhatsAppUrl(whatsapp.number, receptionMessage, language)}
                  onClick={() => trackEvent("whatsapp_click", { language })}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex min-h-11 items-center justify-center gap-1.5 rounded-xl border border-[#25D366]/20 bg-[#25D366]/10 px-3 py-2 text-[11px] font-bold text-[#198F45] hover:bg-[#25D366]/15"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                  <span>WhatsApp</span>
                </a>
              )}
              {email && !(phone && whatsapp) && (
                <a
                  href={`mailto:${email}`}
                  onClick={() => trackEvent("email_click", { language })}
                  className="flex min-h-11 items-center justify-center gap-1.5 rounded-xl border border-accent/25 px-3 py-2 text-[11px] font-bold text-brand-ink hover:bg-brand/5"
                >
                  <Mail className="h-3.5 w-3.5" />
                  <span>{ui(language, "E-posta Gönder", "Send E-mail")}</span>
                </a>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Search */}
      <section className="space-y-2">
        <h3 className="flex items-center gap-1.5 font-serif text-sm font-bold">
          <Sparkles className="h-4 w-4 text-accent" />
          <label htmlFor="home-search">{ui(language, "Hızlı Mekan Arama", "Search Places & Mosques")}</label>
        </h3>
        <div className="flex max-w-xl items-center gap-2 rounded-xl border border-line bg-soft px-4 py-1.5 shadow-sm">
          <Search className="h-4 w-4 shrink-0 text-accent" aria-hidden="true" />
          <input
            id="home-search"
            type="search"
            enterKeyHint="search"
            autoComplete="off"
            placeholder={ui(language, "Mekân, cami veya müze adı yazın…", "Type a place, mosque or museum name…")}
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            className="min-h-11 w-full border-none bg-transparent text-base font-medium text-ink outline-none placeholder:text-[#999999] md:text-xs"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-[#999999]"
              aria-label={ui(language, "Aramayı temizle", "Clear search")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {query.trim() && (
          <div className="animate-fade-in space-y-2.5 rounded-xl border border-line bg-card p-4 shadow-lg" aria-live="polite">
            <div className="text-[10px] font-bold text-[#999999]">
              {ui(language, "Arama sonuçları", "Search results")}: {results.length}
            </div>
            {results.length === 0 ? (
              <div className="py-1 text-xs font-medium text-[#999999]">
                {ui(language, "Aradığınız kriterde bir mekan bulunamadı.", "No matching places found.")}
              </div>
            ) : (
              <div className="max-h-[220px] space-y-1.5 overflow-y-auto">
                {results.map((place) => (
                  <button
                    type="button"
                    key={place.id}
                    onClick={() => onSelectPlace(place)}
                    className="flex w-full items-center justify-between gap-3 rounded-lg px-3 py-2 text-start transition-colors hover:bg-soft"
                  >
                    <span className="text-xs font-semibold">{placeName(place, language)}</span>
                    <span className="shrink-0 text-[9px] font-bold uppercase tracking-widest text-accent">
                      {categoryLabel(place.kategori, language)}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </section>

      {/* Modules */}
      <section className="space-y-3">
        <h3 className="flex items-center gap-1.5 font-serif text-sm font-bold">
          <Compass className="h-4 w-4 text-accent" />
          <span>{ui(language, "Turizm Keşif Modülleri", "Exclusive Concierge Hub")}</span>
        </h3>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {modules.map((item) => {
            const Icon = item.icon;
            return (
              <button
                type="button"
                key={item.id}
                onClick={() => onOpenSubView(item.id)}
                className="flex h-[115px] flex-col justify-between rounded-xl border border-line bg-soft p-4 text-start shadow-sm transition-all hover:border-accent hover:shadow-md"
              >
                <Icon className="h-5 w-5 text-accent" />
                <span className="block min-w-0 space-y-0.5">
                  <span className="block truncate font-serif text-xs font-bold leading-tight">{item.label}</span>
                  <span className="block truncate text-[10px] font-medium text-[#888888]">{item.description}</span>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Popular places */}
      <section className="space-y-3">
        <div className="flex items-end justify-between">
          <h3 className="flex items-center gap-1.5 font-serif text-sm font-bold">
            <Landmark className="h-4 w-4 text-accent" />
            <span>{ui(language, "Popüler Gezilecek Yerler", "Popular Historical Sites")}</span>
          </h3>
          <button
            type="button"
            onClick={() => onOpenSubView("PLACES")}
            className="flex min-h-11 items-center gap-0.5 px-2 text-xs font-bold text-accent hover:underline"
          >
            {ui(language, "Tümünü Gör", "See All")} <ChevronRight className="h-3.5 w-3.5 rtl:rotate-180" />
          </button>
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {places.slice(0, 3).map((place) => (
            <PlaceCard key={place.id} place={place} language={language} onSelect={onSelectPlace} onShowOnMap={onShowOnMap} compact />
          ))}
        </div>
      </section>
    </div>
  );
}
