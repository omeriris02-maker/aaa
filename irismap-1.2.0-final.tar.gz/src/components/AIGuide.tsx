import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowRight, Bot, Send, Sparkles, Trash2, User } from "lucide-react";
import { formatText } from "../../shared/languages";
import { isRtlLanguage, ui } from "../i18n";
import type { Language } from "../types";

interface Message {
  sender: "user" | "bot";
  text: string;
}

interface AIGuideProps {
  language: Language;
  hotelName: string;
  cityName: string;
}

const WELCOME: Record<Language, string> = {
  TR: "Merhaba! Ben {hotel} dijital misafir asistanıyım. Şehrin tarihi, yerel yemekleri, gezilecek yerleri, ulaşım seçenekleri veya otel hizmetleri hakkında bana soru sorabilirsiniz.",
  EN: "Hello! I am the digital guest assistant of {hotel}. Ask me about {city}'s history, regional dishes, places to visit, transport options or hotel services.",
  DE: "Hallo! Ich bin der digitale Gästeassistent von {hotel}. Fragen Sie mich nach Geschichte, regionaler Küche, Sehenswürdigkeiten und Verkehr in {city} oder nach Hotelleistungen.",
  ZH: "您好！我是{hotel}的数字宾客助手。您可以询问{city}的历史、地方美食、景点、交通或酒店服务。",
  RU: "Здравствуйте! Я цифровой помощник гостей ({hotel}). Спросите меня об истории города, местных блюдах, достопримечательностях, транспорте или услугах отеля.",
  AR: "مرحباً! أنا مساعد الضيوف الرقمي في {hotel}. يمكنكم سؤالي عن تاريخ {city} والأطباق المحلية والأماكن التي تستحق الزيارة ووسائل النقل أو خدمات الفندق.",
};

const PRESETS: Record<Language, string[]> = {
  TR: [
    "Bu şehirde mutlaka görmem gereken yerler neler?",
    "Hangi yöresel yemekleri denemeliyim?",
    "1 günlük gezi planı önerir misin?",
    "Otelin sunduğu hizmetler nelerdir?",
  ],
  EN: [
    "What should I not miss in {city}?",
    "Which regional dishes should I try?",
    "Suggest a 1-day itinerary.",
    "What services does the hotel offer?",
  ],
  DE: [
    "Was sollte ich in {city} nicht verpassen?",
    "Welche regionalen Gerichte sollte ich probieren?",
    "Schlagen Sie einen Tagesplan vor.",
    "Welche Leistungen bietet das Hotel?",
  ],
  ZH: [
    "在{city}有哪些不可错过的地方？",
    "我应该品尝哪些地方美食？",
    "推荐一个一天的游览路线。",
    "酒店提供哪些服务？",
  ],
  RU: [
    "Что обязательно стоит посмотреть в городе?",
    "Какие местные блюда стоит попробовать?",
    "Предложите маршрут на один день.",
    "Какие услуги есть в отеле?",
  ],
  AR: [
    "ما الأماكن التي لا ينبغي أن تفوتني في {city}؟",
    "ما الأطباق المحلية التي يجب أن أجربها؟",
    "اقترح برنامج زيارة ليوم واحد.",
    "ما الخدمات التي يقدمها الفندق؟",
  ],
};

const MAX_QUESTION_LENGTH = 800;

export default function AIGuide({ language, hotelName, cityName }: AIGuideProps) {
  const rtl = isRtlLanguage(language);
  const values = { hotel: hotelName, city: cityName };
  const welcome = formatText(WELCOME[language], values);
  const [messages, setMessages] = useState<Message[]>([{ sender: "bot", text: welcome }]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [guideMode, setGuideMode] = useState<"unknown" | "online" | "offline">("unknown");
  const listRef = useRef<HTMLDivElement | null>(null);
  const requestRef = useRef<AbortController | null>(null);

  useEffect(() => () => requestRef.current?.abort(), []);

  useEffect(() => {
    const list = listRef.current;
    if (list) list.scrollTo({ top: list.scrollHeight, behavior: "smooth" });
  }, [messages, isLoading]);

  // Keep the untouched welcome message in the selected language.
  useEffect(() => {
    setMessages((current) => (current.length === 1 && current[0].sender === "bot" ? [{ sender: "bot", text: welcome }] : current));
  }, [welcome]);

  const send = async (text: string) => {
    const question = text.trim().slice(0, MAX_QUESTION_LENGTH);
    if (!question || isLoading) return;
    const history = messages
      .slice(1)
      .map((message) => ({ role: message.sender === "user" ? "user" : "model", text: message.text }));
    setInput("");
    setMessages((current) => [...current, { sender: "user", text: question }]);
    setIsLoading(true);
    const controller = new AbortController();
    requestRef.current = controller;
    try {
      const response = await fetch("/api/ai-guide", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, language, history }),
        signal: controller.signal,
      });
      if (response.status === 429) {
        setMessages((current) => [...current, {
          sender: "bot",
          text: ui(language, "Çok sık soru gönderildi. Lütfen bir dakika sonra tekrar deneyin.", "Too many questions in a short time. Please try again in a minute."),
        }]);
        return;
      }
      if (!response.ok) throw new Error(`Guide request failed: ${response.status}`);
      const data = await response.json() as { answer?: unknown; mode?: unknown };
      const answer = typeof data.answer === "string" && data.answer.trim() ? data.answer.trim() : null;
      if (!answer) throw new Error("Empty answer");
      setGuideMode(data.mode === "online" ? "online" : "offline");
      setMessages((current) => [...current, { sender: "bot", text: answer }]);
    } catch (error) {
      if ((error as Error).name === "AbortError") return;
      setGuideMode("offline");
      setMessages((current) => [...current, {
        sender: "bot",
        text: ui(language, "Üzgünüm, şu an bağlantı kuramıyorum. Lütfen daha sonra tekrar deneyiniz.", "Apologies, I am experiencing a temporary connection issue. Please try again shortly."),
      }]);
    } finally {
      if (requestRef.current === controller) requestRef.current = null;
      setIsLoading(false);
    }
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    void send(input);
  };

  const clearChat = () => {
    requestRef.current?.abort();
    setIsLoading(false);
    setMessages([{ sender: "bot", text: welcome }]);
  };

  return (
    <div className="flex h-[calc(100dvh-210px)] min-h-[480px] flex-col overflow-hidden rounded-2xl border border-line bg-card shadow-sm">
      <div className="flex shrink-0 items-center justify-between border-b border-line bg-soft px-4 py-3.5">
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-brand/20 bg-brand/10 text-brand-ink shadow-sm">
            <Sparkles className="h-5 w-5" />
          </span>
          <div>
            <h2 className="font-serif text-sm font-bold leading-tight text-brand-ink">
              {ui(language, "{hotel} Dijital Misafir Asistanı", "{hotel} Digital Guest Assistant", values)}
            </h2>
            <p className="text-[10px] font-semibold uppercase tracking-wider text-accent">
              {guideMode === "offline"
                ? ui(language, "Çevrimdışı rehber modu · Temel bilgiler", "Offline guide mode · Basic information")
                : guideMode === "online"
                  ? ui(language, "Dijital misafir asistanı · 7/24", "Digital guest assistant · 24/7")
                  : ui(language, "Bağlantı durumu ilk soruda belirlenir", "Connection status is checked with your first question")}
            </p>
          </div>
        </div>
        {messages.length > 1 && (
          <button
            type="button"
            onClick={clearChat}
            className="flex h-11 w-11 items-center justify-center rounded-full text-[#999999] transition-colors hover:bg-gray-100 hover:text-brand-ink"
            title={ui(language, "Sohbeti temizle", "Clear chat")}
            aria-label={ui(language, "Sohbeti temizle", "Clear chat")}
          >
            <Trash2 className="h-4 w-4" />
          </button>
        )}
      </div>

      <div ref={listRef} className="flex-1 space-y-4 overflow-y-auto bg-card p-4" aria-live="polite">
        {messages.map((message, index) => (
          <div key={index} className={`flex max-w-[85%] gap-3 ${message.sender === "user" ? "ms-auto flex-row-reverse" : "me-auto"}`}>
            <span
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full border shadow-sm ${
                message.sender === "user" ? "border-accent/20 bg-accent/10 text-accent" : "border-brand/20 bg-brand/10 text-brand-ink"
              }`}
              aria-hidden="true"
            >
              {message.sender === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
            </span>
            <div
              dir="auto"
              className={`rounded-2xl p-3 text-xs font-medium leading-relaxed ${
                message.sender === "user"
                  ? "rounded-se-none bg-accent/10 text-ink"
                  : "rounded-ss-none border border-line bg-soft text-ink shadow-sm"
              }`}
            >
              <p className="whitespace-pre-line break-words">{message.text}</p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="me-auto flex max-w-[85%] gap-3" role="status" aria-label={ui(language, "Yanıt hazırlanıyor", "Preparing an answer")}>
            <span className="flex h-8 w-8 items-center justify-center rounded-full border border-brand/20 bg-brand/10 text-brand-ink">
              <Bot className="h-4 w-4" />
            </span>
            <div className="flex items-center gap-1.5 rounded-2xl rounded-ss-none border border-line bg-soft p-3 shadow-sm">
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand [animation-delay:0.2s]" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-brand [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      {messages.length === 1 && (
        <div className="flex shrink-0 flex-wrap justify-center gap-2 border-t border-line bg-soft/50 px-4 py-3">
          {PRESETS[language].map((preset) => {
            const text = formatText(preset, values);
            return (
              <button
                type="button"
                key={preset}
                onClick={() => void send(text)}
                className="flex min-h-11 items-center gap-1 rounded-xl border border-brand/10 bg-brand/5 px-3 py-2 text-[10px] font-bold text-brand-ink transition-all hover:border-brand/20 hover:bg-brand/10"
              >
                <span>{text}</span>
                <ArrowRight className={`h-3 w-3 text-accent ${rtl ? "rotate-180" : ""}`} />
              </button>
            );
          })}
        </div>
      )}

      <form onSubmit={submit} className="flex shrink-0 items-center gap-2 border-t border-line bg-card p-3">
        <input
          type="text"
          aria-label={ui(language, "Şehir veya otel hakkında bir şeyler sorun…", "Ask anything about the city or the hotel…")}
          value={input}
          maxLength={MAX_QUESTION_LENGTH}
          onChange={(event) => setInput(event.target.value)}
          placeholder={ui(language, "Şehir veya otel hakkında bir şeyler sorun…", "Ask anything about the city or the hotel…")}
          className="min-h-11 flex-1 rounded-xl border border-line bg-soft px-4 py-2.5 text-base font-medium text-ink placeholder:text-[#999999] focus:border-brand focus:outline-none md:text-xs"
          disabled={isLoading}
          enterKeyHint="send"
        />
        <button
          type="submit"
          aria-label={ui(language, "Soruyu gönder", "Send question")}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand text-white shadow-sm transition-all hover:opacity-95 disabled:opacity-50"
          disabled={isLoading || !input.trim()}
        >
          <Send className="h-4 w-4 rtl:-scale-x-100" />
        </button>
      </form>
    </div>
  );
}
