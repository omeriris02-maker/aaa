import { useState } from "react";

interface HotelLogoProps {
  src: string;
  alt: string;
  /** Size and shape of the coloured frame, e.g. "h-16 w-11 rounded-xl p-1". */
  frameClassName?: string;
  decorative?: boolean;
}

/** The hotel logo on its frame colour; falls back to the IrisMap mark if the file fails. */
export default function HotelLogo({ src, alt, frameClassName = "h-16 w-11 rounded-xl p-1", decorative = false }: HotelLogoProps) {
  const [failedSrc, setFailedSrc] = useState<string | null>(null);
  const failed = failedSrc === src;
  return (
    <span className={`flex shrink-0 items-center justify-center border border-accent/40 bg-logo-frame shadow-md ${frameClassName}`}>
      <img
        src={failed ? "/irismap.svg" : src}
        onError={() => setFailedSrc(src)}
        alt={decorative ? "" : alt}
        aria-hidden={decorative || undefined}
        className="h-full w-full object-contain"
      />
    </span>
  );
}
