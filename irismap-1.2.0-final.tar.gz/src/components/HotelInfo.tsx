import { CheckCircle2, ConciergeBell, Globe, Mail, MapPin, MessageCircle, Phone, Sparkles, Star } from "lucide-react";
import type { HotelConfig } from "../../shared/hotelConfig";
import type { LocalizedText } from "../../shared/languages";
import { ui } from "../i18n";
import { trackEvent } from "../services/analytics";
import type { Language } from "../types";
import { createWhatsAppUrl, openExternal } from "../utils/guest";
import HotelLogo from "./HotelLogo";

interface HotelInfoProps {
  language: Language;
  hotel: HotelConfig;
  hotelName: string;
  logoUrl: string;
  translate: (text: LocalizedText | undefined) => string;
}

export default function HotelInfo({ language, hotel, hotelName, logoUrl, translate }: HotelInfoProps) {
  const { contact, services } = hotel;
  const tagline = translate(hotel.tagline);
  const about = translate(hotel.about);
  const address = translate(hotel.location.address);

  const book = () => {
    if (contact.bookingUrl) {
      trackEvent("booking_click", { language, module: "hotel_booking" });
      openExternal(contact.bookingUrl);
      return;
    }
    if (contact.whatsapp) {
      const message = ui(
        language,
        "Merhaba! {hotel} misafir rehberinden ulaşıyorum. Rezervasyon yaptırmak istiyorum.",
        "Hello! I am contacting you from the {hotel} guest guide. I would like to make a reservation.",
        { hotel: hotelName },
      );
      trackEvent("whatsapp_click", { language, module: "hotel_booking" });
      openExternal(createWhatsAppUrl(contact.whatsapp.number, message, language));
    }
  };

  const websiteLabel = contact.website ? contact.website.replace(/^https?:\/\/(www\.)?/, "").replace(/\/$/, "") : "";

  return (
    <div className="space-y-6 text-start">
      <section className="space-y-4 rounded-2xl border border-accent/40 bg-soft p-6 text-ink shadow-md">
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
          <div className="space-y-1">
            <div className="mb-2 flex items-center gap-3">
              <HotelLogo src={logoUrl} alt={hotelName} frameClassName="h-20 w-14 rounded-xl p-1" />
              <div>
                <h1 className="font-serif text-lg font-bold uppercase tracking-widest text-brand-ink md:text-xl">{hotelName}</h1>
                {tagline && <p className="text-[10px] font-semibold uppercase tracking-widest text-[#888888]">{tagline}</p>}
              </div>
            </div>
            {hotel.stars && (
              <div className="flex items-center gap-1 text-accent" aria-label={ui(language, "{count} yıldız", "{count} stars", { count: hotel.stars })}>
                {Array.from({ length: hotel.stars }).map((_, index) => (
                  <Star key={index} className="h-3.5 w-3.5 fill-accent stroke-accent" aria-hidden="true" />
                ))}
              </div>
            )}
          </div>

          {hotel.features.booking && (contact.bookingUrl || contact.whatsapp) && (
            <button
              type="button"
              onClick={book}
              className="min-h-11 rounded-xl border border-accent/20 bg-brand px-5 py-3 text-xs font-bold uppercase tracking-wider text-white shadow-sm transition-all hover:opacity-95"
            >
              {ui(language, "REZERVASYON YAP", "BOOK A ROOM")}
            </button>
          )}
        </div>
        {about && <p className="text-xs font-normal leading-relaxed text-ink md:text-sm">{about}</p>}
      </section>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {(services.included.length > 0 || services.onRequest.length > 0) && (
          <section className="space-y-5 rounded-2xl border border-line bg-card p-5 shadow-sm">
            <h3 className="flex items-center gap-1.5 border-b border-line pb-2 font-serif text-sm font-bold uppercase tracking-wider text-brand-ink">
              <Sparkles className="h-4 w-4 text-accent" />
              {ui(language, "MİSAFİR HİZMETLERİMİZ", "GUEST SERVICES")}
            </h3>
            {services.included.length > 0 && (
              <div className="space-y-2.5">
                <h4 className="text-[10px] font-bold uppercase tracking-wider text-[#777777]">
                  {ui(language, "DAHİL OLAN HİZMETLER", "INCLUDED SERVICES")}
                </h4>
                <ul className="grid grid-cols-1 gap-2 text-xs font-medium text-ink sm:grid-cols-2">
                  {services.included.map((service, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-brand-ink" />
                      <span className="text-[11px] leading-tight">{translate(service)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {services.onRequest.length > 0 && (
              <div className="space-y-2.5 border-t border-dashed border-accent/20 pt-3.5">
                <h4 className="text-[10px] font-bold uppercase tracking-wider text-brand-ink">
                  {ui(language, "TALEP ÜZERİNE", "ON REQUEST")}
                </h4>
                <ul className="grid grid-cols-1 gap-2 text-xs font-medium text-ink sm:grid-cols-2">
                  {services.onRequest.map((service, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <ConciergeBell className="h-3.5 w-3.5 shrink-0 text-accent" />
                      <span className="text-[11px] leading-tight">{translate(service)}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>
        )}

        <section className="space-y-3.5 rounded-2xl border border-line bg-card p-5 text-xs font-medium text-ink shadow-sm">
          <h3 className="flex items-center gap-1.5 border-b border-line pb-2 font-serif text-sm font-bold uppercase tracking-wider text-brand-ink">
            <MapPin className="h-4 w-4 text-accent" />
            {ui(language, "İLETİŞİM BİLGİLERİ", "CONTACT & LOCATION")}
          </h3>
          {address && (
            <div className="flex items-start gap-2.5 pt-1">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
              <span>{address}</span>
            </div>
          )}
          {contact.phone && (
            <a
              href={`tel:${contact.phone.dial}`}
              onClick={() => trackEvent("reception_call", { language, module: "hotel" })}
              className="flex min-h-10 items-center gap-2.5 transition-colors hover:text-brand-ink"
            >
              <Phone className="h-4 w-4 shrink-0 text-accent" />
              <span dir="ltr">{contact.phone.display}</span>
            </a>
          )}
          {contact.whatsapp && (
            <a
              href={createWhatsAppUrl(contact.whatsapp.number, ui(language, "Merhaba, {hotel} resepsiyonundan destek almak istiyorum.", "Hello, I would like assistance from {hotel} reception.", { hotel: hotelName }), language)}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackEvent("whatsapp_click", { language, module: "hotel" })}
              className="flex min-h-10 items-center gap-2.5 transition-colors hover:text-brand-ink"
            >
              <MessageCircle className="h-4 w-4 shrink-0 text-[#25D366]" />
              <span dir="ltr">{contact.whatsapp.display}</span>
              <span className="text-[10px] text-[#888888]">({ui(language, "WhatsApp Destek", "WhatsApp Support")})</span>
            </a>
          )}
          {contact.email && (
            <a
              href={`mailto:${contact.email}`}
              onClick={() => trackEvent("email_click", { language, module: "hotel" })}
              className="flex min-h-10 items-center gap-2.5 break-all transition-colors hover:text-brand-ink"
            >
              <Mail className="h-4 w-4 shrink-0 text-accent" />
              <span>{contact.email}</span>
            </a>
          )}
          {contact.website && (
            <a
              href={contact.website}
              target="_blank"
              rel="noopener noreferrer"
              className="flex min-h-10 items-center gap-2.5 break-all transition-colors hover:text-brand-ink"
            >
              <Globe className="h-4 w-4 shrink-0 text-accent" />
              <span>{websiteLabel}</span>
            </a>
          )}
        </section>
      </div>
    </div>
  );
}
