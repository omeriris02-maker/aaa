import { formatText } from "../../shared/languages";
import type { Language } from "../types";

/*
 * Plain-language privacy notice (KVKK / GDPR information) shown in the app.
 * It describes what IrisMap itself does; a hotel can link its own full
 * policy with `privacy.policyUrl` in hotel.json.
 */

interface NoticeText {
  title: string;
  intro: string;
  deviceTitle: string;
  device: string;
  statsTitle: string;
  stats: string;
  locationTitle: string;
  location: string;
  aiTitle: string;
  ai: string;
  servicesTitle: string;
  services: string;
  servicesServerWeather: string;
  servicesServer: string;
  servicesLinks: string;
  rightsTitle: string;
  rights: string;
  email: string;
  policy: string;
}

const TEXT: Record<Language, NoticeText> = {
  TR: {
    title: "Gizlilik ve kişisel veriler",
    intro: "{hotel} misafir rehberini hesap açmadan kullanırsınız. Adınız, telefon numaranız veya e-posta adresiniz istenmez. Aşağıda rehberin hangi bilgileri nasıl kullandığını sade bir dille anlatıyoruz.",
    deviceTitle: "Bu cihazda saklananlar",
    device: "Dil seçiminiz, favorileriniz, gezi planınız ve isterseniz girdiğiniz oda numarası yalnızca telefonunuzun tarayıcısında saklanır; otele ya da sunucuya gönderilmez. Oda numarası, yalnızca siz resepsiyonla WhatsApp yazışması açtığınızda mesaja eklenir. Bunların hepsini Ayarlar'daki “{deleteLabel}” düğmesiyle istediğiniz an silebilirsiniz.",
    statsTitle: "Anonim kullanım istatistikleri",
    stats: "Rehberi geliştirmek için hangi ekranların açıldığı ve hangi dilin seçildiği gibi olaylar yalnızca toplam sayılar olarak tutulur. Bu sayılarla birlikte IP adresi, cihaz kimliği ya da kişisel bilgi kaydedilmez; reklam veya takip çerezi kullanılmaz.",
    locationTitle: "Konum",
    location: "Konumunuz yalnızca haritadaki konum düğmesine bastığınızda, sizi haritada göstermek için kullanılır. Konumunuz telefonunuzda kalır, sunucuya gönderilmez. Yürüyüş rotaları otelden ve gezilecek yerlerden hesaplanır.",
    aiTitle: "Yapay zekâ rehberi",
    ai: "Yapay zekâ rehberine yazdığınız sorular, cevap hazırlanabilmesi için otelin sunucusu üzerinden Google'ın Gemini hizmetine iletilir; IrisMap bu soruları saklamaz. Lütfen sorularınıza adınız, pasaport veya kart numaranız gibi kişisel bilgiler yazmayın.",
    servicesTitle: "Dış hizmetler",
    services: "Harita görüntüleri {mapHosts} adresinden, mekân fotoğrafları Wikimedia Commons'tan doğrudan tarayıcınıza yüklenir; her web sitesinde olduğu gibi bu hizmetler IP adresinizi görür.",
    servicesServerWeather: "Hava durumu ve yürüyüş rotası bilgilerini otelin sunucusu alır; telefonunuz bu hizmetlere bağlanmaz.",
    servicesServer: "Yürüyüş rotası bilgilerini otelin sunucusu alır; telefonunuz bu hizmete bağlanmaz.",
    servicesLinks: "Telefon, WhatsApp, e-posta ve Google Haritalar bağlantıları ilgili uygulamayı açar; o uygulamaların kendi gizlilik koşulları geçerlidir.",
    rightsTitle: "Haklarınız ve iletişim",
    rights: "6698 sayılı Kişisel Verilerin Korunması Kanunu (KVKK) ve AB Genel Veri Koruma Tüzüğü (GDPR) kapsamındaki haklarınızla ilgili sorularınız için veri sorumlusu {controller} ile iletişime geçebilirsiniz.",
    email: "E-posta",
    policy: "Ayrıntılı gizlilik politikası",
  },
  EN: {
    title: "Privacy and personal data",
    intro: "You use the {hotel} guest guide without an account. We do not ask for your name, phone number or e-mail address. Here is, in plain words, what the guide uses and how.",
    deviceTitle: "Stored on this device",
    device: "Your language, favourites, trip plan and, if you enter it, your room number are kept only in your phone's browser; they are not sent to the hotel or to the server. Your room number is added to a message only when you open a WhatsApp chat with reception yourself. You can delete all of this at any time with “{deleteLabel}” in Settings.",
    statsTitle: "Anonymous usage statistics",
    stats: "To improve the guide, events such as which screens are opened and which language is chosen are kept only as totals. No IP address, device ID or personal information is stored with these totals, and no advertising or tracking cookies are used.",
    locationTitle: "Location",
    location: "Your location is used only when you tap the location button on the map, to show where you are. It stays on your phone and is not sent to the server. Walking routes are calculated from the hotel and the sights.",
    aiTitle: "AI guide",
    ai: "Questions you type into the AI guide are passed through the hotel's server to Google's Gemini service so that an answer can be written; IrisMap does not store them. Please do not include personal details such as your name, passport or card number.",
    servicesTitle: "Other services",
    services: "Map images are loaded from {mapHosts} and place photos from Wikimedia Commons directly into your browser; like any website, these services can see your IP address.",
    servicesServerWeather: "Weather and walking route information is fetched by the hotel's server, so your phone does not contact those services.",
    servicesServer: "Walking route information is fetched by the hotel's server, so your phone does not contact that service.",
    servicesLinks: "Phone, WhatsApp, e-mail and Google Maps links open the respective app, whose own privacy terms apply.",
    rightsTitle: "Your rights and contact",
    rights: "For questions about your rights under Turkey's Personal Data Protection Law (KVKK) and the EU General Data Protection Regulation (GDPR), contact the data controller, {controller}.",
    email: "E-mail",
    policy: "Full privacy policy",
  },
  DE: {
    title: "Datenschutz und personenbezogene Daten",
    intro: "Sie nutzen den Gästeführer von {hotel} ohne Konto. Wir fragen weder nach Ihrem Namen noch nach Telefonnummer oder E-Mail-Adresse. Hier erklären wir in einfachen Worten, was der Führer verwendet und wie.",
    deviceTitle: "Auf diesem Gerät gespeichert",
    device: "Ihre Sprache, Favoriten, Ihr Reiseplan und – falls eingegeben – Ihre Zimmernummer werden nur im Browser Ihres Telefons gespeichert und weder an das Hotel noch an den Server gesendet. Die Zimmernummer wird nur dann in eine Nachricht eingefügt, wenn Sie selbst einen WhatsApp-Chat mit der Rezeption öffnen. Mit „{deleteLabel}“ in den Einstellungen können Sie alles jederzeit löschen.",
    statsTitle: "Anonyme Nutzungsstatistik",
    stats: "Um den Führer zu verbessern, werden Ereignisse wie geöffnete Seiten und die gewählte Sprache nur als Gesamtzahlen gezählt. Dabei werden keine IP-Adressen, Gerätekennungen oder personenbezogenen Daten gespeichert; Werbe- oder Tracking-Cookies werden nicht verwendet.",
    locationTitle: "Standort",
    location: "Ihr Standort wird nur verwendet, wenn Sie auf der Karte die Standort-Schaltfläche antippen, um Ihre Position anzuzeigen. Er bleibt auf Ihrem Telefon und wird nicht an den Server gesendet. Fußrouten werden vom Hotel und den Sehenswürdigkeiten aus berechnet.",
    aiTitle: "KI-Guide",
    ai: "Fragen, die Sie in den KI-Guide eingeben, werden über den Server des Hotels an den Dienst Gemini von Google übermittelt, damit eine Antwort erstellt werden kann; IrisMap speichert sie nicht. Bitte geben Sie keine persönlichen Daten wie Namen, Pass- oder Kartennummern ein.",
    servicesTitle: "Weitere Dienste",
    services: "Kartenbilder werden von {mapHosts} und Fotos der Orte von Wikimedia Commons direkt in Ihren Browser geladen; wie bei jeder Website sehen diese Dienste Ihre IP-Adresse.",
    servicesServerWeather: "Wetter- und Routeninformationen ruft der Server des Hotels ab; Ihr Telefon verbindet sich nicht mit diesen Diensten.",
    servicesServer: "Routeninformationen ruft der Server des Hotels ab; Ihr Telefon verbindet sich nicht mit diesem Dienst.",
    servicesLinks: "Links zu Telefon, WhatsApp, E-Mail und Google Maps öffnen die jeweilige App; dort gelten deren eigene Datenschutzbestimmungen.",
    rightsTitle: "Ihre Rechte und Kontakt",
    rights: "Bei Fragen zu Ihren Rechten nach dem türkischen Datenschutzgesetz (KVKK) und der EU-Datenschutz-Grundverordnung (DSGVO) wenden Sie sich an den Verantwortlichen: {controller}.",
    email: "E-Mail",
    policy: "Vollständige Datenschutzerklärung",
  },
  ZH: {
    title: "隐私与个人数据",
    intro: "您无需注册账号即可使用{hotel}宾客指南。我们不会要求您提供姓名、电话号码或电子邮箱。以下用简单的语言说明本指南使用哪些信息以及如何使用。",
    deviceTitle: "保存在本设备上的信息",
    device: "您的语言、收藏、行程计划以及您自愿填写的房间号仅保存在手机浏览器中，不会发送给酒店或服务器。只有当您自己打开与前台的 WhatsApp 对话时，房间号才会加入消息。您可以随时在设置中使用“{deleteLabel}”删除这些信息。",
    statsTitle: "匿名使用统计",
    stats: "为改进指南，打开了哪些页面、选择了哪种语言等事件仅以总数形式记录。这些数字不会与 IP 地址、设备标识或个人信息一起保存，也不使用广告或追踪 Cookie。",
    locationTitle: "位置",
    location: "只有当您点击地图上的定位按钮时，才会使用您的位置，以便在地图上显示您所在的位置。位置信息保留在您的手机上，不会发送到服务器。步行路线从酒店和景点出发计算。",
    aiTitle: "AI 导览",
    ai: "您在 AI 导览中输入的问题会经酒店服务器转交给 Google 的 Gemini 服务以生成回答，IrisMap 不会保存这些问题。请勿输入姓名、护照号或银行卡号等个人信息。",
    servicesTitle: "其他服务",
    services: "地图图像来自 {mapHosts}，景点照片来自 Wikimedia Commons，均直接加载到您的浏览器；与任何网站一样，这些服务可以看到您的 IP 地址。",
    servicesServerWeather: "天气和步行路线信息由酒店服务器获取，您的手机不会连接这些服务。",
    servicesServer: "步行路线信息由酒店服务器获取，您的手机不会连接该服务。",
    servicesLinks: "电话、WhatsApp、电子邮件和 Google 地图链接会打开相应的应用，并适用其各自的隐私条款。",
    rightsTitle: "您的权利与联系方式",
    rights: "如对土耳其《个人数据保护法》(KVKK) 和欧盟《通用数据保护条例》(GDPR) 规定的权利有任何疑问，请联系数据控制者：{controller}。",
    email: "电子邮件",
    policy: "完整隐私政策",
  },
  RU: {
    title: "Конфиденциальность и персональные данные",
    intro: "Путеводителем для гостей {hotel} можно пользоваться без регистрации. Мы не спрашиваем ваше имя, номер телефона или адрес электронной почты. Ниже простыми словами объясняем, какие данные использует путеводитель и как.",
    deviceTitle: "Что хранится на этом устройстве",
    device: "Выбранный язык, избранное, план прогулок и, если вы его укажете, номер комнаты хранятся только в браузере вашего телефона и не передаются ни отелю, ни на сервер. Номер комнаты добавляется в сообщение, только когда вы сами открываете чат WhatsApp со стойкой регистрации. Всё это можно в любой момент удалить кнопкой «{deleteLabel}» в настройках.",
    statsTitle: "Анонимная статистика",
    stats: "Чтобы улучшать путеводитель, такие события, как открытие разделов и выбор языка, учитываются только в виде общих сумм. Вместе с ними не сохраняются IP-адрес, идентификатор устройства или личные данные; рекламные и отслеживающие cookie не используются.",
    locationTitle: "Местоположение",
    location: "Ваше местоположение используется, только когда вы нажимаете кнопку геолокации на карте, чтобы показать, где вы находитесь. Оно остаётся на телефоне и не отправляется на сервер. Пешие маршруты строятся от отеля и достопримечательностей.",
    aiTitle: "ИИ-гид",
    ai: "Вопросы, которые вы вводите в ИИ-гид, передаются через сервер отеля в сервис Gemini компании Google, чтобы составить ответ; IrisMap их не хранит. Пожалуйста, не указывайте личные данные — имя, номер паспорта или карты.",
    servicesTitle: "Другие сервисы",
    services: "Изображения карты загружаются с {mapHosts}, а фотографии мест — с Wikimedia Commons напрямую в ваш браузер; как и любой сайт, эти сервисы видят ваш IP-адрес.",
    servicesServerWeather: "Погоду и пешие маршруты получает сервер отеля, поэтому ваш телефон к этим сервисам не обращается.",
    servicesServer: "Пешие маршруты получает сервер отеля, поэтому ваш телефон к этому сервису не обращается.",
    servicesLinks: "Ссылки на телефон, WhatsApp, электронную почту и Google Карты открывают соответствующее приложение, для которого действуют его собственные правила конфиденциальности.",
    rightsTitle: "Ваши права и контакты",
    rights: "По вопросам о ваших правах согласно турецкому закону о защите персональных данных (KVKK) и Общему регламенту ЕС по защите данных (GDPR) обращайтесь к оператору данных: {controller}.",
    email: "Эл. почта",
    policy: "Полная политика конфиденциальности",
  },
  AR: {
    title: "الخصوصية والبيانات الشخصية",
    intro: "تستخدم دليل ضيوف {hotel} دون إنشاء حساب. لا نطلب اسمك أو رقم هاتفك أو بريدك الإلكتروني. نوضح أدناه بلغة بسيطة المعلومات التي يستخدمها الدليل وكيفية استخدامها.",
    deviceTitle: "ما يُحفظ على هذا الجهاز",
    device: "تُحفظ لغتك ومفضلاتك وخطة رحلتك، ورقم غرفتك إن أدخلته، في متصفح هاتفك فقط، ولا تُرسل إلى الفندق أو إلى الخادم. لا يُضاف رقم الغرفة إلى رسالة إلا عندما تفتح بنفسك محادثة WhatsApp مع الاستقبال. يمكنك حذف كل ذلك في أي وقت بزر «{deleteLabel}» في الإعدادات.",
    statsTitle: "إحصاءات استخدام مجهولة",
    stats: "لتحسين الدليل، تُحسب أحداث مثل الصفحات التي تُفتح واللغة المختارة كمجاميع فقط. لا يُحفظ مع هذه المجاميع عنوان الإنترنت أو معرّف الجهاز أو أي بيانات شخصية، ولا تُستخدم ملفات تعريف ارتباط إعلانية أو للتتبع.",
    locationTitle: "الموقع",
    location: "لا يُستخدم موقعك إلا عندما تضغط زر تحديد الموقع على الخريطة لإظهار مكانك. يبقى الموقع على هاتفك ولا يُرسل إلى الخادم. تُحسب مسارات المشي انطلاقاً من الفندق والمعالم.",
    aiTitle: "الدليل الذكي",
    ai: "تُنقل الأسئلة التي تكتبها في الدليل الذكي عبر خادم الفندق إلى خدمة جيميني من Google لصياغة الإجابة، ولا يحفظها IrisMap. يُرجى عدم كتابة معلومات شخصية مثل الاسم أو رقم جواز السفر أو البطاقة.",
    servicesTitle: "خدمات أخرى",
    services: "تُحمَّل صور الخريطة من {mapHosts} وصور الأماكن من ويكيميديا كومنز مباشرة إلى متصفحك، وكما هو الحال مع أي موقع ويب، يمكن لهذه الخدمات رؤية عنوان الإنترنت الخاص بك.",
    servicesServerWeather: "يجلب خادم الفندق معلومات الطقس ومسارات المشي، لذلك لا يتصل هاتفك بهذه الخدمات.",
    servicesServer: "يجلب خادم الفندق معلومات مسارات المشي، لذلك لا يتصل هاتفك بهذه الخدمة.",
    servicesLinks: "تفتح روابط الهاتف وWhatsApp والبريد الإلكتروني وخرائط Google التطبيق المعني، وتسري عليه شروط الخصوصية الخاصة به.",
    rightsTitle: "حقوقك والتواصل",
    rights: "للاستفسار عن حقوقك بموجب قانون حماية البيانات الشخصية التركي واللائحة العامة لحماية البيانات في الاتحاد الأوروبي، تواصل مع المسؤول عن البيانات: {controller}.",
    email: "البريد الإلكتروني",
    policy: "سياسة الخصوصية الكاملة",
  },
};

export interface PrivacyContext {
  hotel: string;
  controller: string;
  deleteLabel: string;
  mapHosts: string;
  aiGuide: boolean;
  weather: boolean;
}

export interface PrivacyNotice {
  title: string;
  intro: string;
  sections: Array<{ id: string; title: string; paragraphs: string[] }>;
  rightsTitle: string;
  rights: string;
  emailLabel: string;
  policyLabel: string;
}

export function getPrivacyNotice(language: Language, context: PrivacyContext): PrivacyNotice {
  const text = TEXT[language];
  const fill = (template: string) => formatText(template, {
    hotel: context.hotel,
    controller: context.controller,
    deleteLabel: context.deleteLabel,
    mapHosts: context.mapHosts,
  });
  const sections = [
    { id: "device", title: text.deviceTitle, paragraphs: [fill(text.device)] },
    { id: "stats", title: text.statsTitle, paragraphs: [fill(text.stats)] },
    { id: "location", title: text.locationTitle, paragraphs: [fill(text.location)] },
    ...(context.aiGuide ? [{ id: "ai", title: text.aiTitle, paragraphs: [fill(text.ai)] }] : []),
    {
      id: "services",
      title: text.servicesTitle,
      paragraphs: [
        fill(text.services),
        context.weather ? text.servicesServerWeather : text.servicesServer,
        text.servicesLinks,
      ],
    },
  ];
  return {
    title: text.title,
    intro: fill(text.intro),
    sections,
    rightsTitle: text.rightsTitle,
    rights: fill(text.rights),
    emailLabel: text.email,
    policyLabel: text.policy,
  };
}

/** Host names of the map image servers, e.g. "basemaps.cartocdn.com". */
export function mapHostNames(tileUrls: string[]): string {
  const hosts = new Set<string>();
  for (const template of tileUrls) {
    try {
      hosts.add(new URL(template.replace(/\{[a-z]+\}/gi, "0")).hostname.replace(/^[a-d]\./, ""));
    } catch {
      // ignore malformed templates (validated on the server)
    }
  }
  return [...hosts].join(", ");
}
