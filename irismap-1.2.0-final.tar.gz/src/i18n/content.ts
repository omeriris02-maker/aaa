import { EventItem, Language, PhotoItem, Place, Tour } from "../types";

const CATEGORY_LABELS: Record<Place["kategori"], Record<Language, string>> = {
  UNESCO: { TR: "UNESCO", EN: "UNESCO", DE: "UNESCO", ZH: "联合国教科文组织", RU: "ЮНЕСКО", AR: "اليونسكو" },
  Müze: { TR: "Müze", EN: "Museum", DE: "Museum", ZH: "博物馆", RU: "Музей", AR: "متحف" },
  Cami: { TR: "Cami", EN: "Mosque", DE: "Moschee", ZH: "清真寺", RU: "Мечеть", AR: "مسجد" },
  Türbe: { TR: "Türbe", EN: "Mausoleum", DE: "Mausoleum", ZH: "陵墓", RU: "Мавзолей", AR: "ضريح" },
  Medrese: { TR: "Medrese", EN: "Madrasa", DE: "Medrese", ZH: "神学院", RU: "Медресе", AR: "مدرسة" },
  "Tarihi Yapı": { TR: "Tarihi Yapı", EN: "Historic Site", DE: "Historische Stätte", ZH: "历史遗迹", RU: "Исторический объект", AR: "معلم تاريخي" },
  Park: { TR: "Doğa ve Park", EN: "Nature & Park", DE: "Natur und Park", ZH: "自然与公园", RU: "Природа и парк", AR: "طبيعة وحديقة" },
  Otel: { TR: "Otel", EN: "Hotel", DE: "Hotel", ZH: "酒店", RU: "Отель", AR: "فندق" },
};

const known = (
  language: Language,
  values: Partial<Record<Language, string>>,
  turkish: string,
) => values[language]?.trim() || turkish;

export const placeName = (place: Place, language: Language) =>
  known(language, {
    TR: place.isim_tr,
    EN: place.isim_en,
    DE: place.isim_de,
    ZH: place.isim_zh,
    RU: place.isim_ru,
    AR: place.isim_ar,
  }, place.isim_tr);

export const placeSummary = (place: Place, language: Language) =>
  known(language, {
    TR: place.aciklama_kisa_tr,
    EN: place.aciklama_kisa_en,
    DE: place.aciklama_kisa_de,
    ZH: place.aciklama_kisa_zh,
    RU: place.aciklama_kisa_ru,
    AR: place.aciklama_kisa_ar,
  }, place.aciklama_kisa_tr);

export const placeHistory = (place: Place, language: Language) =>
  known(language, {
    TR: place.tarihce_tr,
    EN: place.tarihce_en,
    DE: place.tarihce_de,
    ZH: place.tarihce_zh,
    RU: place.tarihce_ru,
    AR: place.tarihce_ar,
  }, place.tarihce_tr);

export const categoryLabel = (category: Place["kategori"], language: Language) =>
  CATEGORY_LABELS[category]?.[language] || CATEGORY_LABELS[category]?.TR || category;

export const tourName = (tour: Tour, language: Language) =>
  known(language, {
    TR: tour.isim_tr,
    EN: tour.isim_en,
    DE: tour.isim_de,
    ZH: tour.isim_zh,
    RU: tour.isim_ru,
    AR: tour.isim_ar,
  }, tour.isim_tr);

export const tourSummary = (tour: Tour, language: Language) =>
  known(language, {
    TR: tour.aciklama_tr,
    EN: tour.aciklama_en,
    DE: tour.aciklama_de,
    ZH: tour.aciklama_zh,
    RU: tour.aciklama_ru,
    AR: tour.aciklama_ar,
  }, tour.aciklama_tr);

export const photoCaption = (photo: PhotoItem, language: Language) =>
  known(language, {
    TR: photo.caption_tr,
    EN: photo.caption_en,
    DE: photo.caption_de,
    ZH: photo.caption_zh,
    RU: photo.caption_ru,
    AR: photo.caption_ar,
  }, photo.caption_tr);

export const eventName = (event: EventItem, language: Language) =>
  known(language, {
    TR: event.isim_tr,
    EN: event.isim_en,
    DE: event.isim_de,
    ZH: event.isim_zh,
    RU: event.isim_ru,
    AR: event.isim_ar,
  }, event.isim_tr);

export const eventSummary = (event: EventItem, language: Language) =>
  known(language, {
    TR: event.aciklama_tr,
    EN: event.aciklama_en,
    DE: event.aciklama_de,
    ZH: event.aciklama_zh,
    RU: event.aciklama_ru,
    AR: event.aciklama_ar,
  }, event.aciklama_tr);

export const eventLocation = (event: EventItem, language: Language) =>
  known(language, {
    TR: event.yer_tr,
    EN: event.yer_en,
    DE: event.yer_de,
    ZH: event.yer_zh,
    RU: event.yer_ru,
    AR: event.yer_ar,
  }, event.yer_tr);

export const eventPrice = (event: EventItem, language: Language) =>
  known(language, {
    TR: event.ucret_tr,
    EN: event.ucret_en,
    DE: event.ucret_de,
    ZH: event.ucret_zh,
    RU: event.ucret_ru,
    AR: event.ucret_ar,
  }, event.ucret_tr);

export const eventDate = (event: EventItem, language: Language) =>
  known(language, {
    TR: event.tarih_tr,
    EN: event.tarih_en,
    DE: event.tarih_de,
    ZH: event.tarih_zh,
    RU: event.tarih_ru,
    AR: event.tarih_ar,
  }, event.tarih_tr);

export const tourBriefing = (tour: Tour, language: Language) =>
  known(language, {
    TR: tour.briefing_tr,
    EN: tour.briefing_en,
    DE: tour.briefing_de,
    ZH: tour.briefing_zh,
    RU: tour.briefing_ru,
    AR: tour.briefing_ar,
  }, tour.briefing_tr ?? "");
