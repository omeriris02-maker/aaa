const ARABIC_DIGRAPHS: Array<[RegExp, string]> = [
  [/ş/gi, "ش"],
  [/ç/gi, "تش"],
  [/ğ/gi, "غ"],
  [/ö/gi, "و"],
  [/ü/gi, "و"],
  [/ı/gi, "ي"],
];

const ARABIC_LETTERS: Record<string, string> = {
  a: "ا", b: "ب", c: "ج", d: "د", e: "ە", f: "ف", g: "غ",
  h: "ه", i: "ي", j: "ژ", k: "ك", l: "ل", m: "م", n: "ن",
  o: "و", p: "ب", q: "ق", r: "ر", s: "س", t: "ت", u: "و",
  v: "و", w: "و", x: "كس", y: "ي", z: "ز",
};

/**
 * Produces an Arabic-script label for Turkish proper names that do not yet
 * have an editorial Arabic form. Normal UI and descriptive copy always comes
 * from the translation catalogue.
 */
export function toArabicName(value: string): string {
  let result = value.normalize("NFC");
  for (const [pattern, replacement] of ARABIC_DIGRAPHS) {
    result = result.replace(pattern, replacement);
  }

  return Array.from(result)
    .map((character) => ARABIC_LETTERS[character.toLocaleLowerCase("tr-TR")] ?? character)
    .join("")
    .replace(/\s+/g, " ")
    .trim();
}
