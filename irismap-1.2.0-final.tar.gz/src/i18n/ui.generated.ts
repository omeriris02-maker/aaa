import type { Language } from "../types";

const UI_ROWS: Record<string, [string, string, string, string, string]> = {
  "{city} keşfiniz {hotel} ile başlıyor.": [
    "Explore {city} as a guest of {hotel}.",
    "Entdecken Sie {city} als Gast von {hotel}.",
    "以{hotel}宾客的身份探索{city}。",
    "{city} ждёт вас · {hotel}",
    "استكشف {city} بصفتك ضيفاً في {hotel}."
  ],
  "{city} Ziyaretçi Rehberi": [
    "{city} Visitor Guide",
    "Besucherführer {city}",
    "{city}游客指南",
    "Путеводитель · {city}",
    "دليل زوار {city}"
  ],
  "{count} yıldız": [
    "{count} stars",
    "{count} Sterne",
    "{count}星级",
    "Звёзд: {count}",
    "{count} نجوم"
  ],
  "{hotel} · MİSAFİR REHBERİ": [
    "{hotel} · GUEST GUIDE",
    "{hotel} · GÄSTEFÜHRER",
    "{hotel} · 宾客指南",
    "{hotel} · ГИД ДЛЯ ГОСТЕЙ",
    "{hotel} · دليل الضيوف"
  ],
  "{hotel} Dijital Misafir Asistanı": [
    "{hotel} Digital Guest Assistant",
    "Digitaler Gästeassistent · {hotel}",
    "{hotel}数字宾客助手",
    "Цифровой помощник · {hotel}",
    "المساعد الرقمي للضيوف · {hotel}"
  ],
  "{hotel} Konsiyerj": [
    "{hotel} Concierge",
    "Concierge · {hotel}",
    "{hotel}礼宾服务",
    "Консьерж · {hotel}",
    "كونسيرج {hotel}"
  ],
  "{hotel} Misafir Desteği": [
    "{hotel} Guest Support",
    "Gästeservice · {hotel}",
    "{hotel}宾客服务",
    "Поддержка гостей · {hotel}",
    "دعم ضيوف {hotel}"
  ],
  "{hotel} Önerileri": [
    "{hotel} Recommendations",
    "Empfehlungen · {hotel}",
    "{hotel}推荐",
    "Рекомендации · {hotel}",
    "توصيات {hotel}"
  ],
  "{hotel} Resepsiyon": [
    "{hotel} Reception",
    "Rezeption · {hotel}",
    "{hotel}前台",
    "Стойка регистрации · {hotel}",
    "استقبال {hotel}"
  ],
  "{hotel} Resepsiyon (WhatsApp)": [
    "{hotel} Reception (WhatsApp)",
    "Rezeption · {hotel} (WhatsApp)",
    "{hotel}前台（WhatsApp）",
    "Стойка регистрации · {hotel} (WhatsApp)",
    "استقبال {hotel} (واتساب)"
  ],
  "Acil durumda resepsiyonu arayabilirsiniz. Türkiye’de ambulans, polis ve itfaiye için ortak acil çağrı numarası 112’dir.": [
    "Call reception in an emergency. In Türkiye, 112 is the single emergency number for ambulance, police, and fire services.",
    "Im Notfall können Sie die Rezeption anrufen. In der Türkei ist 112 die einheitliche Nummer für Rettungsdienst, Polizei und Feuerwehr.",
    "紧急情况下可联系前台。在土耳其，112 是救护、警察和消防的统一紧急号码。",
    "В экстренной ситуации позвоните на стойку регистрации. В Турции 112 — единый номер скорой помощи, полиции и пожарной службы.",
    "يمكنك الاتصال بالاستقبال في حالة الطوارئ. الرقم 112 هو الرقم الموحد للإسعاف والشرطة والإطفاء في تركيا."
  ],
  "Ana menü": [
    "Main menu",
    "Hauptmenü",
    "主菜单",
    "Главное меню",
    "القائمة الرئيسية"
  ],
  "Anasayfa": [
    "Home",
    "Start",
    "首页",
    "Главная",
    "الرئيسية"
  ],
  "Anladım": [
    "Got it",
    "Verstanden",
    "明白了",
    "Понятно",
    "فهمت"
  ],
  "Aradığınız kriterde bir mekan bulunamadı.": [
    "No matching places found.",
    "Keine passenden Orte gefunden.",
    "未找到符合条件的地点。",
    "Подходящие места не найдены.",
    "لم يتم العثور على مكان مطابق."
  ],
  "Arama sonuçları": [
    "Search results",
    "Suchergebnisse",
    "搜索结果",
    "Результаты поиска",
    "نتائج البحث"
  ],
  "Aramayı temizle": [
    "Clear search",
    "Suche löschen",
    "清除搜索",
    "Очистить поиск",
    "مسح البحث"
  ],
  "Arşiv fotoğrafları henüz bulunmuyor": [
    "Archive photos are not available yet",
    "Noch keine Archivfotos verfügbar",
    "暂无档案照片",
    "Архивных фотографий пока нет",
    "لا تتوفر صور أرشيفية بعد"
  ],
  "Arşiv fotoğrafları yükleniyor…": [
    "Loading archive photos…",
    "Archivfotos werden geladen…",
    "正在加载档案照片……",
    "Загружаются архивные фотографии…",
    "جارٍ تحميل الصور الأرشيفية…"
  ],
  "Asansör / Rampa": [
    "Elevator / Ramp",
    "Aufzug / Rampe",
    "电梯 / 坡道",
    "Лифт / пандус",
    "مصعد / منحدر"
  ],
  "Aşağı taşı": [
    "Move down",
    "Nach unten",
    "下移",
    "Переместить вниз",
    "نقل للأسفل"
  ],
  "Atla": [
    "Skip",
    "Überspringen",
    "跳过",
    "Пропустить",
    "تخطي"
  ],
  "Ayarlar": [
    "Settings",
    "Einstellungen",
    "设置",
    "Настройки",
    "الإعدادات"
  ],
  "Bağlantı durumu ilk soruda belirlenir": [
    "Connection status is checked with your first question",
    "Der Verbindungsstatus wird bei Ihrer ersten Frage geprüft",
    "连接状态将在您首次提问时检测",
    "Состояние подключения проверяется при первом вопросе",
    "يتم التحقق من حالة الاتصال عند سؤالك الأول"
  ],
  "Bağlantı kopyalanamadı.": [
    "The link could not be copied.",
    "Der Link konnte nicht kopiert werden.",
    "无法复制链接。",
    "Не удалось скопировать ссылку.",
    "تعذر نسخ الرابط."
  ],
  "Bilgilendirme: Ziyaret saatleri, erişilebilirlik ve diğer bilgiler zaman içinde değişebilir. Ziyaret öncesinde güncel bilgileri ilgili kurumdan doğrulamanız önerilir.": [
    "Information: Visiting hours, accessibility, and other details may change. Please confirm current information with the venue before visiting.",
    "Hinweis: Besuchszeiten, Barrierefreiheit und weitere Angaben können sich ändern. Bitte prüfen Sie die aktuellen Informationen vor dem Besuch beim jeweiligen Ort.",
    "提示：开放时间、无障碍条件及其他信息可能变化。参观前请向相关场馆确认最新信息。",
    "Информация: время работы, доступность и другие сведения могут меняться. Уточняйте актуальную информацию перед посещением.",
    "تنبيه: قد تتغير أوقات الزيارة وإمكانية الوصول وغيرها من المعلومات. يُرجى التحقق من الجهة المعنية قبل الزيارة."
  ],
  "Bilgileriniz kaybolmadı. Sayfayı yenileyerek tekrar deneyebilirsiniz.": [
    "Your saved information is safe. Reload the page to try again.",
    "Ihre gespeicherten Daten sind sicher. Laden Sie die Seite neu und versuchen Sie es erneut.",
    "您保存的信息不会丢失，请刷新页面后重试。",
    "Сохранённые данные не потеряны. Обновите страницу и попробуйте снова.",
    "معلوماتك المحفوظة آمنة. أعد تحميل الصفحة للمحاولة مرة أخرى."
  ],
  "Bu bölüm şu anda yüklenemedi. Bağlantınızı kontrol edip sayfayı yenileyin.": [
    "This section could not be loaded. Check your connection and reload the page.",
    "Dieser Bereich konnte nicht geladen werden. Prüfen Sie Ihre Verbindung und laden Sie die Seite neu.",
    "此部分暂时无法加载。请检查网络连接并刷新页面。",
    "Не удалось загрузить этот раздел. Проверьте подключение и обновите страницу.",
    "تعذر تحميل هذا القسم. تحقق من اتصالك وأعد تحميل الصفحة."
  ],
  "Bu cihazdaki verilerimi sil": [
    "Delete my data on this device",
    "Meine Daten auf diesem Gerät löschen",
    "删除此设备上的我的数据",
    "Удалить мои данные с этого устройства",
    "احذف بياناتي من هذا الجهاز"
  ],
  "Bu cihazdaki verileriniz silindi.": [
    "Your data on this device was deleted.",
    "Ihre Daten auf diesem Gerät wurden gelöscht.",
    "此设备上的数据已删除。",
    "Ваши данные на этом устройстве удалены.",
    "تم حذف بياناتك من هذا الجهاز."
  ],
  "Bu durağa en yakın öneriler": [
    "Closest recommendations to this stop",
    "Empfehlungen nahe diesem Stopp",
    "距此站最近的推荐地点",
    "Ближайшие места к этой остановке",
    "أقرب الأماكن المقترحة لهذه المحطة"
  ],
  "Bu mekân için doğrulanmış görsel bulunamadı. Uygun kaynak doğrulandığında galeriye eklenecektir.": [
    "No verified image is available for this place. It will be added when a suitable source is verified.",
    "Für diesen Ort ist noch kein geprüftes Bild verfügbar. Es wird ergänzt, sobald eine geeignete Quelle bestätigt ist.",
    "此地点暂无经核实的图片。确认合适来源后将添加至图库。",
    "Для этого места пока нет проверенного изображения. Оно будет добавлено после подтверждения подходящего источника.",
    "لا تتوفر صورة موثقة لهذا الموقع حالياً. ستُضاف عند التحقق من مصدر مناسب."
  ],
  "BUGÜNKÜ GEZİ LİSTEM": [
    "TODAY'S VISIT LIST",
    "MEINE HEUTIGE BESUCHSLISTE",
    "今日游览清单",
    "МОЙ СПИСОК НА СЕГОДНЯ",
    "قائمة زياراتي اليوم"
  ],
  "Cami / Mescit": [
    "Mosque",
    "Moschee / Gebetsraum",
    "清真寺 / 礼拜室",
    "Мечеть / молитвенная комната",
    "مسجد / مصلى"
  ],
  "Çevrimdışı rehber modu · Temel bilgiler": [
    "Offline guide mode · Basic information",
    "Offline-Reiseführer · Grundinformationen",
    "离线指南模式 · 基本信息",
    "Офлайн-режим · Основная информация",
    "وضع الدليل دون اتصال · معلومات أساسية"
  ],
  "Çok sık soru gönderildi. Lütfen bir dakika sonra tekrar deneyin.": [
    "Too many questions in a short time. Please try again in a minute.",
    "Zu viele Fragen in kurzer Zeit. Bitte versuchen Sie es in einer Minute erneut.",
    "提问过于频繁，请一分钟后再试。",
    "Слишком много вопросов за короткое время. Попробуйте через минуту.",
    "أُرسلت أسئلة كثيرة في وقت قصير. يرجى المحاولة بعد دقيقة."
  ],
  "Daha fazla göster": [
    "Show more",
    "Mehr anzeigen",
    "显示更多",
    "Показать ещё",
    "عرض المزيد"
  ],
  "DAHİL OLAN HİZMETLER": [
    "INCLUDED SERVICES",
    "INKLUSIVLEISTUNGEN",
    "包含的服务",
    "ВКЛЮЧЁННЫЕ УСЛУГИ",
    "الخدمات المشمولة"
  ],
  "Detayları Gör": [
    "View Details",
    "Details anzeigen",
    "查看详情",
    "Подробнее",
    "عرض التفاصيل"
  ],
  "Devam": [
    "Next",
    "Weiter",
    "下一步",
    "Далее",
    "التالي"
  ],
  "Dijital misafir asistanı · 7/24": [
    "Digital guest assistant · 24/7",
    "Digitaler Gästeassistent · rund um die Uhr",
    "数字宾客助手 · 全天候",
    "Цифровой помощник · 24/7",
    "مساعد الضيوف الرقمي · على مدار الساعة"
  ],
  "Dil menüsünü kapat": [
    "Close language menu",
    "Sprachmenü schließen",
    "关闭语言菜单",
    "Закрыть меню языка",
    "إغلاق قائمة اللغة"
  ],
  "Dil seçin": [
    "Choose language",
    "Sprache wählen",
    "选择语言",
    "Выберите язык",
    "اختر اللغة"
  ],
  "Dini ve mukaddes mekânları ziyaret ederken omuzların ve dizlerin kapalı olmasına ve cami girişlerinde ayakkabıların çıkarılmasına özen gösteriniz.": [
    "When visiting holy sites, cover shoulders and knees and remove shoes at mosque entrances.",
    "Bedecken Sie beim Besuch religiöser Orte Schultern und Knie und ziehen Sie am Moscheeeingang die Schuhe aus.",
    "参观宗教场所时请遮盖肩膀和膝盖，并在清真寺入口处脱鞋。",
    "При посещении религиозных мест прикрывайте плечи и колени и снимайте обувь перед входом в мечеть.",
    "عند زيارة الأماكن المقدسة يُرجى تغطية الكتفين والركبتين وخلع الأحذية عند مداخل المساجد."
  ],
  "dk": [
    "min",
    "Min.",
    "分钟",
    "мин",
    "دقيقة"
  ],
  "Doğal Alan / Park": [
    "Park / Nature",
    "Park / Natur",
    "公园 / 自然区域",
    "Парк / природа",
    "حديقة / طبيعة"
  ],
  "Duraklar haritada işaretlendi": [
    "Stops are marked on the map",
    "Die Stationen sind auf der Karte markiert",
    "各站点已在地图上标出",
    "Остановки отмечены на карте",
    "تم تحديد المحطات على الخريطة"
  ],
  "Duraklar otelden başlayarak en kısa yürüyüş sırasına dizildi.": [
    "Stops were ordered for the shortest walk from the hotel.",
    "Die Stationen wurden für den kürzesten Weg ab dem Hotel sortiert.",
    "已按从酒店出发的最短步行顺序排列站点。",
    "Остановки упорядочены для самой короткой прогулки от отеля.",
    "رُتبت المحطات لأقصر مسار مشي يبدأ من الفندق."
  ],
  "Durdur": [
    "Stop",
    "Stoppen",
    "停止",
    "Остановить",
    "إيقاف"
  ],
  "DÜŞÜNCELERİNİZ VEYA TALEPLERİNİZ": [
    "YOUR COMMENTS OR REQUESTS",
    "IHRE ANMERKUNGEN ODER WÜNSCHE",
    "您的意见或需求",
    "ВАШИ КОММЕНТАРИИ ИЛИ ЗАПРОСЫ",
    "ملاحظاتك أو طلباتك"
  ],
  "E-posta": [
    "E-mail",
    "E-Mail",
    "电子邮件",
    "Эл. почта",
    "البريد الإلكتروني"
  ],
  "E-POSTA ADRESİNİZ (İSTEĞE BAĞLI)": [
    "YOUR EMAIL (OPTIONAL)",
    "IHRE E-MAIL-ADRESSE (OPTIONAL)",
    "您的电子邮箱（可选）",
    "ВАША ЭЛЕКТРОННАЯ ПОЧТА (НЕОБЯЗАТЕЛЬНО)",
    "بريدك الإلكتروني (اختياري)"
  ],
  "E-posta Gönder": [
    "Send E-mail",
    "E-Mail senden",
    "发送邮件",
    "Написать письмо",
    "إرسال بريد إلكتروني"
  ],
  "E-POSTA İLE GERİ BİLDİRİM HAZIRLA": [
    "PREPARE FEEDBACK BY E-MAIL",
    "FEEDBACK PER E-MAIL VORBEREITEN",
    "通过邮件准备反馈",
    "ПОДГОТОВИТЬ ОТЗЫВ ПО ЭЛ. ПОЧТЕ",
    "إعداد الملاحظات عبر البريد الإلكتروني"
  ],
  "E-posta uygulamanız açıldı. E-postayı göndererek işlemi tamamlayabilirsiniz.": [
    "Your e-mail app opened. Send the e-mail to complete your feedback.",
    "Ihre E-Mail-App wurde geöffnet. Senden Sie die E-Mail, um Ihr Feedback abzuschließen.",
    "已打开您的邮件应用。发送邮件即可完成反馈。",
    "Открылось почтовое приложение. Отправьте письмо, чтобы завершить отзыв.",
    "تم فتح تطبيق البريد. أرسل الرسالة لإكمال ملاحظاتك."
  ],
  "En kısa yürüyüş sırasına diz": [
    "Order for the shortest walk",
    "Für den kürzesten Weg sortieren",
    "按最短步行路线排序",
    "Упорядочить по кратчайшему пути",
    "رتّب لأقصر مسار مشي"
  ],
  "Erişilebilir Tuvalet": [
    "Accessible restroom",
    "Barrierefreies WC",
    "无障碍卫生间",
    "Доступный туалет",
    "دورة مياه مهيأة"
  ],
  "Erişilebilirlik Olanakları": [
    "Accessibility Features",
    "Barrierefreiheit",
    "无障碍设施",
    "Доступная среда",
    "تسهيلات الوصول"
  ],
  "Esnek süre": [
    "Flexible time",
    "Flexible Dauer",
    "时间灵活",
    "Гибкое время",
    "مدة مرنة"
  ],
  "Evet, sil": [
    "Yes, delete",
    "Ja, löschen",
    "是的，删除",
    "Да, удалить",
    "نعم، احذف"
  ],
  "FAVORİ MEKÂNLARIM": [
    "MY SAVED PLACES",
    "MEINE FAVORITEN",
    "我的收藏地点",
    "МОИ ИЗБРАННЫЕ МЕСТА",
    "أماكني المفضلة"
  ],
  "Favoriler, plan, oda numarası ve tercihler silinir.": [
    "Removes favourites, plan, room number and preferences.",
    "Entfernt Favoriten, Plan, Zimmernummer und Einstellungen.",
    "将删除收藏、行程、房间号和偏好设置。",
    "Будут удалены избранное, план, номер комнаты и настройки.",
    "تُحذف المفضلة والخطة ورقم الغرفة والتفضيلات."
  ],
  "Favorilerden çıkar": [
    "Remove from favorites",
    "Aus Favoriten entfernen",
    "取消收藏",
    "Удалить из избранного",
    "إزالة من المفضلة"
  ],
  "Favorilere ekle": [
    "Add to favorites",
    "Zu Favoriten hinzufügen",
    "加入收藏",
    "Добавить в избранное",
    "إضافة إلى المفضلة"
  ],
  "Favorilerimi rotaya aktar": [
    "Import favorites as a route",
    "Favoriten als Route übernehmen",
    "将收藏导入路线",
    "Добавить избранное в маршрут",
    "إضافة المفضلة إلى المسار"
  ],
  "Form, mesajınızı e-posta uygulamanızda hazırlar. Gönderimi tamamlamak için e-postayı göndermeniz gerekir.": [
    "This form prepares your message in your e-mail app. Send the e-mail to complete the process.",
    "Das Formular bereitet Ihre Nachricht in Ihrer E-Mail-App vor. Senden Sie die E-Mail, um den Vorgang abzuschließen.",
    "此表单会在您的邮件应用中准备消息，发送邮件即可完成。",
    "Форма подготовит сообщение в вашем почтовом приложении. Чтобы завершить, отправьте письмо.",
    "يُعد هذا النموذج رسالتك في تطبيق البريد. أرسل الرسالة لإتمام العملية."
  ],
  "Form, mesajınızı otelin resmî WhatsApp hattında hazırlar. Gönderimi tamamlamak için açılan WhatsApp ekranında Gönder düğmesine basmanız gerekir.": [
    "This form prepares your message in the hotel's official WhatsApp chat. Complete the process by pressing Send in WhatsApp.",
    "Das Formular bereitet Ihre Nachricht im offiziellen WhatsApp-Chat des Hotels vor. Tippen Sie dort auf Senden, um den Vorgang abzuschließen.",
    "此表单会在酒店官方 WhatsApp 对话中准备好消息；请在打开的 WhatsApp 页面点击“发送”完成操作。",
    "Форма подготовит сообщение в официальном WhatsApp-чате отеля. Для завершения нажмите «Отправить» в WhatsApp.",
    "يُجهّز هذا النموذج رسالتك في محادثة واتساب الرسمية للفندق. اضغط على «إرسال» في واتساب لإتمام العملية."
  ],
  "Fotoğraf Galerisi": [
    "Photo Gallery",
    "Fotogalerie",
    "照片库",
    "Фотогалерея",
    "معرض الصور"
  ],
  "Galeri fotoğrafı": [
    "Gallery photo",
    "Galeriefoto",
    "图库照片",
    "Фото галереи",
    "صورة المعرض"
  ],
  "Gerçek yürüyüş rotası hesaplanıyor…": [
    "Calculating the real walking route…",
    "Reale Fußroute wird berechnet…",
    "正在计算实际步行路线……",
    "Рассчитывается реальный пеший маршрут…",
    "جارٍ حساب مسار المشي الفعلي…"
  ],
  "Geri": [
    "Back",
    "Zurück",
    "返回",
    "Назад",
    "رجوع"
  ],
  "GERİ BİLDİRİM GÖNDERİN": [
    "SEND FEEDBACK",
    "FEEDBACK SENDEN",
    "发送反馈",
    "ОТПРАВИТЬ ОТЗЫВ",
    "إرسال ملاحظات"
  ],
  "Geri dön": [
    "Go back",
    "Zurück",
    "返回",
    "Назад",
    "العودة"
  ],
  "Gezilecek yer veya kategori ara…": [
    "Search places or categories…",
    "Ort oder Kategorie suchen…",
    "搜索景点或类别……",
    "Поиск места или категории…",
    "ابحث عن مكان أو فئة…"
  ],
  "Gezilecek Yerler": [
    "Historical Places",
    "Sehenswürdigkeiten",
    "历史景点",
    "Достопримечательности",
    "أماكن تاريخية"
  ],
  "Google Haritalar ile Git": [
    "Go with Google Maps",
    "Mit Google Maps navigieren",
    "使用 Google 地图前往",
    "Маршрут в Google Картах",
    "الذهاب عبر خرائط غوغل"
  ],
  "Google Haritalar’da aç": [
    "Open in Google Maps",
    "In Google Maps öffnen",
    "在 Google 地图中打开",
    "Открыть в Google Картах",
    "فتح في خرائط غوغل"
  ],
  "Google Haritalar’da Aç": [
    "Open in Google Maps",
    "In Google Maps öffnen",
    "在 Google 地图中打开",
    "Открыть в Google Картах",
    "فتح في خرائط غوغل"
  ],
  "Görüş, öneri veya özel rehberlik talebinizi buraya yazabilirsiniz...": [
    "Write your comments, suggestions or specific guidance requests here...",
    "Schreiben Sie hier Ihre Meinung, Vorschläge oder besonderen Wünsche…",
    "请在此填写意见、建议或具体的导览需求……",
    "Напишите здесь отзыв, предложение или запрос на помощь…",
    "اكتب هنا رأيك أو اقتراحك أو طلب الإرشاد..."
  ],
  "Harita": [
    "Map",
    "Karte",
    "地图",
    "Карта",
    "الخريطة"
  ],
  "HARİTA": [
    "MAP",
    "KARTE",
    "地图",
    "КАРТА",
    "الخريطة"
  ],
  "Harita bu cihazda gösterilemiyor.": [
    "The map cannot be shown on this device.",
    "Die Karte kann auf diesem Gerät nicht angezeigt werden.",
    "此设备无法显示地图。",
    "Карту невозможно показать на этом устройстве.",
    "لا يمكن عرض الخريطة على هذا الجهاز."
  ],
  "Harita Göstergesi": [
    "Map Legend",
    "Kartenlegende",
    "地图图例",
    "Условные обозначения",
    "مفتاح الخريطة"
  ],
  "Harita göstergesini kapat": [
    "Close map legend",
    "Kartenlegende schließen",
    "关闭地图图例",
    "Закрыть условные обозначения",
    "إغلاق مفتاح الخريطة"
  ],
  "Harita hazırlanıyor…": [
    "Preparing the map…",
    "Karte wird vorbereitet…",
    "正在准备地图……",
    "Карта загружается…",
    "جارٍ تجهيز الخريطة…"
  ],
  "Harita şu anda yüklenemedi.": [
    "The map could not be loaded right now.",
    "Die Karte konnte gerade nicht geladen werden.",
    "地图暂时无法加载。",
    "Не удалось загрузить карту.",
    "تعذر تحميل الخريطة حالياً."
  ],
  "Harita tüm durakları gösterir. Yaya güzergâhı alınabildiğinde yol çizilir; alınamadığında yanıltıcı bir çizgi yerine duraklar düzgün biçimde çerçevelenir.": [
    "The map shows every stop. A walking route is drawn when available; otherwise the stops are framed clearly without a misleading line.",
    "Die Karte zeigt alle Stationen. Ein Fußweg wird gezeichnet, wenn er verfügbar ist; andernfalls werden die Stationen ohne irreführende Linie passend eingerahmt.",
    "地图会显示所有站点。可获取步行路线时会绘制路线；否则会清晰框选各站点，而不显示误导性线路。",
    "На карте показаны все остановки. Если доступен пеший маршрут, он будет построен; иначе остановки будут удобно показаны без вводящей в заблуждение линии.",
    "تعرض الخريطة جميع المحطات. يُرسم مسار المشي عند توفره، وإلا فتُعرض المحطات ضمن إطار واضح من دون خط مضلل."
  ],
  "Harita, rotalar ve kişisel planınızla şehri keşfetmeye hazırsınız.": [
    "You are ready to explore the city with the map, routes and your personal plan.",
    "Mit Karte, Routen und Ihrem persönlichen Plan sind Sie bereit, die Stadt zu entdecken.",
    "借助地图、路线和个人计划，开始探索这座城市吧。",
    "Карта, маршруты и личный план помогут вам познакомиться с городом.",
    "أنت جاهز لاستكشاف المدينة بالخريطة والمسارات وخطتك الشخصية."
  ],
  "Haritada Gör": [
    "Show on Map",
    "Auf der Karte anzeigen",
    "在地图上查看",
    "Показать на карте",
    "عرض على الخريطة"
  ],
  "Hazır gezi planları": [
    "Curated routes",
    "Fertige Touren",
    "精选路线",
    "Готовые маршруты",
    "مسارات جاهزة"
  ],
  "Hazır Rotalar": [
    "Curated Routes",
    "Ausgewählte Routen",
    "精选路线",
    "Готовые маршруты",
    "مسارات مقترحة"
  ],
  "Hazır Tur Rotaları": [
    "Curated Tour Routes",
    "Ausgewählte Touren",
    "精选游览路线",
    "Готовые маршруты",
    "مسارات سياحية جاهزة"
  ],
  "Henüz favori mekân eklemediniz. Beğendiğiniz yerleri kalp simgesiyle buraya kaydedebilirsiniz.": [
    "No saved places yet. Use the heart icon to save places here.",
    "Sie haben noch keine Orte gespeichert. Nutzen Sie das Herzsymbol, um Orte hier abzulegen.",
    "您还没有收藏地点。点击心形图标即可保存到这里。",
    "Сохранённых мест пока нет. Нажимайте значок сердца, чтобы добавить их сюда.",
    "لم تحفظ أي مكان بعد. استخدم رمز القلب لحفظ الأماكن هنا."
  ],
  "HIZLI ERİŞİM": [
    "QUICK ACCESS",
    "SCHNELLZUGRIFF",
    "快捷入口",
    "БЫСТРЫЙ ДОСТУП",
    "وصول سريع"
  ],
  "Hızlı Mekan Arama": [
    "Quick Place Search",
    "Schnelle Ortssuche",
    "快速搜索地点",
    "Быстрый поиск мест",
    "بحث سريع عن مكان"
  ],
  "Hoş geldiniz": [
    "Welcome",
    "Willkommen",
    "欢迎",
    "Добро пожаловать",
    "أهلاً وسهلاً"
  ],
  "IrisMap ile hazırlandı": [
    "Powered by IrisMap",
    "Bereitgestellt von IrisMap",
    "由 IrisMap 提供支持",
    "Работает на IrisMap",
    "مدعوم من IrisMap"
  ],
  "İçerik hazırlanıyor…": [
    "Preparing content…",
    "Inhalt wird vorbereitet…",
    "正在准备内容…",
    "Подготовка содержимого…",
    "جارٍ تجهيز المحتوى…"
  ],
  "İLETİŞİM BİLGİLERİ": [
    "CONTACT & LOCATION",
    "KONTAKT UND LAGE",
    "联络与地址",
    "КОНТАКТЫ И АДРЕС",
    "معلومات الاتصال والموقع"
  ],
  "İnteraktif Harita": [
    "Interactive Map",
    "Interaktive Karte",
    "互动地图",
    "Интерактивная карта",
    "الخريطة التفاعلية"
  ],
  "İnternet bağlantınızı kontrol edip sayfayı yenileyin. Mekân listesi ve rotalar çalışmaya devam eder.": [
    "Check your connection and reload the page. Place lists and routes keep working.",
    "Prüfen Sie Ihre Verbindung und laden Sie die Seite neu. Ortslisten und Routen funktionieren weiterhin.",
    "请检查网络连接并刷新页面。地点列表和路线仍可使用。",
    "Проверьте подключение и обновите страницу. Списки мест и маршруты продолжают работать.",
    "تحقق من اتصالك وأعد تحميل الصفحة. تبقى قوائم الأماكن والمسارات متاحة."
  ],
  "İşaretçiye dokunarak ayrıntıları ve yürüyüş rotasını görün.": [
    "Tap a marker to see details and a walking route.",
    "Tippen Sie auf eine Markierung, um Details und eine Fußroute zu sehen.",
    "点击标记即可查看详情和步行路线。",
    "Нажмите на метку, чтобы увидеть подробности и пеший маршрут.",
    "اضغط على العلامة لعرض التفاصيل ومسار المشي."
  ],
  "Kalp simgesiyle kaydettiğiniz yerleri sıralayıp gerçek bir yürüyüş rotasına dönüştürebilirsiniz.": [
    "Arrange saved places and turn them into a real walking route.",
    "Ordnen Sie gespeicherte Orte und erstellen Sie daraus eine echte Fußroute.",
    "您可以排列收藏地点，并将其转换为真实步行路线。",
    "Упорядочьте сохранённые места и превратите их в реальный пеший маршрут.",
    "رتّب الأماكن المحفوظة وحوّلها إلى مسار مشي فعلي."
  ],
  "Kapalıyken yalnızca otele yakın duraklar görünür.": [
    "When off, only places near the hotel are shown.",
    "Wenn deaktiviert, werden nur Orte in Hotelnähe angezeigt.",
    "关闭时仅显示酒店附近的地点。",
    "Если выключено, показываются только места рядом с отелем.",
    "عند إيقافه تظهر الأماكن القريبة من الفندق فقط."
  ],
  "Kapat": [
    "Close",
    "Schließen",
    "关闭",
    "Закрыть",
    "إغلاق"
  ],
  "Kategoriye göre süz": [
    "Filter by category",
    "Nach Kategorie filtern",
    "按类别筛选",
    "Фильтр по категории",
    "تصفية حسب الفئة"
  ],
  "Kaydet": [
    "Save",
    "Speichern",
    "保存",
    "Сохранить",
    "حفظ"
  ],
  "Kaynak": [
    "Source",
    "Quelle",
    "来源",
    "Источник",
    "المصدر"
  ],
  "Kendi {city} rotanızı oluşturun. Favorilerinizin yanındaki artı simgesiyle durak ekleyebilirsiniz.": [
    "Build your own {city} route. Use the plus icon beside a saved place to add a stop.",
    "Erstellen Sie Ihre eigene Route durch {city}. Mit dem Plus-Symbol neben einem gespeicherten Ort fügen Sie eine Station hinzu.",
    "创建您自己的{city}路线。点击收藏地点旁的加号即可添加站点。",
    "Составьте свой маршрут ({city}). Добавляйте остановки значком «плюс» рядом с сохранённым местом.",
    "أنشئ مسارك الخاص في {city}. استخدم رمز الزائد بجانب المكان المحفوظ لإضافة محطة."
  ],
  "Keşfetmeye Başla": [
    "Start Exploring",
    "Entdecken",
    "开始探索",
    "Начать знакомство",
    "ابدأ الاستكشاف"
  ],
  "Kısa Başlangıç Rehberi": [
    "Quick Start Guide",
    "Kurzanleitung",
    "快速入门指南",
    "Краткое руководство",
    "دليل البدء السريع"
  ],
  "Kısa başlangıç rehberini göster": [
    "Show quick start guide",
    "Kurzanleitung anzeigen",
    "显示快速入门指南",
    "Показать краткое руководство",
    "عرض دليل البدء السريع"
  ],
  "Kısaca": [
    "At a Glance",
    "Kurz erklärt",
    "简介",
    "Кратко",
    "نبذة مختصرة"
  ],
  "Kişisel Planım": [
    "Personal Planner",
    "Mein Reiseplan",
    "个人行程计划",
    "Мой план",
    "خطتي الشخصية"
  ],
  "Kişisel Seyahat Planım": [
    "My Personal Travel Plan",
    "Mein persönlicher Reiseplan",
    "我的个人旅行计划",
    "Мой личный план поездки",
    "خطتي الشخصية للرحلة"
  ],
  "Konaklama Merkeziniz": [
    "Your Accommodation",
    "Ihre Unterkunft",
    "您的住宿地点",
    "Ваш отель",
    "مكان إقامتك"
  ],
  "Konumunuz": [
    "Your location",
    "Ihr Standort",
    "您的位置",
    "Ваше местоположение",
    "موقعك"
  ],
  "Konumunuz alınamadı. Lütfen tarayıcı izinlerini kontrol edin.": [
    "Could not retrieve location. Please check browser permissions.",
    "Ihr Standort konnte nicht ermittelt werden. Prüfen Sie die Browserberechtigungen.",
    "无法获取您的位置，请检查浏览器权限。",
    "Не удалось определить местоположение. Проверьте разрешения браузера.",
    "تعذر تحديد موقعك. يُرجى التحقق من أذونات المتصفح."
  ],
  "Kültür Takvimi": [
    "Culture Calendar",
    "Kulturkalender",
    "文化日历",
    "Календарь событий",
    "الجدول الثقافي"
  ],
  "Kültür ve Sanat Takvimi": [
    "Culture and Arts Calendar",
    "Kultur- und Veranstaltungskalender",
    "文化艺术日历",
    "Календарь культуры и искусства",
    "تقويم الثقافة والفنون"
  ],
  "KÜLTÜREL ETİKET": [
    "CULTURAL ETIQUETTE",
    "KULTURELLE HINWEISE",
    "文化礼仪",
    "КУЛЬТУРНЫЙ ЭТИКЕТ",
    "آداب الزيارة"
  ],
  "MANEVİ YOLCULUK": [
    "SPIRITUAL JOURNEY",
    "SPIRITUELLE REISE",
    "精神之旅",
    "ДУХОВНОЕ ПУТЕШЕСТВИЕ",
    "رحلة روحية"
  ],
  "Medrese / Külliye": [
    "Madrasa / Complex",
    "Medrese / Gebäudekomplex",
    "神学院 / 建筑群",
    "Медресе / комплекс",
    "مدرسة / مجمع"
  ],
  "Mekân kartını kapat": [
    "Close place card",
    "Ortskarte schließen",
    "关闭地点卡片",
    "Закрыть карточку места",
    "إغلاق بطاقة المكان"
  ],
  "Mekân, cami veya müze adı yazın…": [
    "Type a place, mosque or museum name…",
    "Ort, Moschee oder Museum eingeben…",
    "输入地点、清真寺或博物馆名称…",
    "Введите название места, мечети или музея…",
    "اكتب اسم مكان أو مسجد أو متحف…"
  ],
  "Merhaba, {hotel} resepsiyonundan destek almak istiyorum.": [
    "Hello, I would like assistance from {hotel} reception.",
    "Hallo, ich hätte gern Unterstützung von der Rezeption ({hotel}).",
    "您好，我需要{hotel}前台的帮助。",
    "Здравствуйте, мне нужна помощь стойки регистрации ({hotel}).",
    "مرحباً، أود الحصول على مساعدة من استقبال {hotel}."
  ],
  "Merhaba! {hotel} misafir rehberinden geri bildirim gönderiyorum:": [
    "Hello! I am sending feedback from the {hotel} guest guide:",
    "Hallo! Ich sende Feedback aus dem Gästeführer von {hotel}:",
    "您好！我通过{hotel}宾客指南发送反馈：",
    "Здравствуйте! Отправляю отзыв из гостевого путеводителя ({hotel}):",
    "مرحباً! أرسل ملاحظاتي من دليل ضيوف {hotel}:"
  ],
  "Merhaba! {hotel} misafir rehberinden ulaşıyorum. \"{event}\" etkinliği için bilgi almak istiyorum.": [
    "Hello! I am contacting you from the {hotel} guest guide. I would like information about \"{event}\".",
    "Hallo! Ich melde mich über den Gästeführer von {hotel}. Ich hätte gern Informationen zu „{event}“.",
    "您好！我通过{hotel}宾客指南联系您，想咨询活动“{event}”。",
    "Здравствуйте! Пишу из гостевого путеводителя ({hotel}). Мне нужна информация о мероприятии «{event}».",
    "مرحباً! أتواصل معكم عبر دليل ضيوف {hotel}. أود الحصول على معلومات حول فعالية «{event}»."
  ],
  "Merhaba! {hotel} misafir rehberinden ulaşıyorum. Rezervasyon yaptırmak istiyorum.": [
    "Hello! I am contacting you from the {hotel} guest guide. I would like to make a reservation.",
    "Hallo! Ich melde mich über den Gästeführer von {hotel} und möchte ein Zimmer reservieren.",
    "您好！我通过{hotel}宾客指南联系您，想预订房间。",
    "Здравствуйте! Пишу из гостевого путеводителя ({hotel}). Хочу забронировать номер.",
    "مرحباً! أتواصل معكم عبر دليل ضيوف {hotel}. أود إجراء حجز."
  ],
  "Mesaj": [
    "Message",
    "Nachricht",
    "留言",
    "Сообщение",
    "الرسالة"
  ],
  "Misafir geri bildirimi": [
    "Guest feedback",
    "Gästefeedback",
    "宾客反馈",
    "Отзыв гостя",
    "ملاحظات الضيف"
  ],
  "MİSAFİR HİZMETLERİMİZ": [
    "GUEST SERVICES",
    "GÄSTESERVICE",
    "宾客服务",
    "УСЛУГИ ДЛЯ ГОСТЕЙ",
    "خدمات الضيوف"
  ],
  "Müze": [
    "Museum",
    "Museum",
    "博物馆",
    "Музей",
    "متحف"
  ],
  "Not: Tarihî ve dini yapıların mimari özellikleri nedeniyle basamaksız erişim sınırlı olabilir veya talep üzerine sağlanabilir. Ziyaret öncesinde ilgili kurumdan teyit alın.": [
    "Note: Step-free access may be limited at historic and religious sites or available on request. Please confirm with the venue before visiting.",
    "Hinweis: In historischen und religiösen Gebäuden kann der stufenlose Zugang eingeschränkt oder nur auf Anfrage verfügbar sein. Bitte vor dem Besuch nachfragen.",
    "提示：受历史及宗教建筑结构限制，无台阶通道可能有限或需提前申请。参观前请向场馆确认。",
    "Примечание: в исторических и религиозных зданиях безбарьерный доступ может быть ограничен или предоставляться по запросу. Уточните перед посещением.",
    "ملاحظة: قد يكون الوصول دون درجات محدوداً في المواقع التاريخية والدينية أو متاحاً عند الطلب. يُرجى التحقق من الجهة قبل الزيارة."
  ],
  "Oda numaranız (isteğe bağlı)": [
    "Your room number (optional)",
    "Ihre Zimmernummer (optional)",
    "您的房间号（可选）",
    "Номер вашей комнаты (необязательно)",
    "رقم غرفتك (اختياري)"
  ],
  "Oda numaranız bu cihaza kaydedildi.": [
    "Your room number is saved on this device.",
    "Ihre Zimmernummer ist auf diesem Gerät gespeichert.",
    "您的房间号已保存在此设备上。",
    "Номер комнаты сохранён на этом устройстве.",
    "تم حفظ رقم غرفتك على هذا الجهاز."
  ],
  "Oda numarası silindi.": [
    "Room number removed.",
    "Zimmernummer entfernt.",
    "已删除房间号。",
    "Номер комнаты удалён.",
    "تم حذف رقم الغرفة."
  ],
  "Oda numarası yalnızca bu cihazda saklanır; WhatsApp mesajına siz bağlantıyı açtığınızda eklenir.": [
    "Your room number stays on this device and is added only when you open a WhatsApp message.",
    "Ihre Zimmernummer wird nur auf diesem Gerät gespeichert und erst beim Öffnen einer WhatsApp-Nachricht hinzugefügt.",
    "房间号仅保存在此设备上，并只会在您打开 WhatsApp 消息时添加。",
    "Номер комнаты хранится только на этом устройстве и добавляется лишь при открытии сообщения WhatsApp.",
    "يُحفظ رقم الغرفة على هذا الجهاز فقط، ولا يُضاف إلا عند فتح رسالة واتساب."
  ],
  "Otel Bilgileri": [
    "Hotel Information",
    "Hotelinformationen",
    "酒店信息",
    "Об отеле",
    "معلومات الفندق"
  ],
  "Otel hakkında": [
    "About the hotel",
    "Über das Hotel",
    "关于酒店",
    "Об отеле",
    "عن الفندق"
  ],
  "OTEL SEÇKİSİ": [
    "HOTEL SELECTION",
    "AUSWAHL DES HOTELS",
    "酒店精选",
    "ВЫБОР ОТЕЛЯ",
    "اختيار الفندق"
  ],
  "Otel ve iletişim": [
    "Hotel and contact",
    "Hotel und Kontakt",
    "酒店与联系",
    "Отель и контакты",
    "الفندق والتواصل"
  ],
  "Otel Web Sitesi": [
    "Hotel Website",
    "Hotelwebseite",
    "酒店网站",
    "Сайт отеля",
    "موقع الفندق"
  ],
  "Önceden teyit edin": [
    "Confirm ahead",
    "Vorher bestätigen",
    "请提前确认",
    "Уточните заранее",
    "تحقق مسبقاً"
  ],
  "Önceki fotoğraf": [
    "Previous photo",
    "Vorheriges Foto",
    "上一张照片",
    "Предыдущее фото",
    "الصورة السابقة"
  ],
  "Öne çıkan ve keşfedilecek yerler": [
    "Featured places and more to discover",
    "Empfohlene Orte und weitere Entdeckungen",
    "精选地点与更多探索",
    "Главные места и новые открытия",
    "أماكن مختارة والمزيد للاستكشاف"
  ],
  "ÖNEMLİ TELEFONLAR": [
    "IMPORTANT CONTACTS",
    "WICHTIGE KONTAKTE",
    "重要联系电话",
    "ВАЖНЫЕ ТЕЛЕФОНЫ",
    "أرقام مهمة"
  ],
  "Önerilen süre": [
    "Suggested time",
    "Empfohlene Dauer",
    "建议时长",
    "Рекомендуемое время",
    "المدة المقترحة"
  ],
  "Örn. 204": [
    "e.g. 204",
    "z. B. 204",
    "例如：204",
    "Например, 204",
    "مثال: 204"
  ],
  "ÖZEL ROTA PLANLAYICIM": [
    "MY CUSTOM ROUTE PLANNER",
    "MEIN ROUTENPLANER",
    "我的自定义路线",
    "МОЙ КОНСТРУКТОР МАРШРУТА",
    "مخطط مساري الخاص"
  ],
  "Paylaş": [
    "Share",
    "Teilen",
    "分享",
    "Поделиться",
    "مشاركة"
  ],
  "Paylaşım bağlantısı panoya kopyalandı!": [
    "Share link copied to the clipboard!",
    "Link wurde in die Zwischenablage kopiert!",
    "分享链接已复制到剪贴板！",
    "Ссылка скопирована!",
    "تم نسخ رابط المشاركة!"
  ],
  "Planım": [
    "My Plan",
    "Mein Plan",
    "我的计划",
    "Мой план",
    "خطتي"
  ],
  "Popüler Gezilecek Yerler": [
    "Popular Historical Sites",
    "Beliebte Sehenswürdigkeiten",
    "热门历史遗迹",
    "Популярные достопримечательности",
    "الأماكن التاريخية الشهيرة"
  ],
  "Pratik Bilgiler": [
    "Practical Info",
    "Praktische Hinweise",
    "实用信息",
    "Полезная информация",
    "معلومات عملية"
  ],
  "Pratik Gezi Rehberi": [
    "Practical Guest Guide",
    "Praktischer Gästeführer",
    "实用旅行指南",
    "Практический путеводитель",
    "دليل عملي للضيف"
  ],
  "Programdan teyit edin": [
    "Confirm in the program",
    "Im Programm bestätigen",
    "请在官方日程中确认",
    "Уточните в программе",
    "تحقق من البرنامج"
  ],
  "Rehber ayarlarınız": [
    "Your guide settings",
    "Ihre Reiseführer-Einstellungen",
    "您的指南设置",
    "Настройки путеводителя",
    "إعدادات دليلك"
  ],
  "Rehber geçici olarak görüntülenemiyor": [
    "The guide is temporarily unavailable",
    "Der Reiseführer ist vorübergehend nicht verfügbar",
    "指南暂时无法显示",
    "Путеводитель временно недоступен",
    "يتعذر عرض الدليل مؤقتاً"
  ],
  "Rehber Hizmeti": [
    "Guide service",
    "Führungsservice",
    "导览服务",
    "Услуги гида",
    "خدمة مرشد"
  ],
  "Rehbere Devam Et": [
    "Continue to Guide",
    "Weiter zum Reiseführer",
    "继续查看指南",
    "Перейти к путеводителю",
    "متابعة إلى الدليل"
  ],
  "Rehberi konaklamanıza göre kişiselleştirebilir ve resepsiyon mesajlarınıza oda bilginizi otomatik ekleyebiliriz.": [
    "Personalize the guide and automatically include your room in reception messages.",
    "Personalisieren Sie den Reiseführer und fügen Sie Ihre Zimmernummer automatisch zu Nachrichten an die Rezeption hinzu.",
    "您可以按入住需求个性化本指南，并在联系前台时自动附上房间号。",
    "Настройте путеводитель под себя и автоматически добавляйте номер комнаты в сообщения на стойку регистрации.",
    "يمكنك تخصيص الدليل حسب إقامتك وإضافة رقم غرفتك تلقائياً إلى رسائل الاستقبال."
  ],
  "RESEPSİYON / MİSAFİR DESTEĞİ": [
    "RECEPTION / GUEST SUPPORT",
    "REZEPTION / GÄSTESERVICE",
    "前台 / 宾客支持",
    "СТОЙКА РЕГИСТРАЦИИ / ПОМОЩЬ",
    "الاستقبال / دعم الضيوف"
  ],
  "Resepsiyondan Bilgi Al": [
    "Ask Reception",
    "An der Rezeption fragen",
    "咨询前台",
    "Уточнить на стойке регистрации",
    "الاستفسار من الاستقبال"
  ],
  "Resepsiyonu Ara": [
    "Call Reception",
    "Rezeption anrufen",
    "致电前台",
    "Позвонить на стойку регистрации",
    "الاتصال بالاستقبال"
  ],
  "Resmî Türkçe adı": [
    "Official Turkish name",
    "Offizieller türkischer Name",
    "土耳其语官方名称",
    "Официальное турецкое название",
    "الاسم التركي الرسمي"
  ],
  "Rezervasyon Gerekebilir": [
    "Booking may be required",
    "Reservierung kann erforderlich sein",
    "可能需要预约",
    "Может потребоваться бронь",
    "قد يلزم الحجز"
  ],
  "REZERVASYON YAP": [
    "BOOK A ROOM",
    "ZIMMER BUCHEN",
    "预订客房",
    "ЗАБРОНИРОВАТЬ НОМЕР",
    "احجز غرفة"
  ],
  "ROTA DURAKLARI": [
    "ROUTE STOPS",
    "ROUTENSTOPPS",
    "路线站点",
    "ОСТАНОВКИ МАРШРУТА",
    "محطات المسار"
  ],
  "Rota hesaplanamadı. Uygulama haritasında veya Google Haritalar’da yeniden deneyebilirsiniz.": [
    "The route could not be calculated. Try again in the app map or Google Maps.",
    "Die Route konnte nicht berechnet werden. Versuchen Sie es in der App-Karte oder in Google Maps erneut.",
    "无法计算路线，请在应用地图或 Google 地图中重试。",
    "Не удалось рассчитать маршрут. Повторите попытку на карте приложения или в Google Картах.",
    "تعذر حساب المسار. حاول مرة أخرى في خريطة التطبيق أو خرائط غوغل."
  ],
  "Rotadan çıkar": [
    "Remove from route",
    "Aus der Route entfernen",
    "从路线移除",
    "Удалить из маршрута",
    "إزالة من المسار"
  ],
  "Rotalar": [
    "Routes",
    "Routen",
    "路线",
    "Маршруты",
    "المسارات"
  ],
  "Rotaya ekle": [
    "Add to route",
    "Zur Route hinzufügen",
    "添加到路线",
    "Добавить в маршрут",
    "إضافة إلى المسار"
  ],
  "Rotayı kapat": [
    "Close route",
    "Route schließen",
    "关闭路线",
    "Закрыть маршрут",
    "إغلاق المسار"
  ],
  "Rotayı sıfırla": [
    "Reset route",
    "Route zurücksetzen",
    "重置路线",
    "Сбросить маршрут",
    "إعادة ضبط المسار"
  ],
  "Rotayı uygulama haritasında aç": [
    "Open route in app map",
    "Route in der App-Karte öffnen",
    "在应用地图中打开路线",
    "Открыть маршрут на карте приложения",
    "فتح المسار في خريطة التطبيق"
  ],
  "saat": [
    "hours",
    "Stunden",
    "小时",
    "часа",
    "ساعات"
  ],
  "Sağlık ve Güvence": [
    "Safety and Emergency Help",
    "Sicherheit und Notfallhilfe",
    "安全与紧急协助",
    "Безопасность и экстренная помощь",
    "السلامة والمساعدة الطارئة"
  ],
  "Sayfayı Yenile": [
    "Reload Page",
    "Seite neu laden",
    "刷新页面",
    "Обновить страницу",
    "إعادة تحميل الصفحة"
  ],
  "Seçili Gezi Rotası": [
    "Selected Tour Route",
    "Ausgewählte Tour",
    "已选游览路线",
    "Выбранный маршрут",
    "مسار الجولة المحدد"
  ],
  "Seçimleriniz bu cihazda saklanır": [
    "Your choices are saved on this device",
    "Ihre Auswahl wird auf diesem Gerät gespeichert",
    "您的选择会保存在此设备上",
    "Ваш выбор сохраняется на этом устройстве",
    "تُحفظ اختياراتك على هذا الجهاز"
  ],
  "Seçtiğiniz durak sırasına göre gerçek yaya güzergâhı kullanılmıştır.": [
    "A real walking route is used in the selected stop order.",
    "Es wird eine reale Fußroute in der gewählten Reihenfolge der Stopps verwendet.",
    "系统按您选择的站点顺序使用真实步行路线。",
    "Используется реальный пеший маршрут в выбранном порядке остановок.",
    "تم استخدام مسار مشي فعلي وفق ترتيب المحطات الذي اخترته."
  ],
  "Sema ve Kültür": [
    "Sema and Culture",
    "Sema und Kultur",
    "旋转礼与文化",
    "Сема и культура",
    "السماع والثقافة"
  ],
  "Sesli anlatım bu tarayıcıda desteklenmiyor.": [
    "Text-to-speech is not supported in this browser.",
    "Sprachausgabe wird von diesem Browser nicht unterstützt.",
    "此浏览器不支持语音朗读。",
    "Этот браузер не поддерживает озвучивание.",
    "هذا المتصفح لا يدعم القراءة الصوتية."
  ],
  "Sesli Dinle": [
    "Listen",
    "Anhören",
    "语音朗读",
    "Прослушать",
    "استمع"
  ],
  "Sohbeti temizle": [
    "Clear chat",
    "Chat löschen",
    "清空对话",
    "Очистить чат",
    "مسح المحادثة"
  ],
  "Son doğrulama": [
    "Last verified",
    "Zuletzt geprüft",
    "最近核实",
    "Последняя проверка",
    "آخر تحقق"
  ],
  "Sonraki fotoğraf": [
    "Next photo",
    "Nächstes Foto",
    "下一张照片",
    "Следующее фото",
    "الصورة التالية"
  ],
  "Sorularınız için dijital asistan": [
    "Digital assistant for your questions",
    "Digitaler Assistent für Ihre Fragen",
    "为您答疑的数字助手",
    "Цифровой помощник для ваших вопросов",
    "مساعد رقمي لأسئلتك"
  ],
  "Soruyu gönder": [
    "Send question",
    "Frage senden",
    "发送问题",
    "Отправить вопрос",
    "إرسال السؤال"
  ],
  "Şehir veya otel hakkında bir şeyler sorun…": [
    "Ask anything about the city or the hotel…",
    "Fragen Sie etwas über die Stadt oder das Hotel…",
    "询问有关城市或酒店的任何问题…",
    "Спросите о городе или отеле…",
    "اسأل عن المدينة أو الفندق…"
  ],
  "Şehre ilk kez gelen misafirlerimiz için seçtiğimiz öne çıkan duraklar.": [
    "Essential stops selected for first-time visitors.",
    "Ausgewählte Höhepunkte für Gäste, die zum ersten Mal hier sind.",
    "为首次到访的宾客精选的必游景点。",
    "Главные места, отобранные для тех, кто впервые в городе.",
    "محطات بارزة اخترناها للضيوف الذين يزورون المدينة لأول مرة."
  ],
  "Şimdilik Atla": [
    "Skip for Now",
    "Vorerst überspringen",
    "暂时跳过",
    "Пока пропустить",
    "تخطَّ الآن"
  ],
  "Şu an neredeyim?": [
    "Where am I?",
    "Wo bin ich?",
    "我在哪里？",
    "Где я?",
    "أين أنا الآن؟"
  ],
  "ŞU ANDA": [
    "HAPPENING NOW",
    "JETZT",
    "正在进行",
    "СЕЙЧАС",
    "يجري الآن"
  ],
  "Şu anda doğrulanmış yaklaşan etkinlik bulunmuyor.": [
    "There are no verified upcoming events at the moment.",
    "Derzeit gibt es keine bestätigten bevorstehenden Veranstaltungen.",
    "目前没有已核实的近期活动。",
    "Сейчас нет подтверждённых предстоящих событий.",
    "لا توجد حالياً فعاليات قادمة تم التحقق منها."
  ],
  "TALEP ÜZERİNE": [
    "ON REQUEST",
    "AUF ANFRAGE",
    "按需提供",
    "ПО ЗАПРОСУ",
    "عند الطلب"
  ],
  "Tarayıcınız harita için gereken grafik desteğini sunmuyor. Mekân listesi, rotalar ve Google Haritalar bağlantıları çalışmaya devam eder.": [
    "Your browser lacks the graphics support the map needs. Place lists, routes and Google Maps links keep working.",
    "Ihr Browser bietet nicht die Grafikunterstützung, die die Karte benötigt. Ortslisten, Routen und Google-Maps-Links funktionieren weiterhin.",
    "您的浏览器不支持地图所需的图形功能。地点列表、路线和 Google 地图链接仍可使用。",
    "Ваш браузер не поддерживает графику, необходимую для карты. Списки мест, маршруты и ссылки на Google Карты продолжают работать.",
    "متصفحك لا يدعم الرسوميات اللازمة للخريطة. تبقى قوائم الأماكن والمسارات وروابط خرائط Google متاحة."
  ],
  "Tarayıcınız konum özelliğini desteklemiyor.": [
    "Geolocation is not supported by your browser.",
    "Ihr Browser unterstützt keine Standortbestimmung.",
    "您的浏览器不支持定位。",
    "Ваш браузер не поддерживает геолокацию.",
    "متصفحك لا يدعم تحديد الموقع."
  ],
  "TARİHÇE VE KÜLTÜR": [
    "HISTORY & HERITAGE",
    "GESCHICHTE UND KULTUR",
    "历史与文化",
    "ИСТОРИЯ И КУЛЬТУРА",
    "التاريخ والثقافة"
  ],
  "TARİHÎ ROTA": [
    "HISTORIC ROUTE",
    "HISTORISCHE ROUTE",
    "历史路线",
    "ИСТОРИЧЕСКИЙ МАРШРУТ",
    "مسار تاريخي"
  ],
  "Tarihî Yapı": [
    "Historic Site",
    "Historische Stätte",
    "历史遗迹",
    "Исторический объект",
    "معلم تاريخي"
  ],
  "Tek destinasyon seçildi; rota mesafesi hesaplanmaz.": [
    "One destination selected; route distance is not calculated.",
    "Ein Ziel ausgewählt; die Routenentfernung wird nicht berechnet.",
    "已选择一个目的地；不计算路线距离。",
    "Выбрано одно место; расстояние маршрута не рассчитывается.",
    "تم اختيار وجهة واحدة؛ لا تُحسب مسافة المسار."
  ],
  "Tekerlekli Sandalye": [
    "Wheelchair access",
    "Rollstuhlzugang",
    "轮椅通道",
    "Доступ на коляске",
    "دخول الكرسي المتحرك"
  ],
  "Tercihler": [
    "Preferences",
    "Einstellungen",
    "偏好设置",
    "Предпочтения",
    "التفضيلات"
  ],
  "Toplam Yürüyüş Mesafesi": [
    "Total Walking Distance",
    "Gesamte Gehstrecke",
    "总步行距离",
    "Общее расстояние пешком",
    "إجمالي مسافة المشي"
  ],
  "Tur rotası etkin": [
    "Tour route active",
    "Tourroute aktiv",
    "游览路线已启用",
    "Маршрут включён",
    "مسار الجولة نشط"
  ],
  "Turizm Keşif Modülleri": [
    "Explore Konya",
    "Konya entdecken",
    "探索科尼亚",
    "Исследуйте Конью",
    "استكشف قونية"
  ],
  "Tüm kayıtlı bilgileriniz bu cihazdan silinsin mi?": [
    "Delete all your saved information from this device?",
    "Alle gespeicherten Angaben von diesem Gerät löschen?",
    "要从此设备删除您保存的所有信息吗？",
    "Удалить все сохранённые данные с этого устройства?",
    "هل تريد حذف كل معلوماتك المحفوظة من هذا الجهاز؟"
  ],
  "Tüm Mekânları Gör": [
    "View All Places",
    "Alle Orte anzeigen",
    "查看所有地点",
    "Показать все места",
    "عرض جميع الأماكن"
  ],
  "Tüm mekânları göster": [
    "Show all places",
    "Alle Orte anzeigen",
    "显示所有地点",
    "Показывать все места",
    "عرض جميع الأماكن"
  ],
  "Tümü": [
    "All",
    "Alle",
    "全部",
    "Все",
    "الكل"
  ],
  "Tümünü Gör": [
    "See All",
    "Alle anzeigen",
    "查看全部",
    "Показать все",
    "عرض الكل"
  ],
  "Türbe / Kabir": [
    "Tomb / Shrine",
    "Mausoleum / Grab",
    "陵墓 / 圣墓",
    "Мавзолей / гробница",
    "ضريح / قبر"
  ],
  "UNESCO Eseri": [
    "UNESCO Site",
    "UNESCO-Stätte",
    "联合国教科文组织遗产",
    "Объект ЮНЕСКО",
    "موقع يونسكو"
  ],
  "Uygulama dili": [
    "App language",
    "App-Sprache",
    "应用语言",
    "Язык приложения",
    "لغة التطبيق"
  ],
  "Uygulama dilini ve haritada gösterilecek mekân kapsamını seçin. Tercihleriniz bu cihazda saklanır.": [
    "Choose the app language and which places appear on the map. Your preferences are saved on this device.",
    "Wählen Sie die App-Sprache und den Umfang der Orte auf der Karte. Ihre Auswahl wird auf diesem Gerät gespeichert.",
    "选择应用语言以及地图上显示的地点范围。您的偏好会保存在此设备上。",
    "Выберите язык приложения и охват мест на карте. Ваши настройки сохраняются на этом устройстве.",
    "اختر لغة التطبيق ونطاق الأماكن الظاهرة على الخريطة. تُحفظ تفضيلاتك على هذا الجهاز."
  ],
  "Uygulama Haritasında Gör": [
    "View on App Map",
    "Auf der App-Karte anzeigen",
    "在应用地图中查看",
    "Показать на карте приложения",
    "عرض في خريطة التطبيق"
  ],
  "Üç adımlı tanıtımı istediğiniz zaman yeniden açın.": [
    "Replay the three-step introduction at any time.",
    "Die dreistufige Einführung kann jederzeit erneut geöffnet werden.",
    "您可以随时重新打开三步介绍。",
    "Трёхэтапное знакомство можно открыть снова в любое время.",
    "يمكنك إعادة المقدمة المكوّنة من ثلاث خطوات في أي وقت."
  ],
  "Üzgünüm, şu an bağlantı kuramıyorum. Lütfen daha sonra tekrar deneyiniz.": [
    "I cannot connect right now. Please try again later.",
    "Derzeit kann keine Verbindung hergestellt werden. Bitte versuchen Sie es später erneut.",
    "目前无法连接，请稍后重试。",
    "Сейчас не удаётся подключиться. Повторите попытку позже.",
    "يتعذر الاتصال الآن. يُرجى المحاولة لاحقاً."
  ],
  "Vazgeç": [
    "Cancel",
    "Abbrechen",
    "取消",
    "Отмена",
    "إلغاء"
  ],
  "WhatsApp Destek": [
    "WhatsApp Support",
    "WhatsApp-Support",
    "WhatsApp 客服",
    "Поддержка в WhatsApp",
    "دعم عبر واتساب"
  ],
  "WhatsApp görüşmesi açıldı. Mesajınızı WhatsApp üzerinden göndererek işlemi tamamlayabilirsiniz.": [
    "WhatsApp opened. Send the prepared message there to complete your feedback.",
    "WhatsApp wurde geöffnet. Senden Sie dort die vorbereitete Nachricht, um Ihr Feedback abzuschließen.",
    "WhatsApp 已打开。请发送准备好的消息以完成反馈。",
    "WhatsApp открыт. Отправьте подготовленное сообщение, чтобы завершить отправку отзыва.",
    "تم فتح واتساب. أرسل الرسالة المُعدّة لإكمال إرسال ملاحظاتك."
  ],
  "WHATSAPP'TA GERİ BİLDİRİM HAZIRLA": [
    "PREPARE FEEDBACK IN WHATSAPP",
    "FEEDBACK IN WHATSAPP VORBEREITEN",
    "在 WHATSAPP 中准备反馈",
    "ПОДГОТОВИТЬ ОТЗЫВ В WHATSAPP",
    "تجهيز الملاحظات في واتساب"
  ],
  "Yakındaki Mekânlar": [
    "Nearby Places",
    "Orte in der Nähe",
    "附近地点",
    "Места рядом",
    "أماكن قريبة"
  ],
  "YAKLAŞAN ETKİNLİK": [
    "UPCOMING EVENT",
    "BEVORSTEHENDE VERANSTALTUNG",
    "即将举行",
    "ПРЕДСТОЯЩЕЕ СОБЫТИЕ",
    "فعالية قادمة"
  ],
  "Yaklaşan etkinlikler": [
    "Upcoming events",
    "Bevorstehende Veranstaltungen",
    "近期活动",
    "Предстоящие события",
    "الفعاليات القادمة"
  ],
  "Yanıt hazırlanıyor": [
    "Preparing an answer",
    "Antwort wird vorbereitet",
    "正在生成回答",
    "Готовим ответ",
    "جارٍ إعداد الإجابة"
  ],
  "Yapay Zeka Rehberi": [
    "AI Concierge Guide",
    "KI-Reiseführer",
    "AI 智能导游",
    "ИИ-путеводитель",
    "دليل الذكاء الاصطناعي"
  ],
  "Yaya güzergâhı": [
    "Walking route",
    "Fußweg",
    "步行路线",
    "Пеший маршрут",
    "مسار المشي"
  ],
  "YEREL İPUÇLARI": [
    "LOCAL TRAVEL TIPS",
    "LOKALE TIPPS",
    "本地旅行提示",
    "МЕСТНЫЕ СОВЕТЫ",
    "نصائح محلية"
  ],
  "Yerel Kültür Etkinliği": [
    "Local Cultural Event",
    "Lokale Kulturveranstaltung",
    "本地文化活动",
    "Местное культурное событие",
    "فعالية ثقافية محلية"
  ],
  "Yukarı taşı": [
    "Move up",
    "Nach oben",
    "上移",
    "Переместить вверх",
    "نقل للأعلى"
  ],
  "Yürüyüş Rotası": [
    "Walking Route",
    "Fußroute",
    "步行路线",
    "Пеший маршрут",
    "مسار المشي"
  ],
  "Yürüyüş rotası hesaplanıyor…": [
    "Calculating the walking route…",
    "Fußroute wird berechnet…",
    "正在计算步行路线…",
    "Расчёт пешего маршрута…",
    "جارٍ حساب مسار المشي…"
  ],
  "Yürüyüş Süresi": [
    "Walking Duration",
    "Gehzeit",
    "步行时间",
    "Время пешком",
    "مدة المشي"
  ],
  "Ziyaret ipuçları": [
    "Visitor tips",
    "Besuchstipps",
    "参观提示",
    "Советы посетителям",
    "نصائح للزيارة"
  ],
  "Ziyaret Notu": [
    "Visit note",
    "Besuchshinweis",
    "参观提示",
    "Примечание к посещению",
    "ملاحظة الزيارة"
  ],
  "Ziyaret öncesi teyit edin": [
    "Confirm before visiting",
    "Vor dem Besuch bestätigen",
    "参观前请确认",
    "Уточните перед посещением",
    "تحقق قبل الزيارة"
  ],
  "Ziyaret Saatleri": [
    "Visiting Hours",
    "Besuchszeiten",
    "开放时间",
    "Время посещения",
    "أوقات الزيارة"
  ],
  "Gizlilik ve kişisel veriler": [
    "Privacy and personal data",
    "Datenschutz und personenbezogene Daten",
    "隐私与个人数据",
    "Конфиденциальность и персональные данные",
    "الخصوصية والبيانات الشخصية"
  ],
  "Hangi bilgilerin nasıl kullanıldığını okuyun (KVKK).": [
    "Read what information is used and how (KVKK/GDPR).",
    "Lesen Sie, welche Daten wie verwendet werden (DSGVO).",
    "了解哪些信息被使用以及如何使用（KVKK/GDPR）。",
    "Узнайте, какие данные используются и как (KVKK/GDPR).",
    "اطّلع على المعلومات المستخدمة وكيفية استخدامها."
  ],
  "Kaynaklar ve lisanslar": [
    "Sources and licences",
    "Quellen und Lizenzen",
    "数据来源与许可",
    "Источники и лицензии",
    "المصادر والتراخيص"
  ],
  "Harita verileri": [
    "Map data",
    "Kartendaten",
    "地图数据",
    "Картографические данные",
    "بيانات الخريطة"
  ],
  "Harita görüntüleri": [
    "Map images",
    "Kartenbilder",
    "地图图像",
    "Изображения карты",
    "صور الخريطة"
  ],
  "Mekân fotoğrafları": [
    "Place photos",
    "Fotos der Orte",
    "景点照片",
    "Фотографии мест",
    "صور الأماكن"
  ],
  "Her fotoğrafın lisansı fotoğrafla birlikte gösterilir.": [
    "Each photo shows its own licence.",
    "Die Lizenz jedes Fotos wird beim Foto angezeigt.",
    "每张照片的许可信息显示在照片旁。",
    "Лицензия каждой фотографии указана рядом с ней.",
    "يظهر ترخيص كل صورة بجانبها."
  ],
  "Hava durumu verileri": [
    "Weather data",
    "Wetterdaten",
    "天气数据",
    "Данные о погоде",
    "بيانات الطقس"
  ],
  "Açık kaynak yazılım lisansları": [
    "Open-source software licences",
    "Open-Source-Lizenzen",
    "开源软件许可",
    "Лицензии открытого ПО",
    "تراخيص البرمجيات مفتوحة المصدر"
  ],
  "Harita görüntüsü şu anda yüklenemiyor; otel ve gezilecek yerler yine de gösteriliyor.": [
    "The map images cannot be loaded right now; the hotel and places are still shown.",
    "Die Kartenbilder können gerade nicht geladen werden; Hotel und Sehenswürdigkeiten werden trotzdem angezeigt.",
    "暂时无法加载地图图像；酒店和景点仍会显示。",
    "Сейчас не удаётся загрузить изображение карты; отель и достопримечательности всё равно показаны.",
    "تعذّر تحميل صور الخريطة حالياً، ومع ذلك يظهر الفندق والمعالم على الخريطة."
  ],
  "yedek": [
    "fallback",
    "Ersatz",
    "备用",
    "резерв",
    "احتياطي"
  ],
};

const LANGUAGE_INDEX: Record<Exclude<Language, "TR">, number> = {
  EN: 0,
  DE: 1,
  ZH: 2,
  RU: 3,
  AR: 4,
};

export const UI_TRANSLATIONS: Record<string, Record<Language, string>> =
  Object.fromEntries(
    Object.entries(UI_ROWS).map(([turkish, values]) => [
      turkish,
      {
        TR: turkish,
        EN: values[LANGUAGE_INDEX.EN],
        DE: values[LANGUAGE_INDEX.DE],
        ZH: values[LANGUAGE_INDEX.ZH],
        RU: values[LANGUAGE_INDEX.RU],
        AR: values[LANGUAGE_INDEX.AR],
      },
    ]),
  );
