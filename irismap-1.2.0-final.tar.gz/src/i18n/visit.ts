import type { Language } from "../types";

type Localized = Record<Language, string>;

const pick = (language: Language, values: Localized) => values[language] || values.TR;

const HOURS = {
  verify: {
    TR: "Ziyaret öncesinde güncel saatleri teyit edin.",
    EN: "Confirm current hours before visiting.",
    DE: "Bestätigen Sie die aktuellen Zeiten vor dem Besuch.",
    ZH: "参观前请确认最新开放时间。",
    RU: "Уточните актуальные часы перед посещением.",
    AR: "تحقق من ساعات الزيارة الحالية قبل الذهاب.",
  },
  worship: {
    TR: "İbadet saatleri dışında ziyaret önerilir; önceden teyit edin.",
    EN: "Visit outside prayer times; confirm ahead.",
    DE: "Besuch außerhalb der Gebetszeiten; vorher bestätigen.",
    ZH: "建议避开礼拜时间，并提前确认。",
    RU: "Рекомендуется посещение вне времени молитв; уточните заранее.",
    AR: "يُنصح بالزيارة خارج أوقات الصلاة مع التحقق مسبقاً.",
  },
  allDay: {
    TR: "24 saat erişilebilir; güncel koşulları teyit edin.",
    EN: "Accessible 24 hours; confirm current conditions.",
    DE: "24 Stunden zugänglich; aktuelle Bedingungen bestätigen.",
    ZH: "全天可进入；请确认当前情况。",
    RU: "Доступно круглосуточно; уточните текущие условия.",
    AR: "متاح على مدار الساعة؛ تحقق من الظروف الحالية.",
  },
  schedule: {
    TR: "Sema ve etkinlik programına göre değişir; programdan teyit edin.",
    EN: "Varies by the sema and event schedule; confirm in the program.",
    DE: "Abhängig vom Sema- und Veranstaltungsprogramm; im Programm bestätigen.",
    ZH: "开放安排随旋转舞及活动日程变化；请查看官方日程。",
    RU: "Зависит от расписания сема и мероприятий; уточните в программе.",
    AR: "تختلف حسب برنامج السماح والفعاليات؛ تحقق من البرنامج.",
  },
} satisfies Record<string, Localized>;

const NOTES = {
  museum: {
    TR: "İç mekân erişimi, restorasyon ve özel kullanım durumu ziyaret öncesinde teyit edilmelidir.",
    EN: "Confirm indoor access, restoration work, and special-use restrictions before visiting.",
    DE: "Innenzugang, Restaurierungsarbeiten und Sondernutzung vor dem Besuch bestätigen.",
    ZH: "参观前请确认室内开放、修缮及特殊使用安排。",
    RU: "Перед посещением уточните доступ внутрь, реставрацию и ограничения из-за специальных мероприятий.",
    AR: "تحقق قبل الزيارة من إتاحة الدخول وأعمال الترميم والاستخدامات الخاصة.",
  },
  inventory: {
    TR: "Bu kayıt kültür envanteri niteliğindedir; alanın ziyaret edilebilir olduğu varsayılmamalıdır.",
    EN: "This is a cultural-inventory record; do not assume the site is open to visitors.",
    DE: "Dies ist ein Eintrag im Kulturinventar; eine Besichtigung ist nicht automatisch möglich.",
    ZH: "此记录属于文化遗产名录，不代表该地点一定对游客开放。",
    RU: "Это объект культурного реестра; не следует считать, что он открыт для посещения.",
    AR: "هذا سجل ضمن الجرد الثقافي، ولا يعني بالضرورة أن الموقع مفتوح للزيارة.",
  },
  nature: {
    TR: "Gün ışığında ziyaret önerilir. Hava, yol, telefon çekimi ve saha güvenliğini aynı gün teyit edin.",
    EN: "A daylight visit is recommended. Check weather, road access, phone coverage, and site safety on the same day.",
    DE: "Ein Besuch bei Tageslicht wird empfohlen. Wetter, Zufahrt, Mobilfunkempfang und Sicherheit am selben Tag prüfen.",
    ZH: "建议白天前往，并在当天确认天气、道路、手机信号及现场安全情况。",
    RU: "Рекомендуется посещать днём. В день поездки проверьте погоду, дорогу, связь и безопасность.",
    AR: "يُنصح بالزيارة نهاراً. تحقق في اليوم نفسه من الطقس والطريق وتغطية الهاتف وسلامة الموقع.",
  },
  worship: {
    TR: "Uygun kıyafet, sessizlik ve ibadet edenlerin mahremiyetine saygı gerekir; cami girişinde ayakkabılar çıkarılır.",
    EN: "Dress modestly, remain quiet, respect worshippers’ privacy, and remove shoes at mosque entrances.",
    DE: "Angemessene Kleidung, Ruhe und Rücksicht auf Betende sind erforderlich; Schuhe am Moscheeeingang ausziehen.",
    ZH: "请着装得体、保持安静、尊重礼拜者隐私，并在清真寺入口脱鞋。",
    RU: "Соблюдайте скромную одежду и тишину, уважайте молящихся и снимайте обувь при входе в мечеть.",
    AR: "يجب ارتداء ملابس محتشمة والتزام الهدوء واحترام خصوصية المصلين وخلع الأحذية عند دخول المسجد.",
  },
  schedule: {
    TR: "Son giriş, haftalık kapanış, bakım ve özel gün değişikliklerini ziyaret öncesinde teyit edin.",
    EN: "Confirm last admission, weekly closures, maintenance, and special-day changes before visiting.",
    DE: "Letzten Einlass, Ruhetage, Wartung und Änderungen an Feiertagen vor dem Besuch bestätigen.",
    ZH: "参观前请确认最晚入场、每周闭馆、维护及特殊日期调整。",
    RU: "Перед посещением уточните последний вход, выходные дни, обслуживание и изменения в особые даты.",
    AR: "تحقق قبل الزيارة من آخر دخول والإغلاق الأسبوعي والصيانة وتغييرات الأيام الخاصة.",
  },
  closed: {
    TR: "Alan açık/saatli gösterilmemelidir; yeniden açılış yalnızca resmî duyuruyla doğrulanabilir.",
    EN: "Do not treat the site as open; reopening must be confirmed by an official announcement.",
    DE: "Der Ort darf nicht als geöffnet gelten; eine Wiedereröffnung muss offiziell bestätigt werden.",
    ZH: "请勿将该地点视为开放；重新开放须以官方公告为准。",
    RU: "Не считайте объект открытым; повторное открытие должно быть подтверждено официально.",
    AR: "لا تعتبر الموقع مفتوحاً؛ يجب تأكيد إعادة الافتتاح بإعلان رسمي.",
  },
  tropical: {
    TR: "Tropikal bölüm sıcak ve yüksek nemlidir; ısı veya solunum hassasiyeti olan ziyaretçiler mola planlamalıdır.",
    EN: "The tropical area is hot and humid; visitors sensitive to heat or breathing conditions should plan breaks.",
    DE: "Der Tropenbereich ist warm und feucht; hitze- oder atemempfindliche Gäste sollten Pausen einplanen.",
    ZH: "热带区域温暖且湿度较高；对高温或呼吸敏感的游客应安排休息。",
    RU: "В тропической зоне жарко и влажно; чувствительным к жаре или дыхательным нагрузкам стоит планировать перерывы.",
    AR: "القسم الاستوائي حار وعالي الرطوبة؛ ينبغي لمن لديهم حساسية للحرارة أو التنفس التخطيط للاستراحة.",
  },
  ticket: {
    TR: "Bilet, rezervasyon, yaş sınırı, başlangıç ve son giriş bilgilerini programdan teyit edin.",
    EN: "Confirm tickets, reservations, age limits, start time, and last admission in the program.",
    DE: "Tickets, Reservierung, Altersgrenzen, Beginn und letzten Einlass im Programm bestätigen.",
    ZH: "请在官方日程中确认门票、预约、年龄限制、开始时间及最晚入场。",
    RU: "Уточните в программе билеты, бронирование, возрастные ограничения, начало и последний вход.",
    AR: "تحقق من البرنامج بشأن التذاكر والحجز والحد العمري ووقت البدء وآخر دخول.",
  },
  performance: {
    TR: "Başlangıçtan önce gelin; bilet, oturma düzeni ve fotoğraf/video kurallarını programdan teyit edin.",
    EN: "Arrive before the start and confirm tickets, seating, and photo/video rules in the program.",
    DE: "Vor Beginn eintreffen und Tickets, Sitzordnung sowie Foto-/Videoregeln im Programm prüfen.",
    ZH: "请提前到场，并在日程中确认门票、座位及拍照录像规定。",
    RU: "Приходите заранее и уточните в программе билеты, рассадку и правила фото/видео.",
    AR: "احضر قبل البداية وتحقق من البرنامج بشأن التذاكر وترتيب المقاعد وقواعد التصوير.",
  },
  science: {
    TR: "Planetaryum ve atölyeler için seans, yaş sınırı ve kapasiteyi ayrıca teyit edin.",
    EN: "Confirm session times, age limits, and capacity for the planetarium and workshops.",
    DE: "Zeiten, Altersgrenzen und Kapazität für Planetarium und Workshops gesondert bestätigen.",
    ZH: "请另行确认天文馆及工作坊的场次、年龄限制和容量。",
    RU: "Отдельно уточните сеансы, возрастные ограничения и вместимость планетария и мастерских.",
    AR: "تحقق بشكل منفصل من مواعيد القبة الفلكية والورش والحد العمري والسعة.",
  },
} satisfies Record<string, Localized>;

const timeRanges = (value: string) =>
  value.match(/\d{1,2}:\d{2}\s*[–-]\s*\d{1,2}:\d{2}/g)?.map((item) => item.replace(/\s*-\s*/g, "–")) || [];

const lastAdmission = (value: string) =>
  value.match(/gişe\s*(\d{1,2}:\d{2})/i)?.[1] || null;

export const visitHours = (raw: string | undefined, language: Language) => {
  if (!raw) return pick(language, HOURS.verify);
  if (language === "TR") return raw;

  const ranges = timeRanges(raw);
  const ticketTime = lastAdmission(raw);
  const range = ranges[0] || raw.match(/\d{1,2}:\d{2}/)?.[0] || "";
  const daily = pick(language, {
    TR: "Her gün",
    EN: "Daily",
    DE: "Täglich",
    ZH: "每日",
    RU: "Ежедневно",
    AR: "يومياً",
  });
  const weekdays = pick(language, {
    TR: "Hafta içi",
    EN: "Weekdays",
    DE: "Werktags",
    ZH: "工作日",
    RU: "По будням",
    AR: "أيام الأسبوع",
  });
  const tuesdaySunday = pick(language, {
    TR: "Salı–Pazar",
    EN: "Tuesday–Sunday",
    DE: "Dienstag–Sonntag",
    ZH: "周二至周日",
    RU: "Вторник–воскресенье",
    AR: "الثلاثاء–الأحد",
  });
  const mondayClosed = pick(language, {
    TR: "Pazartesi kapalı",
    EN: "Monday closed",
    DE: "Montags geschlossen",
    ZH: "周一闭馆",
    RU: "Понедельник — выходной",
    AR: "مغلق يوم الاثنين",
  });
  const lastEntry = ticketTime
    ? `${pick(language, { TR: "son giriş", EN: "last admission", DE: "letzter Einlass", ZH: "最晚入场", RU: "последний вход", AR: "آخر دخول" })} ${ticketTime}`
    : "";

  if (/Ziyaret öncesinde|güncel erişim|Sabit genel ziyaret saati net/i.test(raw)) return pick(language, HOURS.verify);
  if (/İbadet saatleri/i.test(raw)) return pick(language, HOURS.worship);
  if (/24 Saat/i.test(raw)) return pick(language, HOURS.allDay);
  if (/Sema ve etkinlik/i.test(raw)) return pick(language, HOURS.schedule);
  if (/hafta içi 09:00–17:00, hafta sonu 10:00–18:00/i.test(raw)) {
    return pick(language, {
      TR: raw,
      EN: "Weekdays 09:00–17:00; weekends 10:00–18:00; Monday closed. Confirm special schedules.",
      DE: "Werktags 09:00–17:00; am Wochenende 10:00–18:00; montags geschlossen. Sonderzeiten bestätigen.",
      ZH: "工作日09:00–17:00；周末10:00–18:00；周一闭馆。请确认特殊安排。",
      RU: "Будни 09:00–17:00; выходные 10:00–18:00; понедельник — выходной. Уточните особое расписание.",
      AR: "أيام الأسبوع 09:00–17:00؛ عطلة نهاية الأسبوع 10:00–18:00؛ مغلق الاثنين. تحقق من المواعيد الخاصة.",
    });
  }

  const pieces: string[] = [];
  if (/Salı|Tuesday/i.test(raw)) pieces.push(tuesdaySunday);
  else if (/Hafta İçi/i.test(raw)) pieces.push(weekdays);
  else if (/Her gün|Hergün/i.test(raw)) pieces.push(daily);
  if (range) pieces.push(range);
  if (lastEntry) pieces.push(lastEntry);
  if (/Pazartesi kapalı/i.test(raw)) pieces.push(mondayClosed);
  return pieces.length ? pieces.join(" · ") : pick(language, HOURS.verify);
};

export const visitNote = (raw: string | undefined, language: Language) => {
  if (!raw || language === "TR") return raw || pick(language, NOTES.schedule);
  if (/kültür envanteri/i.test(raw)) return pick(language, NOTES.inventory);
  if (/Uygun kıyafet|ibadet edenlerin|Yoğunluk yüksektir/i.test(raw)) return pick(language, NOTES.worship);
  if (/Tropikal bölüm/i.test(raw)) return pick(language, NOTES.tropical);
  if (/Planetaryum/i.test(raw)) return pick(language, NOTES.science);
  if (/Başlangıçtan önce/i.test(raw)) return pick(language, NOTES.performance);
  if (/Bilet\/rezervasyon|yaş sınırı/i.test(raw)) return pick(language, NOTES.ticket);
  if (/açık\/saatli gösterilmemeli/i.test(raw)) return pick(language, NOTES.closed);
  if (/Gün ışığında|Güneş, sıcaklık|Kuzey Korugan/i.test(raw)) {
    const base = pick(language, NOTES.nature);
    if (/Mağara girişleri/i.test(raw)) {
      return `${base} ${pick(language, {
        TR: "Mağara girişleri kaygan olabilir; rehbersiz giriş uygun olmayabilir.",
        EN: "Cave entrances may be slippery; unguided entry may be unsuitable.",
        DE: "Höhleneingänge können rutschig sein; ein Besuch ohne Führung kann ungeeignet sein.",
        ZH: "洞穴入口可能湿滑，不建议无向导进入。",
        RU: "Входы в пещеры могут быть скользкими; посещение без гида может быть небезопасным.",
        AR: "قد تكون مداخل الكهوف زلقة وقد لا يكون الدخول دون دليل مناسباً.",
      })}`;
    }
    if (/Yüzme alanı/i.test(raw)) {
      return `${base} ${pick(language, {
        TR: "Yüzme alanı ve cankurtaran durumunu ayrıca teyit edin.",
        EN: "Also confirm the swimming area and lifeguard status.",
        DE: "Zusätzlich Badebereich und Rettungsschwimmer bestätigen.",
        ZH: "另请确认游泳区域及救生员情况。",
        RU: "Также уточните наличие зоны для купания и спасателей.",
        AR: "تحقق أيضاً من منطقة السباحة ووجود المنقذين.",
      })}`;
    }
    return base;
  }
  if (/İç mekân|Müze bölümü|Öğrenci grupları/i.test(raw)) return pick(language, NOTES.museum);
  return pick(language, NOTES.schedule);
};

export const visitDuration = (
  minimum: number | null | undefined,
  maximum: number | null | undefined,
  fallback: number,
  language: Language,
) => {
  const value = minimum && maximum
    ? `${minimum}–${maximum}`
    : fallback > 0 ? String(fallback) : "";
  if (!value) {
    return pick(language, {
      TR: "Planınıza göre",
      EN: "Depends on your plan",
      DE: "Je nach Planung",
      ZH: "根据您的计划",
      RU: "Зависит от вашего плана",
      AR: "حسب خطتك",
    });
  }
  const unit = pick(language, {
    TR: "dakika",
    EN: "minutes",
    DE: "Minuten",
    ZH: "分钟",
    RU: "минут",
    AR: "دقيقة",
  });
  return `${value} ${unit}`;
};
