import { formatText } from "../../shared/languages";
import type { Language } from "../types";

export interface TutorialStep {
  title: string;
  text: string;
}

type StepTexts = [TutorialStep, TutorialStep, TutorialStep, string];

/** Three steps; the last item is the third step's text for hotels without WhatsApp. */
const TUTORIAL_STEPS: Record<Language, StepTexts> = {
  TR: [
    {
      title: "{city} rehberiniz hazır",
      text: "{hotel} çevresindeki önemli yerleri keşfedin, mekân ayrıntılarını inceleyin ve gezi planınızı tek yerde oluşturun.",
    },
    {
      title: "Harita ve rotalarla keşfedin",
      text: "Haritadaki bir işaretçiye dokunarak mekânı inceleyin, uygulama içi yürüyüş rotası oluşturun veya Google Haritalar’da açın. Hazır Rotalar bölümünde otelden başlayan seçkiler bulunur.",
    },
    {
      title: "Planlayın, kaydedin, destek alın",
      text: "Kalp simgesiyle yerleri Planım’a ekleyin ve gezi sıranızı düzenleyin. Resepsiyonu arayabilir veya WhatsApp’tan yazabilirsiniz; kaydettiğiniz oda numarası yalnızca hazırlanmış WhatsApp mesajına eklenir.",
    },
    "Kalp simgesiyle yerleri Planım’a ekleyin ve gezi sıranızı düzenleyin. Sorularınız için resepsiyona her zaman ulaşabilirsiniz.",
  ],
  EN: [
    {
      title: "Your {city} guide is ready",
      text: "Discover important places around {hotel}, review practical details, and build your visit plan in one place.",
    },
    {
      title: "Explore with maps and routes",
      text: "Tap a map marker to view a place, create an in-app walking route, or open it in Google Maps. Curated routes include selections starting from the hotel.",
    },
    {
      title: "Plan, save, and get support",
      text: "Use the heart icon to add places to My Plan and arrange your visit order. You can call reception or write on WhatsApp; your saved room number is added only to the prepared WhatsApp message.",
    },
    "Use the heart icon to add places to My Plan and arrange your visit order. Reception is always happy to help with your questions.",
  ],
  DE: [
    {
      title: "Ihr Reiseführer für {city} ist bereit",
      text: "Entdecken Sie wichtige Orte rund um {hotel}, sehen Sie praktische Details an und planen Sie Ihren Besuch an einem Ort.",
    },
    {
      title: "Mit Karte und Routen entdecken",
      text: "Tippen Sie auf eine Kartenmarkierung, um einen Ort anzusehen, eine Fußroute in der App zu erstellen oder ihn in Google Maps zu öffnen. Fertige Routen starten am Hotel.",
    },
    {
      title: "Planen, speichern und Hilfe erhalten",
      text: "Mit dem Herzsymbol fügen Sie Orte zu „Mein Plan“ hinzu und ordnen Ihren Besuch. Sie können die Rezeption anrufen oder per WhatsApp schreiben; die gespeicherte Zimmernummer wird nur der vorbereiteten WhatsApp-Nachricht hinzugefügt.",
    },
    "Mit dem Herzsymbol fügen Sie Orte zu „Mein Plan“ hinzu und ordnen Ihren Besuch. Bei Fragen hilft Ihnen die Rezeption jederzeit gern.",
  ],
  ZH: [
    {
      title: "您的{city}指南已准备就绪",
      text: "探索{hotel}周边的重要地点，查看实用详情，并在一个地方安排您的游览计划。",
    },
    {
      title: "通过地图与路线探索",
      text: "点击地图标记可查看地点、在应用内生成步行路线，或在 Google 地图中打开。精选路线包含从酒店出发的方案。",
    },
    {
      title: "规划、收藏并获取帮助",
      text: "点击心形图标把地点加入“我的计划”，并安排游览顺序。您可以致电前台或通过 WhatsApp 联系；已保存的房间号仅会加入预先生成的 WhatsApp 消息。",
    },
    "点击心形图标把地点加入“我的计划”，并安排游览顺序。如有疑问，欢迎随时联系前台。",
  ],
  RU: [
    {
      title: "Ваш путеводитель готов · {city}",
      text: "Открывайте важные места рядом с отелем ({hotel}), смотрите полезные сведения и составляйте план посещения в одном месте.",
    },
    {
      title: "Исследуйте город по карте и маршрутам",
      text: "Нажмите на метку, чтобы открыть место, построить пеший маршрут в приложении или перейти в Google Карты. Готовые маршруты включают варианты от отеля.",
    },
    {
      title: "Планируйте, сохраняйте и обращайтесь за помощью",
      text: "Добавляйте места в «Мой план» значком сердца и меняйте порядок посещения. Вы можете позвонить на стойку регистрации или написать в WhatsApp; сохранённый номер комнаты добавляется только в подготовленное сообщение WhatsApp.",
    },
    "Добавляйте места в «Мой план» значком сердца и меняйте порядок посещения. Стойка регистрации всегда готова помочь с вопросами.",
  ],
  AR: [
    {
      title: "دليلك إلى {city} جاهز",
      text: "اكتشف أهم الأماكن حول {hotel}، واطّلع على التفاصيل المفيدة، وأنشئ خطة زيارتك في مكان واحد.",
    },
    {
      title: "استكشف بالخريطة والمسارات",
      text: "اضغط على علامة في الخريطة لعرض المكان أو إنشاء مسار مشي داخل التطبيق أو فتحه في خرائط Google. تتضمن المسارات الجاهزة خيارات تبدأ من الفندق.",
    },
    {
      title: "خطط واحفظ واحصل على الدعم",
      text: "استخدم رمز القلب لإضافة الأماكن إلى «خطتي» ورتّب زيارتك. يمكنك الاتصال بالاستقبال أو مراسلته عبر WhatsApp؛ ويُضاف رقم الغرفة المحفوظ إلى رسالة WhatsApp المُعدّة فقط.",
    },
    "استخدم رمز القلب لإضافة الأماكن إلى «خطتي» ورتّب زيارتك. يسعد فريق الاستقبال بمساعدتك في أي وقت.",
  ],
};

export function getTutorialSteps(
  language: Language,
  values: { hotel: string; city: string; hasWhatsApp: boolean },
): TutorialStep[] {
  const [first, second, third, thirdWithoutWhatsApp] = TUTORIAL_STEPS[language] ?? TUTORIAL_STEPS.EN;
  const names = { hotel: values.hotel, city: values.city };
  const fill = (step: TutorialStep): TutorialStep => ({
    title: formatText(step.title, names),
    text: formatText(step.text, names),
  });
  return [
    fill(first),
    fill(second),
    fill(values.hasWhatsApp ? third : { title: third.title, text: thirdWithoutWhatsApp }),
  ];
}
