import { formatText, LANGUAGES } from "../../shared/languages";
import type { Language } from "../types";
import { UI_TRANSLATIONS } from "./ui.generated";

export const SUPPORTED_LANGUAGES: Language[] = [...LANGUAGES];

export const LANGUAGE_LABELS: Record<Language, string> = {
  TR: "Türkçe",
  EN: "English",
  DE: "Deutsch",
  ZH: "中文",
  RU: "Русский",
  AR: "العربية",
};

/**
 * Interface text lookup. The Turkish text is the catalogue key and the
 * English text the fallback; `{name}` placeholders are filled from `values`.
 */
export function ui(
  language: Language,
  turkish: string,
  english: string,
  values?: Record<string, string | number>,
): string {
  const row = UI_TRANSLATIONS[turkish as keyof typeof UI_TRANSLATIONS] as Partial<Record<Language, string>> | undefined;
  const text = row?.[language] ?? (language === "TR" ? turkish : english);
  return values ? formatText(text, values) : text;
}

export const isRtlLanguage = (language: Language) => language === "AR";

export const localeForLanguage: Record<Language, string> = {
  TR: "tr-TR",
  EN: "en-GB",
  DE: "de-DE",
  ZH: "zh-CN",
  RU: "ru-RU",
  AR: "ar-SA",
};
