import { DESIGNS, FONT_FALLBACKS, type DesignId } from "../../shared/designs";
import type { BrandPalette, BrandVariant } from "../../shared/hotelConfig";

const VARIABLES: Record<keyof BrandPalette, string> = {
  primary: "--im-primary",
  primaryInk: "--im-primary-ink",
  primaryDeep: "--im-primary-deep",
  accent: "--im-accent",
  accentSoft: "--im-accent-soft",
  page: "--im-page",
  card: "--im-card",
  soft: "--im-soft",
  ink: "--im-ink",
  line: "--im-line",
  logoFrame: "--im-logo-frame",
};

/** Writes the palette to CSS variables used by the Tailwind brand utilities. */
export function applyBrandVariant(variant: BrandVariant, root: HTMLElement = document.documentElement) {
  for (const [key, variable] of Object.entries(VARIABLES) as Array<[keyof BrandPalette, string]>) {
    root.style.setProperty(variable, variant.palette[key]);
  }
  root.dataset.brandVariant = variant.id;
  let themeColor = document.querySelector<HTMLMetaElement>('meta[name="theme-color"]');
  if (!themeColor) {
    themeColor = document.createElement("meta");
    themeColor.name = "theme-color";
    document.head.appendChild(themeColor);
  }
  themeColor.content = variant.palette.primary;
}

/**
 * Applies a ready-made design: typefaces (Tailwind's --font-serif for headings
 * and --font-sans for text), corner radii and the banner pattern.
 */
export function applyDesign(design: DesignId, root: HTMLElement = document.documentElement) {
  const preset = DESIGNS[design] ?? DESIGNS.modern;
  root.style.setProperty("--font-serif", `"${preset.headingFont}", ${FONT_FALLBACKS}, Georgia, serif`);
  root.style.setProperty("--font-sans", `"${preset.bodyFont}", ${FONT_FALLBACKS}, ui-sans-serif, system-ui, sans-serif`);
  for (const [size, value] of Object.entries(preset.radius)) root.style.setProperty(`--radius-${size}`, value);
  root.style.setProperty("--im-hero-pattern", preset.pattern ?? "none");
  root.dataset.design = preset.id;
}
