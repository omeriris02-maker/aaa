import { EventItem } from "../types";

export type EventOccurrence = {
  start: number;
  end: number;
  year: number;
};

const ordinal = (year: number, month: number, day: number) =>
  year * 10_000 + month * 100 + day;

export function resolveEventOccurrence(
  event: EventItem,
  currentYear: number,
  currentOrdinal: number,
): EventOccurrence | null {
  if (event.recurrence === "fixed-annual") {
    let year = currentYear;
    let start = ordinal(year, event.baslangic_ay, event.baslangic_gun);
    let endYear = event.bitis_ay < event.baslangic_ay ? year + 1 : year;
    let end = ordinal(endYear, event.bitis_ay, event.bitis_gun);
    if (currentOrdinal > end) {
      year += 1;
      start = ordinal(year, event.baslangic_ay, event.baslangic_gun);
      endYear = event.bitis_ay < event.baslangic_ay ? year + 1 : year;
      end = ordinal(endYear, event.bitis_ay, event.bitis_gun);
    }
    return { start, end, year };
  }

  if (event.dateStatus !== "confirmed") return null;
  const start = ordinal(event.baslangic_yil, event.baslangic_ay, event.baslangic_gun);
  const end = ordinal(event.bitis_yil, event.bitis_ay, event.bitis_gun);
  if (currentOrdinal > end) return null;
  return { start, end, year: event.baslangic_yil };
}

export function eventOccurrenceStatus(
  occurrence: EventOccurrence,
  currentOrdinal: number,
): "active" | "upcoming" {
  return currentOrdinal >= occurrence.start && currentOrdinal <= occurrence.end
    ? "active"
    : "upcoming";
}
