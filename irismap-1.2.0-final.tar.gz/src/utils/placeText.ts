import { placeHistory, placeSummary } from "../i18n/content";
import type { Language, Place } from "../types";
import { matchesSearch } from "./search";

/** Every text a guest might type to find a place, in all languages. */
export const placeSearchFields = (place: Place): Array<string | undefined> => [
  place.isim_tr,
  place.isim_en,
  place.isim_de,
  place.isim_zh,
  place.isim_ru,
  place.isim_ar,
  place.kategori,
  place.aciklama_kisa_tr,
  place.aciklama_kisa_en,
  place.aciklama_kisa_de,
  place.aciklama_kisa_zh,
  place.aciklama_kisa_ru,
  place.aciklama_kisa_ar,
  ...(place.etiketler ?? []),
];

export const placeMatches = (place: Place, query: string) => matchesSearch(query, placeSearchFields(place));

/**
 * Card text: the short summary, extended with one or two history sentences
 * when the summary alone is very short.
 */
export function placeCardDescription(place: Place, language: Language): string {
  const summary = placeSummary(place, language).trim();
  if (summary.length >= 135) return summary;
  const history = placeHistory(place, language).trim();
  const lowerSummary = summary.toLocaleLowerCase();
  const extra = history
    .split(/(?<=[.!?])\s+|(?<=[。！？])/u)
    .filter((sentence) => sentence.length > 25 && !lowerSummary.includes(sentence.toLocaleLowerCase()))
    .slice(0, summary.length < 70 ? 2 : 1)
    .join(" ");
  if (!extra) return summary;
  return `${summary}${/[.!?。！？]$/u.test(summary) ? "" : "."} ${extra}`;
}
