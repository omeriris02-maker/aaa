import type { Language } from "../types";
import { readString, removeKey, writeString } from "./storage";

const ROOM_KEY = "guest-room";

export function getStoredRoomNumber(): string {
  return readString(ROOM_KEY) ?? "";
}

/** Keeps letters, digits and dashes only (max 12) and stores it on this device. */
export function saveStoredRoomNumber(roomNumber: string): string {
  const cleanRoom = roomNumber.replace(/[^\p{L}\p{N}-]/gu, "").slice(0, 12);
  if (cleanRoom) writeString(ROOM_KEY, cleanRoom);
  else removeKey(ROOM_KEY);
  return cleanRoom;
}

const ROOM_LABELS: Record<Language, string> = {
  TR: "Oda",
  EN: "Room",
  DE: "Zimmer",
  ZH: "房间",
  RU: "Комната",
  AR: "رقم الغرفة",
};

/** Prefixes a message with the guest's room number when one is stored. */
export function addGuestContext(message: string, language: Language, roomNumber = getStoredRoomNumber()): string {
  if (!roomNumber) return message;
  return `${ROOM_LABELS[language]}: ${roomNumber}\n${message}`;
}

/** wa.me link for a WhatsApp number given as digits with country code (e.g. 905015234242). */
export function createWhatsAppUrl(
  whatsappNumber: string,
  message: string,
  language: Language,
  roomNumber?: string,
): string {
  const digits = whatsappNumber.replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(addGuestContext(message, language, roomNumber))}`;
}

export function createMailtoUrl(email: string, subject: string, body: string): string {
  return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/** Opens an external link in a new tab without giving it access to this page. */
export function openExternal(url: string) {
  const opened = window.open(url, "_blank", "noopener,noreferrer");
  if (!opened) window.location.href = url;
}
