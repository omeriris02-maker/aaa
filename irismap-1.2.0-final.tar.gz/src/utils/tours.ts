import type { HotelConfig } from "../../shared/hotelConfig";
import { formatText, pickText, type LocalizedText } from "../../shared/languages";
import type { Language, Place, Tour } from "../types";

/** Id of the generated "walk around the hotel" tour (outside the content pack's ids). */
export const AROUND_HOTEL_TOUR_ID = 900;

/** Typical extra distance of a real walking route compared with straight lines. */
const WALKING_DETOUR_FACTOR = 1.3;
const WALKING_SPEED_KMH = 4.5;
/** A walking tour pauses briefly at each stop; full museum visits are planned separately. */
const DEFAULT_STOP_MINUTES = 12;
const MAX_STOP_MINUTES = 20;

export interface LatLng {
  lat: number;
  lng: number;
}

export function distanceMeters(a: LatLng, b: LatLng): number {
  const toRadians = (value: number) => value * Math.PI / 180;
  const earthRadius = 6_371_000;
  const deltaLat = toRadians(b.lat - a.lat);
  const deltaLng = toRadians(b.lng - a.lng);
  const value = Math.sin(deltaLat / 2) ** 2
    + Math.cos(toRadians(a.lat)) * Math.cos(toRadians(b.lat)) * Math.sin(deltaLng / 2) ** 2;
  return earthRadius * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

const placePoint = (place: Place): LatLng => ({ lat: place.koordinatlar.lat, lng: place.koordinatlar.lng });

/** Orders stops greedily: always walk to the nearest unvisited stop next. */
export function orderByNearestNeighbour(start: LatLng, places: Place[]): Place[] {
  const remaining = [...places];
  const ordered: Place[] = [];
  let current = start;
  while (remaining.length > 0) {
    let bestIndex = 0;
    let bestDistance = Number.POSITIVE_INFINITY;
    remaining.forEach((place, index) => {
      const distance = distanceMeters(current, placePoint(place));
      if (distance < bestDistance) {
        bestDistance = distance;
        bestIndex = index;
      }
    });
    const [next] = remaining.splice(bestIndex, 1);
    ordered.push(next);
    current = placePoint(next);
  }
  return ordered;
}

const TOUR_TEXT: Record<"name" | "summary" | "briefing", LocalizedText> = {
  name: {
    TR: "{hotel} Çevresi Yürüyüşü",
    EN: "Walk Around {hotel}",
    DE: "Spaziergang rund um {hotel}",
    ZH: "{hotel}周边漫步",
    RU: "Прогулка рядом с отелем · {hotel}",
    AR: "جولة حول {hotel}",
  },
  summary: {
    TR: "Otelden başlayan kolay bir yürüyüşle en yakın {count} tarihî ve kültürel durağı keşfedin.",
    EN: "An easy walk from the hotel linking the {count} closest historic and cultural stops.",
    DE: "Ein leichter Rundgang ab dem Hotel zu den {count} nächstgelegenen historischen und kulturellen Stationen.",
    ZH: "从酒店出发，串联附近{count}处历史与文化景点的轻松步行路线。",
    RU: "Лёгкая прогулка от отеля по ближайшим историческим и культурным местам (остановок: {count}).",
    AR: "جولة مشي سهلة تبدأ من الفندق وتجمع أقرب {count} معالم تاريخية وثقافية.",
  },
  briefing: {
    TR: "Otel resepsiyonundan başlayın ve durakları sırasıyla takip edin. Toplam süre, her mekânda ayıracağınız zamana göre değişir; ibadet saatlerine saygı gösterin ve açılış saatlerini önceden teyit edin.",
    EN: "Start at hotel reception and follow the stops in order. Total time depends on how long you spend at each place; respect worship times and confirm opening hours before you go.",
    DE: "Starten Sie an der Hotelrezeption und folgen Sie den Stationen der Reihe nach. Die Gesamtdauer hängt von Ihrer Aufenthaltszeit ab; beachten Sie Gebetszeiten und prüfen Sie die Öffnungszeiten vorab.",
    ZH: "从酒店前台出发，按顺序游览各站。总时长取决于每处停留时间；请尊重礼拜安排，并在出发前确认开放时间。",
    RU: "Начните у стойки регистрации отеля и следуйте остановкам по порядку. Общее время зависит от длительности посещений; учитывайте время молитв и заранее уточняйте часы работы.",
    AR: "ابدأ من استقبال الفندق واتبع المحطات بالترتيب. تعتمد المدة الإجمالية على وقتك في كل موقع؛ راعِ أوقات العبادة وتحقق من ساعات الزيارة مسبقاً.",
  },
};

/**
 * Builds the hotel's own walking tour: the configured stops in their given
 * order, or otherwise the closest places inside the configured radius in a
 * nearest-neighbour order. Returns null when fewer than two stops qualify.
 */
export function buildAroundHotelTour(
  config: HotelConfig,
  places: Place[],
  aliases: Readonly<Record<number, number>> = {},
): Tour | null {
  const settings = config.aroundHotelTour;
  if (!settings.enabled) return null;
  const hotel: LatLng = { lat: config.location.lat, lng: config.location.lng };
  const byId = new Map(places.map((place) => [place.id, place]));

  let stops: Place[];
  if (settings.placeIds.length > 0) {
    stops = [...new Set(settings.placeIds.map((id) => aliases[id] ?? id))]
      .map((id) => byId.get(id))
      .filter((place): place is Place => Boolean(place));
  } else {
    const nearby = places
      .filter((place) => place.kategori !== "Otel")
      .map((place) => ({ place, distance: distanceMeters(hotel, placePoint(place)) }))
      .filter((item) => item.distance <= settings.radiusMeters)
      .sort((a, b) => a.distance - b.distance || a.place.id - b.place.id)
      .slice(0, settings.maxStops)
      .map((item) => item.place);
    stops = orderByNearestNeighbour(hotel, nearby);
  }
  if (stops.length < 2) return null;

  let pathMeters = 0;
  let previous = hotel;
  for (const stop of stops) {
    pathMeters += distanceMeters(previous, placePoint(stop));
    previous = placePoint(stop);
  }
  const distanceKm = Math.max(0.1, Math.round((pathMeters * WALKING_DETOUR_FACTOR) / 100) / 10);
  const visitMinutes = stops.reduce(
    (total, stop) => total + (stop.ziyaret_suresi_dk > 0 ? Math.min(stop.ziyaret_suresi_dk, MAX_STOP_MINUTES) : DEFAULT_STOP_MINUTES),
    0,
  );
  const walkMinutes = (distanceKm / WALKING_SPEED_KMH) * 60;
  const hours = Math.max(0.5, Math.round(((visitMinutes + walkMinutes) / 60) * 2) / 2);

  const text = (key: keyof typeof TOUR_TEXT, language: Language) =>
    formatText(pickText(TOUR_TEXT[key], language), {
      hotel: pickText(config.name, language, config.defaultLanguage),
      count: stops.length,
    });

  return {
    id: AROUND_HOTEL_TOUR_ID,
    isim_tr: text("name", "TR"),
    isim_en: text("name", "EN"),
    isim_de: text("name", "DE"),
    isim_zh: text("name", "ZH"),
    isim_ru: text("name", "RU"),
    isim_ar: text("name", "AR"),
    aciklama_tr: text("summary", "TR"),
    aciklama_en: text("summary", "EN"),
    aciklama_de: text("summary", "DE"),
    aciklama_zh: text("summary", "ZH"),
    aciklama_ru: text("summary", "RU"),
    aciklama_ar: text("summary", "AR"),
    briefing_tr: text("briefing", "TR"),
    briefing_en: text("briefing", "EN"),
    briefing_de: text("briefing", "DE"),
    briefing_zh: text("briefing", "ZH"),
    briefing_ru: text("briefing", "RU"),
    briefing_ar: text("briefing", "AR"),
    duraklar: stops.map((stop) => stop.id),
    mesafe_km: distanceKm,
    sure_saat: hours,
    gorsel_icon: "MapPin",
  };
}

/** Pack tours plus the hotel's own tour first. Tours whose stops are missing are dropped. */
export function toursForHotel(
  config: HotelConfig,
  places: Place[],
  packTours: Tour[],
  aliases: Readonly<Record<number, number>> = {},
): Tour[] {
  const placeIds = new Set(places.map((place) => place.id));
  const usable = packTours
    .map((tour) => ({ ...tour, duraklar: tour.duraklar.filter((id) => placeIds.has(id)) }))
    .filter((tour) => tour.duraklar.length >= 2);
  const own = buildAroundHotelTour(config, places, aliases);
  return own ? [own, ...usable] : usable;
}
