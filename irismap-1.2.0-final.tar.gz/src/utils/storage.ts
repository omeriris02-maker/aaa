/**
 * Safe wrappers around localStorage. Private browsing modes, disabled site
 * data or full quotas make localStorage throw; the guide must keep working.
 */
const PREFIX = "irismap:";

const storage = (): Storage | null => {
  try {
    return typeof window !== "undefined" ? window.localStorage : null;
  } catch {
    return null;
  }
};

export function readString(key: string): string | null {
  try {
    return storage()?.getItem(PREFIX + key) ?? null;
  } catch {
    return null;
  }
}

export function writeString(key: string, value: string): void {
  try {
    storage()?.setItem(PREFIX + key, value);
  } catch {
    // Storage unavailable or full: the preference simply is not remembered.
  }
}

export function removeKey(key: string): void {
  try {
    storage()?.removeItem(PREFIX + key);
  } catch {
    // Ignore unavailable storage.
  }
}

export function readFlag(key: string): boolean {
  return readString(key) === "1";
}

export function writeFlag(key: string): void {
  writeString(key, "1");
}

/** Reads a stored list of positive whole numbers (place ids), dropping anything else. */
export function readIdList(key: string): number[] {
  const raw = readString(key);
  if (!raw) return [];
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return [...new Set(parsed.filter((value): value is number => Number.isInteger(value) && value > 0))];
  } catch {
    return [];
  }
}

export function writeIdList(key: string, ids: number[]): void {
  writeString(key, JSON.stringify(ids));
}

export function readJson<T>(key: string): T | null {
  const raw = readString(key);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function writeJson(key: string, value: unknown): void {
  writeString(key, JSON.stringify(value));
}

/** Keys used by the earlier single-hotel guide, copied once so guests keep their plans. */
const LEGACY_KEYS: Record<string, string> = {
  sircali_lang: "lang",
  sircali_favorites: "favorites",
  sircali_checklist: "checklist",
  sircali_custom_route: "custom-route",
  sircali_guest_room: "guest-room",
  sircali_guest_welcome_seen: "welcome-seen",
  sircali_onboarding_v2_seen: "onboarding-seen",
  sircali_map_tip_seen: "map-tip-seen",
  sircali_plan_tip_seen: "plan-tip-seen",
  sircali_show_all_places: "show-all-places",
};

export function migrateLegacyStorage(): void {
  const store = storage();
  if (!store) return;
  try {
    if (store.getItem(`${PREFIX}migrated`) === "1") return;
    for (const [legacyKey, key] of Object.entries(LEGACY_KEYS)) {
      const value = store.getItem(legacyKey);
      if (value !== null && store.getItem(PREFIX + key) === null) store.setItem(PREFIX + key, value);
    }
    // Old route caches and the retired manual theme choice are not carried over.
    for (let index = store.length - 1; index >= 0; index -= 1) {
      const key = store.key(index);
      if (key && (key.startsWith("sircali_") || key.startsWith("sircali-"))) store.removeItem(key);
    }
    store.setItem(`${PREFIX}migrated`, "1");
  } catch {
    // Storage unavailable: nothing to migrate.
  }
}

/** Deletes everything IrisMap stored on this device (used by "delete my data"). */
export function clearAllStoredData(): void {
  const store = storage();
  if (!store) return;
  try {
    for (let index = store.length - 1; index >= 0; index -= 1) {
      const key = store.key(index);
      if (key && key.startsWith(PREFIX) && key !== `${PREFIX}migrated`) store.removeItem(key);
    }
  } catch {
    // Storage unavailable: nothing stored.
  }
}
