/**
 * Small, dependency-free toast. Messages are announced to screen readers
 * through a single polite live region.
 */
let region: HTMLDivElement | null = null;
let hideTimer: number | undefined;

export function showToast(message: string, durationMs = 3000) {
  if (typeof document === "undefined") return;
  if (!region) {
    region = document.createElement("div");
    region.setAttribute("role", "status");
    region.setAttribute("aria-live", "polite");
    region.className = "pointer-events-none fixed inset-x-4 bottom-24 z-[9999] mx-auto flex max-w-sm justify-center md:bottom-8";
    document.body.appendChild(region);
  }
  region.innerHTML = "";
  const toast = document.createElement("div");
  toast.className = "animate-fade-in rounded-full border border-accent/40 bg-brand px-5 py-3 text-center text-xs font-semibold text-white shadow-2xl";
  toast.textContent = message;
  region.appendChild(toast);
  window.clearTimeout(hideTimer);
  hideTimer = window.setTimeout(() => {
    if (region) region.innerHTML = "";
  }, durationMs);
}
