import type { Place } from "./types";
import destinations from "./destinations-100.json";
import destinationMedia from "./destination-media.json";
import { toArabicName } from "./i18n/transliteration";

type DestinationRecord = {
  ID: string;
  "Eser Adı": string;
  Kategori: string;
  İlçe: string;
  Mahalle: string;
  Adres: string;
  "Nihai Latitude": number;
  "Nihai Longitude": number;
  "Kısa Açıklama": string;
  "Uzun Açıklama": string;
  "Yapım Tarihi": string;
  Dönemi: string;
  "Ziyaret Durumu": string;
  "Giriş Ücreti": string;
  "Ziyaret Saatleri": string;
  "Ana Kaynak": string;
  "Koordinat Güven Seviyesi": string;
};

type DestinationMediaItem = {
  url: string;
  sourceUrl: string;
  source: string;
  license: string;
  title: string;
};

const getCategory = (category: string): Place["kategori"] => {
  const value = category.toLocaleLowerCase("tr-TR");
  if (value.includes("unesco")) return "UNESCO";
  if (value.includes("müze")) return "Müze";
  if (value.includes("cami") || value.includes("mescit")) return "Cami";
  if (value.includes("türbe") || value.includes("kümbet")) return "Türbe";
  if (value.includes("medrese")) return "Medrese";
  if (value.includes("park") || value.includes("göl") || value.includes("şelale") || value.includes("mağara")) return "Park";
  return "Tarihi Yapı";
};

const parseHours = (hours: string) => ({
  "Güncel ziyaret bilgisi": hours || "Ziyaret öncesinde resmî kaynaktan doğrulayın"
});

const categoryText = (category: Place["kategori"]) => ({
  en: {
    UNESCO: "heritage site",
    Müze: "museum",
    Cami: "mosque",
    Türbe: "mausoleum",
    Medrese: "madrasa",
    "Tarihi Yapı": "cultural site",
    Park: "natural or recreational area",
    Otel: "hotel",
  }[category],
  de: {
    UNESCO: "Kulturerbestätte",
    Müze: "Museum",
    Cami: "Moschee",
    Türbe: "Mausoleum",
    Medrese: "Medrese",
    "Tarihi Yapı": "Kulturstätte",
    Park: "Natur- oder Erholungsgebiet",
    Otel: "Hotel",
  }[category],
  zh: {
    UNESCO: "文化遗产地",
    Müze: "博物馆",
    Cami: "清真寺",
    Türbe: "陵墓",
    Medrese: "经学院",
    "Tarihi Yapı": "文化景点",
    Park: "自然或休闲区域",
    Otel: "酒店",
  }[category],
  ru: {
    UNESCO: "объект наследия",
    Müze: "музей",
    Cami: "мечеть",
    Türbe: "мавзолей",
    Medrese: "медресе",
    "Tarihi Yapı": "культурный объект",
    Park: "природная или рекреационная зона",
    Otel: "отель",
  }[category],
  ar: {
    UNESCO: "موقع تراثي",
    Müze: "متحف",
    Cami: "مسجد",
    Türbe: "ضريح",
    Medrese: "مدرسة تاريخية",
    "Tarihi Yapı": "موقع ثقافي",
    Park: "منطقة طبيعية أو ترفيهية",
    Otel: "فندق",
  }[category],
});

export const DESTINATION_PLACES: Place[] = (destinations as DestinationRecord[]).map((record, index) => {
  const name = record["Eser Adı"].trim();
  const arabicName = toArabicName(name);
  const category = getCategory(record.Kategori);
  const localizedCategory = categoryText(category);
  const district = record.İlçe || "Konya";
  const shortDescription = record["Kısa Açıklama"] || `${name}, Konya'nın öne çıkan kültür ve gezi duraklarından biridir.`;
  const longDescription = record["Uzun Açıklama"] || shortDescription;
  const address = [record.Adres, record.Mahalle, record.İlçe, "Konya"].filter(Boolean).join(", ");
  const media = ((destinationMedia as Record<string, DestinationMediaItem[]>)[name] || []).map((item, mediaIndex) => ({
    url: item.url,
    caption_tr: mediaIndex === 0 ? `${name} genel görünümü` : `${name} fotoğrafı ${mediaIndex + 1}`,
    caption_en: mediaIndex === 0 ? `General view of ${name}` : `Photo of ${name} ${mediaIndex + 1}`,
    caption_de: mediaIndex === 0 ? `Gesamtansicht von ${name}` : `Foto von ${name} ${mediaIndex + 1}`,
    caption_zh: `${name} 照片 ${mediaIndex + 1}`,
    caption_ru: mediaIndex === 0 ? `Общий вид ${name}` : `Фотография ${name} ${mediaIndex + 1}`,
    caption_ar: `صورة ${arabicName} ${mediaIndex + 1}`,
    source: item.source || "Wikimedia Commons",
    license: item.license || "Kaynak sayfasındaki lisans koşulları geçerlidir",
    sourceUrl: item.sourceUrl
  }));

  return {
    id: 2001 + index,
    isim_tr: name,
    isim_en: name,
    isim_de: name,
    isim_zh: name,
    isim_ru: name,
    isim_ar: arabicName,
    kategori: category,
    aciklama_kisa_tr: shortDescription,
    aciklama_kisa_en: `${name} is a ${localizedCategory.en} in ${district}, Konya.`,
    aciklama_kisa_de: `${name} ist eine ${localizedCategory.de} im Bezirk ${district} in Konya.`,
    aciklama_kisa_zh: `${name} 是位于科尼亚 ${district} 区的${localizedCategory.zh}。`,
    aciklama_kisa_ru: `${name} — ${localizedCategory.ru} в районе ${district}, Конья.`,
    aciklama_kisa_ar: `${arabicName} هو ${localizedCategory.ar} في منطقة ${district} بقونية.`,
    tarihce_tr: longDescription,
    tarihce_en: `${name} is documented as a ${localizedCategory.en} in ${district}. Its location and source record are included so guests can plan a focused visit and confirm current access before departure.`,
    tarihce_de: `${name} ist als ${localizedCategory.de} im Bezirk ${district} dokumentiert. Standort und Quelle helfen bei der Planung; aktuelle Zugangsbedingungen sollten vor der Abfahrt bestätigt werden.`,
    tarihce_zh: `${name} 被记录为 ${district} 区的${localizedCategory.zh}。应用提供其位置与资料来源，便于规划行程；出发前请确认最新开放情况。`,
    tarihce_ru: `${name} зарегистрирован как ${localizedCategory.ru} в районе ${district}. Координаты и источник помогают спланировать визит; перед выездом уточните актуальные условия доступа.`,
    tarihce_ar: `${arabicName} موثّق بوصفه ${localizedCategory.ar} في منطقة ${district}. يتيح الموقع والمصدر التخطيط للزيارة، ويُنصح بتأكيد ظروف الدخول الحالية قبل الانطلاق.`,
    koordinatlar: {
      lat: Number(record["Nihai Latitude"]),
      lng: Number(record["Nihai Longitude"])
    },
    adres: address,
    web: record["Ana Kaynak"] || undefined,
    calisma_saatleri: parseHours(record["Ziyaret Saatleri"]),
    giris_ucreti: {
      tr: record["Giriş Ücreti"] || "Ziyaret öncesinde doğrulayın",
      en: "Verify before visiting",
      zh: "参观前请确认",
      ar: "يرجى التحقق قبل الزيارة"
    },
    ziyaret_suresi_dk: 45,
    fotograf_url: media.map((item) => item.url),
    fotograf: media,
    etiketler: [
      record.Kategori,
      record.Dönemi,
      record["Yapım Tarihi"],
      record["Ziyaret Durumu"],
      record["Koordinat Güven Seviyesi"],
      record.ID
    ].filter(Boolean),
    erisilebilirlik: {
      elevator: false,
      wheelchair: false,
      disabledToilet: false,
      guideService: false
    },
    puan: 0,
    yorum_sayisi: 0,
    is_major: false
  };
});
