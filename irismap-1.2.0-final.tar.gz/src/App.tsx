import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { ArrowLeft } from "lucide-react";
import { resolveBrandVariant } from "../shared/branding";
import { guideDescription, guideTitle } from "../shared/guideText";
import { isLanguage } from "../shared/languages";
import { getHotel, hotelTexts } from "./config/hotel";
import { canonicalPlaceId, normalizePlaceIds, PLACE_ALIASES, PLACES, TOURS } from "./data";
import { isRtlLanguage, ui } from "./i18n";
import { getTutorialSteps } from "./i18n/tutorial";
import { trackEvent } from "./services/analytics";
import { applyBrandVariant } from "./theme/brand";
import type { Language, Place, Tour } from "./types";
import { clearAllStoredData, readFlag, readIdList, readString, writeFlag, writeIdList, writeString } from "./utils/storage";
import { showToast } from "./utils/toast";
import { toursForHotel } from "./utils/tours";
import { DesktopSidebar, MobileNavigation, type NavTarget, type SubView, type Tab } from "./components/AppNavigation";
import AppErrorBoundary from "./components/AppErrorBoundary";
import HomeView from "./components/HomeView";
import HotelLogo from "./components/HotelLogo";
import LanguageMenu from "./components/LanguageMenu";
import MapView from "./components/MapView";
import { ContextTip, GuestWelcome, QuickStart } from "./components/Onboarding";
import PersonalPlan from "./components/PersonalPlan";
import PlaceDetail from "./components/PlaceDetail";
import PlacesView from "./components/PlacesView";
import SettingsView from "./components/SettingsView";
import ToursList from "./components/ToursList";

const EventsList = lazy(() => import("./components/EventsList"));
const PracticalInfo = lazy(() => import("./components/PracticalInfo"));
const AIGuide = lazy(() => import("./components/AIGuide"));
const HotelInfo = lazy(() => import("./components/HotelInfo"));
const PrivacyNotice = lazy(() => import("./components/PrivacyNotice"));

interface ViewState {
  tab: Tab;
  subView: SubView | null;
  placeId: number | null;
}

const HOME: ViewState = { tab: "HOME", subView: null, placeId: null };
const TABS: Tab[] = ["HOME", "MAP", "PERSONAL", "SETTINGS"];
const SUB_VIEWS: SubView[] = ["PLACES", "TOURS", "EVENTS", "PRACTICAL", "AI_GUIDE", "HOTEL", "PRIVACY"];

const isViewState = (value: unknown): value is ViewState => {
  if (!value || typeof value !== "object") return false;
  const view = value as ViewState;
  return TABS.includes(view.tab)
    && (view.subView === null || SUB_VIEWS.includes(view.subView))
    && (view.placeId === null || Number.isInteger(view.placeId));
};

const sameView = (a: ViewState, b: ViewState) =>
  a.tab === b.tab && a.subView === b.subView && a.placeId === b.placeId;

function detectDeviceLanguage(available: Language[]): Language | null {
  const preferred = navigator.languages?.length ? navigator.languages : [navigator.language];
  for (const locale of preferred) {
    const code = (locale || "").toLowerCase().split("-")[0].toUpperCase();
    if (isLanguage(code) && available.includes(code)) return code;
  }
  return null;
}

let appOpenTracked = false;

export default function App() {
  const hotel = getHotel();
  const places = PLACES;
  const tours = useMemo(() => toursForHotel(hotel, places, TOURS, PLACE_ALIASES), [hotel, places]);
  const placesById = useMemo(() => new Map(places.map((place) => [place.id, place])), [places]);

  const [language, setLanguage] = useState<Language>(() => {
    const saved = readString("lang");
    if (isLanguage(saved) && hotel.languages.includes(saved)) return saved;
    return detectDeviceLanguage(hotel.languages) ?? hotel.defaultLanguage;
  });
  const { hotel: hotelName, city: cityName, text } = hotelTexts(language);

  /* --------------------------------------------------- Navigation + history */
  const [view, setView] = useState<ViewState>(() => {
    const state: unknown = window.history.state;
    const saved = state && typeof state === "object" ? (state as { irismap?: unknown }).irismap : null;
    return isViewState(saved) ? saved : HOME;
  });
  const viewRef = useRef(view);
  const historyIndex = useRef<number>(Number((window.history.state as { irismapIndex?: number } | null)?.irismapIndex) || 0);

  useEffect(() => {
    window.history.replaceState({ ...(window.history.state ?? {}), irismap: viewRef.current, irismapIndex: historyIndex.current }, "");
    const onPopState = (event: PopStateEvent) => {
      const state = event.state as { irismap?: unknown; irismapIndex?: number } | null;
      const next = isViewState(state?.irismap) ? state!.irismap as ViewState : HOME;
      historyIndex.current = Number(state?.irismapIndex) || 0;
      viewRef.current = next;
      setView(next);
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, []);

  const navigate = useCallback((next: ViewState, { replace = false } = {}) => {
    if (sameView(viewRef.current, next)) return;
    if (replace) {
      window.history.replaceState({ irismap: next, irismapIndex: historyIndex.current }, "");
    } else {
      historyIndex.current += 1;
      window.history.pushState({ irismap: next, irismapIndex: historyIndex.current }, "");
    }
    viewRef.current = next;
    setView(next);
  }, []);

  /** Goes back in history when possible; otherwise replaces the view with `fallback`. */
  const goBack = useCallback((fallback: ViewState) => {
    if (historyIndex.current > 0) window.history.back();
    else navigate(fallback, { replace: true });
  }, [navigate]);

  const selectedPlace = view.placeId !== null ? placesById.get(canonicalPlaceId(view.placeId)) ?? null : null;
  const contentScrollRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    contentScrollRef.current?.scrollTo({ top: 0, behavior: "auto" });
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [view.tab, view.subView, view.placeId]);

  /* -------------------------------------------------------- Brand + document */
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 60_000);
    return () => window.clearInterval(timer);
  }, []);
  const brandVariant = useMemo(() => resolveBrandVariant(hotel.branding, hotel.timezone, now), [hotel, now]);
  useEffect(() => {
    applyBrandVariant(brandVariant);
  }, [brandVariant]);

  useEffect(() => {
    document.title = guideTitle(hotel, language);
    document.documentElement.lang = language.toLowerCase();
    document.documentElement.dir = isRtlLanguage(language) ? "rtl" : "ltr";
    document.querySelector('meta[name="description"]')?.setAttribute("content", guideDescription(hotel, language));
  }, [hotel, language]);

  useEffect(() => {
    if (appOpenTracked) return;
    appOpenTracked = true;
    trackEvent("app_open", { language, theme: brandVariant.id });
  }, [language, brandVariant.id]);

  /* -------------------------------------------------------------- Language */
  const [languageMenuOpen, setLanguageMenuOpen] = useState(false);
  const mobileLanguageRef = useRef<HTMLDivElement | null>(null);
  const desktopLanguageRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!languageMenuOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setLanguageMenuOpen(false);
    };
    const closeOnOutside = (event: PointerEvent) => {
      const target = event.target as Node;
      if (!mobileLanguageRef.current?.contains(target) && !desktopLanguageRef.current?.contains(target)) {
        setLanguageMenuOpen(false);
      }
    };
    document.addEventListener("keydown", closeOnEscape);
    document.addEventListener("pointerdown", closeOnOutside);
    return () => {
      document.removeEventListener("keydown", closeOnEscape);
      document.removeEventListener("pointerdown", closeOnOutside);
    };
  }, [languageMenuOpen]);

  const changeLanguage = (next: Language) => {
    setLanguage(next);
    writeString("lang", next);
    trackEvent("language_select", { language: next });
    setLanguageMenuOpen(false);
  };

  /* ------------------------------------------------- Guest data on device */
  const [favorites, setFavorites] = useState<number[]>(() => normalizePlaceIds(readIdList("favorites")));
  const [showAllPlaces, setShowAllPlaces] = useState(() => readString("show-all-places") === "true");

  const toggleFavorite = (id: number) => {
    setFavorites((current) => {
      const updated = current.includes(id) ? current.filter((value) => value !== id) : [...current, id];
      writeIdList("favorites", updated);
      return updated;
    });
  };

  const changeShowAllPlaces = (enabled: boolean) => {
    setShowAllPlaces(enabled);
    writeString("show-all-places", String(enabled));
  };

  const clearDeviceData = () => {
    clearAllStoredData();
    setFavorites([]);
    setShowAllPlaces(false);
    setLanguage(detectDeviceLanguage(hotel.languages) ?? hotel.defaultLanguage);
    showToast(ui(language, "Bu cihazdaki verileriniz silindi.", "Your data on this device was deleted."));
  };

  /* ----------------------------------------------------------- Onboarding */
  const [showWelcome, setShowWelcome] = useState(() => !readFlag("welcome-seen"));
  const [showQuickStart, setShowQuickStart] = useState(() => readFlag("welcome-seen") && !readFlag("onboarding-seen"));
  const [dismissedTips, setDismissedTips] = useState(() => ({
    MAP: readFlag("map-tip-seen"),
    PERSONAL: readFlag("plan-tip-seen"),
  }));

  const finishWelcome = () => {
    writeFlag("welcome-seen");
    setShowWelcome(false);
    if (!readFlag("onboarding-seen")) setShowQuickStart(true);
  };

  const closeQuickStart = (openMap: boolean) => {
    writeFlag("onboarding-seen");
    setShowQuickStart(false);
    if (openMap) navigate({ tab: "MAP", subView: null, placeId: null });
  };

  const startTutorial = () => {
    navigate(HOME);
    setShowQuickStart(true);
  };

  const contextTip: "MAP" | "PERSONAL" | null =
    showWelcome || showQuickStart || view.subView || view.placeId !== null
      ? null
      : view.tab === "MAP" && !dismissedTips.MAP
        ? "MAP"
        : view.tab === "PERSONAL" && !dismissedTips.PERSONAL
          ? "PERSONAL"
          : null;

  const dismissTip = () => {
    if (contextTip === "MAP") writeFlag("map-tip-seen");
    if (contextTip === "PERSONAL") writeFlag("plan-tip-seen");
    if (contextTip) setDismissedTips((current) => ({ ...current, [contextTip]: true }));
  };

  /* -------------------------------------------------------- Map + routes */
  const [mapFocusPlace, setMapFocusPlace] = useState<Place | null>(null);
  const [selectedTour, setSelectedTour] = useState<Tour | null>(null);
  const clearMapFocus = useCallback(() => setMapFocusPlace(null), []);
  const clearTour = useCallback(() => setSelectedTour(null), []);

  const openTarget = (target: NavTarget) => {
    trackEvent("module_open", { module: target.id, language });
    if (target.isSub) navigate({ tab: "HOME", subView: target.id as SubView, placeId: null });
    else navigate({ tab: target.id as Tab, subView: null, placeId: null });
  };

  const openSubView = (subView: SubView) => openTarget({ id: subView, isSub: true });

  const selectPlace = (place: Place) => {
    trackEvent("place_detail_view", { placeId: place.id, language });
    navigate({ ...viewRef.current, placeId: place.id });
  };

  const showOnMap = (place: Place) => {
    trackEvent("show_on_map", { placeId: place.id });
    setSelectedTour(null);
    setMapFocusPlace(place);
    navigate({ tab: "MAP", subView: null, placeId: null });
  };

  const showTourOnMap = (tour: Tour) => {
    trackEvent("tour_open", { tourId: tour.id });
    setMapFocusPlace(null);
    setSelectedTour(tour);
    navigate({ tab: "MAP", subView: null, placeId: null });
  };

  const showCustomRouteOnMap = (placeIds: number[]) => {
    if (placeIds.length === 0) return;
    trackEvent("route_start", { routeStopCount: placeIds.length });
    showTourOnMap({
      id: -1,
      isim_tr: "Kişisel Rotam",
      isim_en: "My Personal Route",
      isim_de: "Meine persönliche Route",
      isim_zh: "我的个人路线",
      isim_ru: "Мой личный маршрут",
      isim_ar: "مساري الشخصي",
      aciklama_tr: "Kaydettiğiniz yerlerden oluşturduğunuz kişisel rota.",
      aciklama_en: "Your personal route created from saved places.",
      aciklama_de: "Ihre persönliche Route aus gespeicherten Orten.",
      aciklama_zh: "由收藏地点创建的个人路线。",
      aciklama_ru: "Ваш личный маршрут из сохранённых мест.",
      aciklama_ar: "مسارك الشخصي من الأماكن المحفوظة.",
      duraklar: placeIds,
      mesafe_km: 0,
      sure_saat: 0,
    });
  };

  /* --------------------------------------------------------------- Render */
  const logoUrl = brandVariant.logoUrl;
  const preparing = (
    <div className="p-6 text-sm text-[#777777]" role="status">{ui(language, "İçerik hazırlanıyor…", "Preparing content…")}</div>
  );
  const sectionFailed = (
    <div className="rounded-2xl border border-line bg-soft p-6 text-sm text-[#777777]">
      {ui(language, "Bu bölüm şu anda yüklenemedi. Bağlantınızı kontrol edip sayfayı yenileyin.", "This section could not be loaded. Check your connection and reload the page.")}
    </div>
  );
  const lazySection = (node: ReactNode) => (
    <AppErrorBoundary fallback={sectionFailed}>
      <Suspense fallback={preparing}>{node}</Suspense>
    </AppErrorBoundary>
  );

  const quickStartSteps = getTutorialSteps(language, {
    hotel: hotelName,
    city: cityName,
    hasWhatsApp: Boolean(hotel.contact.whatsapp),
  });

  const subViewAllowed = (subView: SubView) =>
    (subView !== "EVENTS" || hotel.features.events)
    && (subView !== "AI_GUIDE" || hotel.features.aiGuide)
    && (subView !== "PRACTICAL" || hotel.features.practicalInfo);
  const activeSubView = view.subView && subViewAllowed(view.subView) ? view.subView : null;

  let content: ReactNode;
  if (selectedPlace) {
    content = (
      <PlaceDetail
        place={selectedPlace}
        language={language}
        hotelName={hotelName}
        onClose={() => goBack({ ...view, placeId: null })}
        isFavorite={favorites.includes(selectedPlace.id)}
        onToggleFavorite={toggleFavorite}
        places={places}
        onShowOnMap={showOnMap}
        onSelectPlace={selectPlace}
      />
    );
  } else if (activeSubView) {
    content = (
      <div className="animate-fade-in space-y-6">
        <div className="flex items-center justify-between border-b border-line pb-3">
          <button
            type="button"
            onClick={() => goBack(HOME)}
            className="flex min-h-11 items-center gap-1.5 rounded-lg border border-line bg-soft px-3 py-2 text-xs font-bold text-brand-ink hover:bg-card"
          >
            <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
            {ui(language, "Geri dön", "Go back")}
          </button>
        </div>
        {activeSubView === "PLACES" && (
          <PlacesView places={places} language={language} onSelectPlace={selectPlace} onShowOnMap={showOnMap} />
        )}
        {activeSubView === "TOURS" && (
          <ToursList
            tours={tours}
            places={places}
            language={language}
            hotel={hotel}
            onSelectPlace={selectPlace}
            onShowTourOnMap={showTourOnMap}
          />
        )}
        {activeSubView === "EVENTS" && lazySection(<EventsList language={language} hotel={hotel} hotelName={hotelName} />)}
        {activeSubView === "PRACTICAL" && lazySection(<PracticalInfo language={language} hotel={hotel} hotelName={hotelName} />)}
        {activeSubView === "AI_GUIDE" && lazySection(<AIGuide language={language} hotelName={hotelName} cityName={cityName} />)}
        {activeSubView === "HOTEL" && lazySection(
          <HotelInfo language={language} hotel={hotel} hotelName={hotelName} logoUrl={logoUrl} translate={text} />,
        )}
        {activeSubView === "PRIVACY" && lazySection(<PrivacyNotice language={language} hotel={hotel} hotelName={hotelName} />)}
      </div>
    );
  } else if (view.tab === "MAP") {
    content = (
      <MapView
        hotel={hotel}
        hotelName={hotelName}
        logoUrl={logoUrl}
        language={language}
        places={places}
        focusPlace={mapFocusPlace}
        selectedTour={selectedTour}
        nearHotelOnly={!showAllPlaces}
        onFocusHandled={clearMapFocus}
        onSelectPlace={selectPlace}
        onShowOnMap={showOnMap}
        onClearTour={clearTour}
        onNavigateToPlace={(place) => showCustomRouteOnMap([place.id])}
        onOpenAllPlaces={() => openSubView("PLACES")}
      />
    );
  } else if (view.tab === "PERSONAL") {
    content = (
      <PersonalPlan
        places={places}
        language={language}
        cityName={cityName}
        onSelectPlace={selectPlace}
        onShowOnMap={showOnMap}
        onShowRouteOnMap={showCustomRouteOnMap}
        favorites={favorites}
        onToggleFavorite={toggleFavorite}
      />
    );
  } else if (view.tab === "SETTINGS") {
    content = (
      <SettingsView
        hotel={hotel}
        hotelName={hotelName}
        cityName={cityName}
        tagline={text(hotel.tagline)}
        about={text(hotel.about)}
        translate={text}
        logoUrl={logoUrl}
        language={language}
        showAllPlaces={showAllPlaces}
        onChangeLanguage={changeLanguage}
        onChangeShowAllPlaces={changeShowAllPlaces}
        onStartTutorial={startTutorial}
        onClearDeviceData={clearDeviceData}
        onOpenPrivacy={() => openSubView("PRIVACY")}
      />
    );
  } else {
    content = (
      <HomeView
        hotel={hotel}
        hotelName={hotelName}
        cityName={cityName}
        receptionHours={text(hotel.contact.receptionHours)}
        language={language}
        places={places}
        logoUrl={logoUrl}
        onOpenSubView={openSubView}
        onOpenMap={() => openTarget({ id: "MAP", isSub: false })}
        onSelectPlace={selectPlace}
        onShowOnMap={showOnMap}
      />
    );
  }

  return (
    <div
      dir={isRtlLanguage(language) ? "rtl" : "ltr"}
      lang={language.toLowerCase()}
      className="flex min-h-dvh flex-col bg-page font-sans text-ink transition-colors duration-300 md:flex-row"
    >
      {showWelcome && (
        <GuestWelcome
          language={language}
          hotelName={hotelName}
          cityName={cityName}
          logoUrl={logoUrl}
          askRoomNumber={hotel.features.roomNumber && Boolean(hotel.contact.whatsapp)}
          onDone={finishWelcome}
        />
      )}

      <DesktopSidebar
        language={language}
        languages={hotel.languages}
        activeTab={view.tab}
        activeSubView={activeSubView}
        onNavigate={openTarget}
        hotelName={hotelName}
        cityName={cityName}
        logoUrl={logoUrl}
        eventsEnabled={hotel.features.events}
        aiEnabled={hotel.features.aiGuide}
        languageMenuOpen={languageMenuOpen}
        onToggleLanguageMenu={() => setLanguageMenuOpen((open) => !open)}
        onCloseLanguageMenu={() => setLanguageMenuOpen(false)}
        onSelectLanguage={changeLanguage}
        languageMenuRef={desktopLanguageRef}
      />

      <main className="flex h-dvh min-w-0 flex-1 flex-col overflow-hidden bg-card pb-[calc(70px+env(safe-area-inset-bottom))] md:pb-0">
        <header className={`flex shrink-0 items-center justify-between gap-3 border-b border-line bg-soft px-3 py-2.5 md:hidden ${languageMenuOpen ? "z-[80]" : "z-10"}`}>
          <div className="flex min-w-0 items-center gap-2">
            <HotelLogo src={logoUrl} alt={hotelName} frameClassName="h-11 w-8 rounded-lg p-0.5" />
            <h1 className="truncate font-serif text-[13px] font-bold uppercase tracking-wider text-brand-ink">{hotelName}</h1>
          </div>
          <LanguageMenu
            language={language}
            languages={hotel.languages}
            open={languageMenuOpen}
            onToggle={() => setLanguageMenuOpen((open) => !open)}
            onClose={() => setLanguageMenuOpen(false)}
            onSelect={changeLanguage}
            containerRef={mobileLanguageRef}
          />
        </header>

        <div ref={contentScrollRef} className="flex-1 space-y-6 overflow-y-auto p-4 md:p-6">
          {content}
        </div>

        {showQuickStart && !showWelcome && (
          <QuickStart language={language} steps={quickStartSteps} onClose={closeQuickStart} />
        )}
        {contextTip && <ContextTip language={language} kind={contextTip} onDismiss={dismissTip} />}

        <MobileNavigation language={language} activeTab={view.tab} activeSubView={activeSubView} onNavigate={openTarget} />
      </main>
    </div>
  );
}
