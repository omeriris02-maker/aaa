/*
 * Where place photos may come from. IrisMap shows only photos that are
 * either free-licence (Wikimedia Commons) or published by the monument's
 * own heritage inventory / the Ministry of Culture and Tourism, always with a
 * link to their source page. Anything else is dropped, so an unrelated or
 * unlicensed picture can never reach guests; places without a suitable photo
 * show an illustration instead.
 */

export const ALLOWED_PHOTO_HOSTS = new Set([
  "upload.wikimedia.org",
  "cdn.kulturenvanteri.com",
  "kulturenvanteri.com",
  "www.kulturportali.gov.tr",
]);

export function isAllowedPhotoUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return parsed.protocol === "https:" && ALLOWED_PHOTO_HOSTS.has(parsed.hostname);
  } catch {
    return false;
  }
}

/**
 * Wikimedia Commons files checked by hand for places whose old photos were
 * unrelated (their file names name the place itself). Shown first.
 */
export const VERIFIED_COMMONS_FILES: Record<number, string[]> = {
  1001: ["Konya Hasbey Dar'ül Huffazı 083.jpg"],
  2023: ["Lake Meke - Meke Gölü 05.JPG", "Karapınar; Meke Gölü.JPG", "Meke Gölü -1.jpg"],
  2035: ["Tomb of Sadereddin Konevi (Sadr al-Din al-Qunawi).jpg", "Sadr al-Din al-Qunawi's tomb inscription, Konya, Turkey.jpg"],
  2061: ["Çatalhöyük, 7400 BC, Konya, Turkey - UNESCO World Heritage Site, 08.jpg"],
  2064: ["Meyil obruğu.JPG"],
};

/**
 * Places that may use the curated photo set chosen by name (PLACE_PHOTOS in
 * data.ts) when they have no photo of their own. The name match is only
 * trusted for these; e.g. "Beyşehir Kale Kapısı" must not get the lake photo.
 */
export const NAME_MATCHED_PHOTO_IDS = new Set([
  2003, // Sille Tarihî Yerleşimi → Sille
  2026, // Mevlana Meydanı ve Türbeönü → the Mevlana Museum facing the square
  2013, // Meram Bağları → Meram
  2056, // Zazadin Hanı
]);

/** Commons file page for a photo hosted on upload.wikimedia.org. */
export function commonsFilePage(url: string): string | null {
  const match = /^https:\/\/upload\.wikimedia\.org\/wikipedia\/commons\/(?:thumb\/)?[0-9a-f]\/[0-9a-f]{2}\/([^/]+)/.exec(url);
  if (!match) return null;
  try {
    return `https://commons.wikimedia.org/wiki/File:${encodeURIComponent(decodeURIComponent(match[1]))}`;
  } catch {
    return null;
  }
}
