export type AnalyticsEvent =
  | "app_open"
  | "language_select"
  | "theme_select"
  | "module_open"
  | "place_detail_view"
  | "tour_open"
  | "route_start"
  | "show_on_map"
  | "reception_call"
  | "whatsapp_click"
  | "email_click"
  | "booking_click"
  | "feedback_start";

type SafeMetadata = Record<string, string | number | boolean>;

const allowedMetadata = new Set([
  "language",
  "theme",
  "module",
  "placeId",
  "tourId",
  "routeStopCount",
]);

export function trackEvent(event: AnalyticsEvent, metadata: SafeMetadata = {}): void {
  const safeMetadata = Object.fromEntries(
    Object.entries(metadata).filter(([key]) => allowedMetadata.has(key)),
  );
  const payload = JSON.stringify({
    event,
    metadata: safeMetadata,
  });

  try {
    if (typeof navigator.sendBeacon === "function"
      && navigator.sendBeacon("/api/analytics", new Blob([payload], { type: "application/json" }))) {
      return;
    }
    void fetch("/api/analytics", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: payload,
      keepalive: true,
    }).catch(() => undefined);
  } catch {
    // Analytics must never interrupt the guest experience.
  }
}
