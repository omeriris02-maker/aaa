import type { Place } from "../types";
import { readJson, removeKey, writeJson } from "../utils/storage";

export interface WalkingRouteMetrics {
  distanceKm: number;
  durationMinutes: number;
  cached?: boolean;
}

const CACHE_PREFIX = "route-metrics:";
const MEMORY_CACHE_LIMIT = 100;
const CACHE_TTL_MS = 6 * 60 * 60 * 1000;
const memoryCache = new Map<string, { expiresAt: number; result: WalkingRouteMetrics }>();

const routeKey = (places: Place[]) =>
  places
    .map((place) => `${place.koordinatlar.lng.toFixed(6)},${place.koordinatlar.lat.toFixed(6)}`)
    .join(";");

const readStoredResult = (key: string): WalkingRouteMetrics | null => {
  const parsed = readJson<{ expiresAt: number; result: WalkingRouteMetrics }>(`${CACHE_PREFIX}${key}`);
  if (!parsed || typeof parsed.expiresAt !== "number" || !parsed.result) return null;
  if (parsed.expiresAt <= Date.now()) {
    removeKey(`${CACHE_PREFIX}${key}`);
    return null;
  }
  if (!Number.isFinite(parsed.result.distanceKm) || !Number.isFinite(parsed.result.durationMinutes)) return null;
  return { ...parsed.result, cached: true };
};

const storeResult = (key: string, result: WalkingRouteMetrics) => {
  const entry = { expiresAt: Date.now() + CACHE_TTL_MS, result };
  if (memoryCache.size >= MEMORY_CACHE_LIMIT) {
    const oldest = memoryCache.keys().next().value;
    if (oldest !== undefined) memoryCache.delete(oldest);
  }
  memoryCache.set(key, entry);
  // Storage may be unavailable in private browsing; the in-memory cache still works.
  writeJson(`${CACHE_PREFIX}${key}`, entry);
};

export async function getWalkingRouteMetrics(
  places: Place[],
  signal?: AbortSignal,
): Promise<WalkingRouteMetrics> {
  if (places.length < 2) {
    throw new Error("At least two places are required for route metrics.");
  }

  const key = routeKey(places);
  const memoryEntry = memoryCache.get(key);
  if (memoryEntry && memoryEntry.expiresAt > Date.now()) {
    return { ...memoryEntry.result, cached: true };
  }

  const stored = readStoredResult(key);
  if (stored) {
    memoryCache.set(key, { expiresAt: Date.now() + CACHE_TTL_MS, result: stored });
    return stored;
  }

  const response = await fetch("/api/route", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      coordinates: places.slice(0, 25).map((place) => [
        place.koordinatlar.lng,
        place.koordinatlar.lat,
      ]),
    }),
    signal,
  });

  if (!response.ok) {
    throw new Error("Walking route could not be calculated.");
  }

  const payload = await response.json() as Partial<WalkingRouteMetrics>;
  if (
    !Number.isFinite(payload.distanceKm)
    || !Number.isFinite(payload.durationMinutes)
  ) {
    throw new Error("Walking route returned invalid metrics.");
  }

  const result = {
    distanceKm: Number(payload.distanceKm),
    durationMinutes: Number(payload.durationMinutes),
    cached: Boolean(payload.cached),
  };
  storeResult(key, result);
  return result;
}
