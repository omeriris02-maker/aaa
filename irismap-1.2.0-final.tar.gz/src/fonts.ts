/**
 * Fonts are served by the hotel's own server (no Google Fonts request), so
 * guests' IP addresses are not shared with a font provider (GDPR/KVKK) and
 * the app shell also looks right offline. Browsers download only the
 * subsets a page needs (and only the typefaces of the hotel's design).
 * Chinese uses the phone's own system font.
 */
import "@fontsource/inter/latin-400.css";
import "@fontsource/inter/latin-ext-400.css";
import "@fontsource/inter/cyrillic-400.css";
import "@fontsource/inter/cyrillic-ext-400.css";
import "@fontsource/inter/latin-500.css";
import "@fontsource/inter/latin-ext-500.css";
import "@fontsource/inter/cyrillic-500.css";
import "@fontsource/inter/cyrillic-ext-500.css";
import "@fontsource/inter/latin-600.css";
import "@fontsource/inter/latin-ext-600.css";
import "@fontsource/inter/cyrillic-600.css";
import "@fontsource/inter/cyrillic-ext-600.css";
import "@fontsource/inter/latin-700.css";
import "@fontsource/inter/latin-ext-700.css";
import "@fontsource/inter/cyrillic-700.css";
import "@fontsource/inter/cyrillic-ext-700.css";
import "@fontsource/poppins/latin-400.css";
import "@fontsource/poppins/latin-ext-400.css";
import "@fontsource/poppins/latin-500.css";
import "@fontsource/poppins/latin-ext-500.css";
import "@fontsource/poppins/latin-600.css";
import "@fontsource/poppins/latin-ext-600.css";
import "@fontsource/poppins/latin-700.css";
import "@fontsource/poppins/latin-ext-700.css";
import "@fontsource/noto-sans-arabic/arabic-400.css";
import "@fontsource/noto-sans-arabic/arabic-500.css";
import "@fontsource/noto-sans-arabic/arabic-600.css";
import "@fontsource/noto-sans-arabic/arabic-700.css";
// Heading typefaces of the ready-made designs (shared/designs.ts).
import "@fontsource/playfair-display/latin-600.css";
import "@fontsource/playfair-display/latin-ext-600.css";
import "@fontsource/playfair-display/cyrillic-600.css";
import "@fontsource/playfair-display/latin-700.css";
import "@fontsource/playfair-display/latin-ext-700.css";
import "@fontsource/playfair-display/cyrillic-700.css";
import "@fontsource/cormorant-garamond/latin-600.css";
import "@fontsource/cormorant-garamond/latin-ext-600.css";
import "@fontsource/cormorant-garamond/cyrillic-600.css";
import "@fontsource/cormorant-garamond/latin-700.css";
import "@fontsource/cormorant-garamond/latin-ext-700.css";
import "@fontsource/cormorant-garamond/cyrillic-700.css";
import "@fontsource/lora/latin-600.css";
import "@fontsource/lora/latin-ext-600.css";
import "@fontsource/lora/cyrillic-600.css";
import "@fontsource/lora/latin-700.css";
import "@fontsource/lora/latin-ext-700.css";
import "@fontsource/lora/cyrillic-700.css";
import "@fontsource/montserrat/latin-600.css";
import "@fontsource/montserrat/latin-ext-600.css";
import "@fontsource/montserrat/cyrillic-600.css";
import "@fontsource/montserrat/latin-700.css";
import "@fontsource/montserrat/latin-ext-700.css";
import "@fontsource/montserrat/cyrillic-700.css";
