import type { HotelConfig } from "../../shared/hotelConfig";
import type { Language } from "../types";
import { cityName, hotelName, localized } from "../../shared/guideText";
import type { LocalizedText } from "../../shared/languages";

declare global {
  interface Window {
    __IRISMAP_CONFIG__?: HotelConfig;
  }
}

export type { HotelConfig };

let activeHotel: HotelConfig | null = null;

const looksLikeConfig = (value: unknown): value is HotelConfig =>
  !!value
  && typeof value === "object"
  && typeof (value as HotelConfig).id === "string"
  && typeof (value as HotelConfig).name === "object"
  && typeof (value as HotelConfig).location?.lat === "number"
  && typeof (value as HotelConfig).branding?.base?.palette?.primary === "string"
  && Array.isArray((value as HotelConfig).languages);

/**
 * The server embeds the hotel's configuration in index.html. When the page
 * was opened some other way (e.g. a cached shell), it is fetched instead.
 */
export async function loadHotelConfig(): Promise<HotelConfig> {
  if (typeof window !== "undefined" && looksLikeConfig(window.__IRISMAP_CONFIG__)) {
    activeHotel = window.__IRISMAP_CONFIG__;
    return activeHotel;
  }
  const response = await fetch("/api/config", { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`Hotel configuration unavailable (${response.status})`);
  const payload: unknown = await response.json();
  if (!looksLikeConfig(payload)) throw new Error("Hotel configuration is invalid");
  activeHotel = payload;
  return activeHotel;
}

/** Sets the active hotel directly (used by tests). */
export function setActiveHotel(config: HotelConfig) {
  activeHotel = config;
}

export function getHotel(): HotelConfig {
  if (!activeHotel) throw new Error("Hotel configuration has not been loaded");
  return activeHotel;
}

/** Hotel and city names plus a translator for configured texts. */
export function hotelTexts(language: Language) {
  const hotel = getHotel();
  return {
    hotel: hotelName(hotel, language),
    city: cityName(hotel, language),
    text: (value: LocalizedText | undefined) => localized(hotel, value, language),
  };
}
