import type { Place, PhotoItem } from "./types";
import nearbyHeritage from "./nearby-heritage.json";
import nearbySourceMedia from "./nearby-source-media.json";
import { toArabicName } from "./i18n/transliteration";

type HeritageRecord = {
  id: string;
  name: string;
  app_category: string;
  district: string;
  neighborhood: string;
  address: string;
  latitude: number;
  longitude: number;
  short_description: string;
  long_description: string;
  construction_date: string;
  period: string;
  visit_status: string;
  image_url: string;
  image_creator: string;
  image_license: string;
  image_source: string;
  source: string;
};

const getCategory = (category: string): Place["kategori"] => {
  if (category === "Cami ve Mescit") return "Cami";
  if (category === "Türbe ve Kümbet") return "Türbe";
  if (category === "Medrese ve Eğitim") return "Medrese";
  if (category === "Müze") return "Müze";
  return "Tarihi Yapı";
};

const categoryText = (category: Place["kategori"]) => ({
  en: category === "Cami" ? "mosque" : category === "Türbe" ? "mausoleum" : category === "Medrese" ? "madrasa" : category === "Müze" ? "museum" : "historic structure",
  de: category === "Cami" ? "Moschee" : category === "Türbe" ? "Mausoleum" : category === "Medrese" ? "Medrese" : category === "Müze" ? "Museum" : "historisches Bauwerk",
  zh: category === "Cami" ? "清真寺" : category === "Türbe" ? "陵墓" : category === "Medrese" ? "经学院" : category === "Müze" ? "博物馆" : "历史建筑",
  ru: category === "Cami" ? "мечеть" : category === "Türbe" ? "мавзолей" : category === "Medrese" ? "медресе" : category === "Müze" ? "музей" : "историческое сооружение",
  ar: category === "Cami" ? "مسجد" : category === "Türbe" ? "ضريح" : category === "Medrese" ? "مدرسة تاريخية" : category === "Müze" ? "متحف" : "مبنى تاريخي",
});

const getPhotos = (record: HeritageRecord): PhotoItem[] | undefined => {
  const arabicName = toArabicName(record.name);
  const sourceMedia = (nearbySourceMedia as Record<string, Array<{
    url: string;
    sourceUrl: string;
    source: string;
    license: string;
  }>>)[record.name] || [];
  if (!record.image_url && sourceMedia.length === 0) return undefined;
  if (!record.image_url) {
    return sourceMedia.map((item, index) => ({
      url: item.url,
      caption_tr: index === 0 ? `${record.name} genel görünümü` : `${record.name} fotoğrafı ${index + 1}`,
      caption_en: `View of ${record.name}`,
      caption_de: `Ansicht von ${record.name}`,
      caption_zh: `${record.name} 景观`,
      caption_ru: `Вид на ${record.name}`,
      caption_ar: `منظر ${arabicName}`,
      source: item.source,
      license: item.license,
      sourceUrl: item.sourceUrl
    }));
  }
  return [{
    url: record.image_url,
    caption_tr: `${record.name} görünümü`,
    caption_en: `View of ${record.name}`,
    caption_de: `Ansicht von ${record.name}`,
    caption_zh: `${record.name} 景观`,
    caption_ru: `Вид на ${record.name}`,
    caption_ar: `منظر ${arabicName}`,
    source: record.image_creator ? `${record.image_creator} / Kültür Envanteri` : "Kültür Envanteri",
    license: record.image_license || "Kaynak kaydında lisans belirtilmemiş",
    sourceUrl: record.image_source || record.source
  }];
};

export const NEARBY_PLACES: Place[] = (nearbyHeritage as HeritageRecord[]).map((record, index) => {
  const arabicName = toArabicName(record.name);
  const category = getCategory(record.app_category);
  const localizedCategory = categoryText(category);
  const district = record.district || "Karatay";
  const shortDescription = record.short_description || `${record.name}, Konya'nın tarihî merkezindeki yapılardan biridir.`;
  const longDescription = record.long_description || shortDescription;
  const photos = getPhotos(record);
  return {
    id: 1001 + index,
    isim_tr: record.name,
    isim_en: record.name,
    isim_de: record.name,
    isim_zh: record.name,
    isim_ru: record.name,
    isim_ar: arabicName,
    kategori: category,
    aciklama_kisa_tr: shortDescription,
    aciklama_kisa_en: `${record.name} is a ${localizedCategory.en} in ${district}, in Konya's historic centre.`,
    aciklama_kisa_de: `${record.name} ist eine ${localizedCategory.de} im Bezirk ${district}, im historischen Zentrum von Konya.`,
    aciklama_kisa_zh: `${record.name} 是位于 ${district} 区、科尼亚历史城区的${localizedCategory.zh}。`,
    aciklama_kisa_ru: `${record.name} — ${localizedCategory.ru} в районе ${district}, в исторической части Коньи.`,
    aciklama_kisa_ar: `${arabicName} هو ${localizedCategory.ar} في منطقة ${district} ضمن المركز التاريخي لمدينة قونية.`,
    tarihce_tr: longDescription,
    tarihce_en: `${record.name} is recorded as a ${localizedCategory.en} in ${district}. It is included as a nearby stop because its position supports a short historic walk from the hotel; confirm current access before visiting.`,
    tarihce_de: `${record.name} ist als ${localizedCategory.de} im Bezirk ${district} verzeichnet. Wegen seiner Lage eignet sich der Ort für einen kurzen historischen Spaziergang ab dem Hotel; bitte Zugang vorab bestätigen.`,
    tarihce_zh: `${record.name} 被记录为 ${district} 区的${localizedCategory.zh}。其位置适合从酒店出发进行短途历史步行；参观前请确认最新开放情况。`,
    tarihce_ru: `${record.name} зарегистрирован как ${localizedCategory.ru} в районе ${district}. Расположение подходит для короткой исторической прогулки от отеля; перед визитом уточните доступ.`,
    tarihce_ar: `${arabicName} موثّق بوصفه ${localizedCategory.ar} في منطقة ${district}. يجعله موقعه مناسباً لجولة تاريخية قصيرة من الفندق؛ يُرجى تأكيد إمكانية الدخول قبل الزيارة.`,
    koordinatlar: { lat: record.latitude, lng: record.longitude },
    adres: record.address || [record.neighborhood, record.district, "Konya"].filter(Boolean).join(", "),
    web: record.source || undefined,
    calisma_saatleri: { "Ziyaret bilgisi": "Ziyaret öncesinde güncel durumu doğrulayın" },
    giris_ucreti: {
      tr: "Ziyaret öncesinde doğrulayın",
      en: "Verify before visiting",
      zh: "参观前请确认",
      ar: "يرجى التحقق قبل الزيارة"
    },
    ziyaret_suresi_dk: 30,
    fotograf_url: photos?.map((photo) => photo.url) || [],
    fotograf: photos,
    etiketler: [record.app_category, record.period, record.construction_date, "Otele Yakın", record.id].filter(Boolean),
    erisilebilirlik: { elevator: false, wheelchair: false, disabledToilet: false, guideService: false },
    puan: 0,
    yorum_sayisi: 0,
    is_major: false
  };
});
