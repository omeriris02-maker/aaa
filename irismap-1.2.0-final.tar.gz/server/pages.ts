import QRCode from "qrcode";
import { DESIGNS, type DesignPreset } from "../shared/designs";
import { guideLabel, hotelName } from "../shared/guideText";
import type { Language } from "../shared/languages";
import { escapeHtml } from "./html";
import type { Tenant } from "./tenants";

/*
 * Server-rendered helper pages for hotel staff and sales:
 *   /demo  hotel picker for demo links (only when demo mode is on)
 *   /qr    printable QR poster and room / table cards
 *   /rapor usage report (data is fetched with the report key)
 * They are self-contained (inline CSS) and never indexed by search engines.
 */

const BASE_STYLE = `
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#26302f;background:#f4f4f1;-webkit-print-color-adjust:exact;print-color-adjust:exact}
a{color:inherit}
.toolbar{position:sticky;top:0;z-index:5;display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:12px 16px;background:#ffffff;border-bottom:1px solid #e3e3de}
.toolbar h1{font-size:15px;margin:0 12px 0 0}
.btn{display:inline-flex;align-items:center;min-height:40px;padding:0 14px;border-radius:10px;border:1px solid #d6d6cf;background:#fff;font:600 13px system-ui,sans-serif;text-decoration:none;cursor:pointer;color:#26302f}
.btn.primary{background:#2f5d62;border-color:#2f5d62;color:#fff}
.btn[aria-current=page]{border-color:#2f5d62;box-shadow:inset 0 0 0 1px #2f5d62}
.notice{width:100%;margin:4px 0 0;padding:10px 12px;border-radius:10px;background:#fff6e0;border:1px solid #f0d58c;font-size:13px;line-height:1.45}
input[type=text]{min-height:40px;padding:0 10px;border-radius:10px;border:1px solid #d6d6cf;font:14px system-ui,sans-serif;min-width:0}
.muted{color:#6b716f}
@media print{.toolbar,.no-print{display:none!important}body{background:#fff}}
`;

function document(title: string, body: string, style: string, lang = "tr"): string {
  return `<!doctype html>
<html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>${escapeHtml(title)}</title>
<style>${BASE_STYLE}${style}</style>
</head><body>${body}</body></html>`;
}

/* ------------------------------------------------------------- Rooms */

export const MAX_CARDS = 300;
const ROOM = /^[\p{L}\p{N}-]{1,12}$/u;

/** Parses "101-110, 201, A-12" into a list of room labels. */
export function parseRooms(input: string): { rooms: string[]; error: string | null } {
  const rooms: string[] = [];
  const seen = new Set<string>();
  const add = (room: string) => {
    if (!seen.has(room)) {
      seen.add(room);
      rooms.push(room);
    }
  };
  for (const token of input.split(/[\s,;]+/).filter(Boolean)) {
    const range = /^(\d{1,5})-(\d{1,5})$/.exec(token);
    if (range) {
      const from = Number(range[1]);
      const to = Number(range[2]);
      if (to < from) return { rooms: [], error: `"${token}" aralığı ters yazılmış` };
      if (to - from + 1 > MAX_CARDS) return { rooms: [], error: `En fazla ${MAX_CARDS} kart hazırlanabilir` };
      const width = range[1].length === range[2].length && range[1].startsWith("0") ? range[1].length : 0;
      for (let value = from; value <= to; value += 1) add(String(value).padStart(width, "0"));
    } else if (ROOM.test(token)) {
      add(token);
    } else {
      return { rooms: [], error: `"${token.slice(0, 20)}" geçerli bir oda numarası değil` };
    }
    if (rooms.length > MAX_CARDS) return { rooms: [], error: `En fazla ${MAX_CARDS} kart hazırlanabilir` };
  }
  return { rooms, error: null };
}

/** Adds `room=<n>` to the guide address; the app stores it on the phone. */
export function guideUrlForRoom(baseUrl: string, room: string | null): string {
  if (!room) return baseUrl;
  const url = new URL(baseUrl);
  url.searchParams.set("room", room);
  return url.toString();
}

/** True for addresses a guest's phone cannot reach (this computer, home/office networks). */
export function isPrivateAddress(url: string): boolean {
  let host: string;
  try {
    host = new URL(url).hostname.replace(/^\[|\]$/g, "");
  } catch {
    return true;
  }
  return host === "localhost"
    || host.endsWith(".local")
    || host === "::1"
    || /^127\./.test(host)
    || /^10\./.test(host)
    || /^192\.168\./.test(host)
    || /^172\.(1[6-9]|2\d|3[01])\./.test(host)
    || /^0\.0\.0\.0$/.test(host);
}

/* --------------------------------------------------------------- QR */

const SCAN_TEXT: Record<Language, string> = {
  TR: "Şehir rehberi için okutun",
  EN: "Scan for the city guide",
  DE: "Für den Stadtführer scannen",
  ZH: "扫码查看城市指南",
  RU: "Отсканируйте, чтобы открыть путеводитель",
  AR: "امسح الرمز لفتح دليل المدينة",
};

const NO_APP_TEXT: Record<Language, string> = {
  TR: "Uygulama indirmeye gerek yok, telefonunuzun kamerası yeterli.",
  EN: "No app to install, just use your phone camera.",
  DE: "Keine App nötig – einfach mit der Handykamera.",
  ZH: "无需安装应用，用手机相机扫码即可。",
  RU: "Ничего не нужно устанавливать — просто камера телефона.",
  AR: "لا حاجة لتثبيت تطبيق، تكفي كاميرا هاتفك.",
};

const ROOM_LABEL: Record<Language, string> = {
  TR: "Oda",
  EN: "Room",
  DE: "Zimmer",
  ZH: "房间",
  RU: "Номер",
  AR: "الغرفة",
};

const dirOf = (language: Language) => (language === "AR" ? "rtl" : "ltr");
const langAttr = (language: Language) => `lang="${language.toLowerCase()}" dir="${dirOf(language)}"`;
const displayUrl = (url: string) => url.replace(/^https?:\/\//, "").replace(/\/$/, "");

async function qrSvg(text: string, color: string): Promise<string> {
  return QRCode.toString(text, {
    type: "svg",
    errorCorrectionLevel: "M",
    // A white "quiet zone" around the code helps every phone camera read it.
    margin: 2,
    color: { dark: color, light: "#ffffff" },
  });
}

/** Dark enough for every phone camera: keep the brand colour only when it is deep. */
function qrColor(hex: string): string {
  const value = hex.replace("#", "");
  const full = value.length === 3 ? value.split("").map((c) => c + c).join("") : value;
  const [r, g, b] = [0, 2, 4].map((index) => parseInt(full.slice(index, index + 2), 16) / 255)
    .map((channel) => (channel <= 0.03928 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4));
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return luminance < 0.12 ? `#${full}` : "#111111";
}

export interface QrPageOptions {
  tenant: Tenant;
  /** Address the codes open (the hotel's public guide). */
  guideUrl: string;
  layout: "poster" | "cards";
  rooms: string[];
  roomsInput: string;
  notices: string[];
  /** Query string that keeps the selected hotel in demo mode (e.g. "otel=demo&"). */
  keepQuery: string;
}

export async function renderQrPage(options: QrPageOptions): Promise<string> {
  const { tenant, layout, rooms } = options;
  const { config } = tenant;
  const language = config.defaultLanguage;
  const palette = config.branding.base.palette;
  const name = hotelName(config, language);
  const label = guideLabel(config, language);
  const logo = config.branding.base.logoUrl;
  const dark = qrColor(palette.primaryDeep);
  const otherLanguages = config.languages.filter((item) => item !== language);

  // Padding is given in mm: a percentage would be measured against the whole sheet.
  const logoBlock = (size: number) => logo
    ? `<div class="logo" style="background:${palette.logoFrame};width:${size}mm;height:${size}mm;padding:${(size * 0.14).toFixed(1)}mm"><img src="${escapeHtml(logo)}" alt=""></div>`
    : "";

  let content: string;
  if (layout === "poster") {
    const svg = await qrSvg(options.guideUrl, dark);
    content = `<main class="sheet poster">
  ${logoBlock(30)}
  <h2 class="name" ${langAttr(language)} style="color:${palette.primaryInk}">${escapeHtml(name)}</h2>
  <p class="label" ${langAttr(language)}>${escapeHtml(label)}</p>
  <div class="qr" role="img" aria-label="QR">${svg}</div>
  <p class="scan" ${langAttr(language)} style="color:${palette.primaryInk}">${escapeHtml(SCAN_TEXT[language])}</p>
  <p class="noapp" ${langAttr(language)}>${escapeHtml(NO_APP_TEXT[language])}</p>
  <ul class="others">${otherLanguages.map((item) => `<li ${langAttr(item)}>${escapeHtml(SCAN_TEXT[item])}</li>`).join("")}</ul>
  <p class="url">${escapeHtml(displayUrl(options.guideUrl))}</p>
  <p class="brand" lang="en">IrisMap</p>
</main>`;
  } else {
    const targets = rooms.length > 0 ? rooms : [null, null, null, null];
    const cards = await Promise.all(targets.map(async (room) => {
      const url = guideUrlForRoom(options.guideUrl, room);
      const svg = await qrSvg(url, dark);
      const secondLanguage = language === "EN" ? null : config.languages.includes("EN") ? "EN" : null;
      return `<article class="card">
    <header>${logoBlock(13)}<div><h2 ${langAttr(language)} style="color:${palette.primaryInk}">${escapeHtml(name)}</h2><p ${langAttr(language)}>${escapeHtml(label)}</p></div></header>
    <div class="qr">${svg}</div>
    ${room ? `<p class="room" style="background:${palette.primary}">${escapeHtml(ROOM_LABEL[language])} ${escapeHtml(room)}</p>` : ""}
    <p class="scan" ${langAttr(language)}>${escapeHtml(SCAN_TEXT[language])}</p>
    ${secondLanguage ? `<p class="scan2" lang="en">${escapeHtml(SCAN_TEXT.EN)}</p>` : ""}
    <p class="url">${escapeHtml(displayUrl(url))}</p>
  </article>`;
    }));
    const pages: string[] = [];
    for (let index = 0; index < cards.length; index += 4) {
      pages.push(`<section class="sheet cards">${cards.slice(index, index + 4).join("")}</section>`);
    }
    content = pages.join("");
  }

  const keep = options.keepQuery;
  const toolbar = `<div class="toolbar">
  <h1>${escapeHtml(name)} · QR</h1>
  <a class="btn" href="/qr?${keep}layout=poster"${layout === "poster" ? ' aria-current="page"' : ""}>A4 afiş</a>
  <a class="btn" href="/qr?${keep}layout=cards"${layout === "cards" && rooms.length === 0 ? ' aria-current="page"' : ""}>Masa kartları (4'lü)</a>
  <form method="get" action="/qr" style="display:flex;gap:8px;flex-wrap:wrap">
    ${keep ? keep.split("&").filter(Boolean).map((pair) => {
      const [key, value = ""] = pair.split("=");
      return `<input type="hidden" name="${escapeHtml(decodeURIComponent(key))}" value="${escapeHtml(decodeURIComponent(value))}">`;
    }).join("") : ""}
    <input type="hidden" name="layout" value="cards">
    <label class="muted" for="rooms" style="align-self:center;font-size:13px">Oda kartları:</label>
    <input type="text" id="rooms" name="rooms" placeholder="101-120, 201, 202" value="${escapeHtml(options.roomsInput)}" size="18">
    <button class="btn" type="submit">Hazırla</button>
  </form>
  <button class="btn primary" type="button" onclick="window.print()">Yazdır / PDF kaydet</button>
  ${options.notices.map((notice) => `<p class="notice" role="status">${escapeHtml(notice)}</p>`).join("")}
</div>`;

  const style = `
@page{size:A4;margin:0}
.sheet{width:210mm;min-height:297mm;margin:16px auto;background:#fff;box-shadow:0 2px 12px rgba(0,0,0,.08);overflow:hidden}
.logo{flex:none;display:flex;align-items:center;justify-content:center;border-radius:18%;margin:0 auto}
.logo img{display:block;width:100%;height:100%;object-fit:contain}
.poster{display:flex;flex-direction:column;align-items:center;text-align:center;padding:20mm 18mm 12mm;border-top:6mm solid ${palette.primary}}
.poster .name{font:700 30pt Georgia,"Times New Roman",serif;margin:8mm 0 2mm}
.poster .label{font-size:14pt;margin:0 0 9mm;letter-spacing:.04em;text-transform:uppercase;color:${palette.accent}}
.poster .qr{width:92mm;height:92mm;padding:3mm;border:1.2mm solid ${palette.accent};border-radius:6mm}
.qr svg{display:block;width:100%;height:100%}
.poster .scan{font:700 21pt system-ui,sans-serif;margin:9mm 0 2mm}
.poster .noapp{font-size:12pt;margin:0 0 7mm;color:#555}
.poster .others{list-style:none;padding:0;margin:0 0 6mm;display:flex;flex-wrap:wrap;justify-content:center;gap:2mm 9mm;max-width:165mm;font-size:11pt;color:#444}
.poster .url{font:600 12pt ui-monospace,Menlo,monospace;margin:auto 0 1mm;color:#333}
.poster .brand{font-size:8pt;color:#9a9a9a;margin:0;letter-spacing:.2em;text-transform:uppercase}
.cards{display:grid;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;height:297mm;break-after:page}
.card{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:9mm 8mm;border:0.3mm dashed #c9c9c2;margin:-0.15mm}
.card header{display:flex;align-items:center;gap:4mm;margin-bottom:5mm;text-align:start}
.card h2{font:700 15pt Georgia,"Times New Roman",serif;margin:0}
.card header p{margin:1mm 0 0;font-size:8.5pt;color:${palette.accent};text-transform:uppercase;letter-spacing:.05em}
.card .qr{width:58mm;height:58mm}
.card .room{margin:4mm 0 0;padding:1.5mm 5mm;border-radius:3mm;color:#fff;font:700 13pt system-ui,sans-serif}
.card .scan{font:700 12pt system-ui,sans-serif;margin:4mm 0 0}
.card .scan2{font-size:9.5pt;color:#555;margin:1mm 0 0}
.card .url{font:9pt ui-monospace,Menlo,monospace;color:#555;margin:3mm 0 0;word-break:break-all}
@media screen and (max-width:820px){.sheet{zoom:.45}}
@media print{.sheet{margin:0;box-shadow:none}}
`;
  return document(`${name} · QR`, toolbar + content, style, language.toLowerCase());
}

/* ------------------------------------------------------------- Demo */

export interface DemoPageOptions {
  tenants: Tenant[];
  origin: string;
  currentId: string | null;
}

export function renderDemoPage(options: DemoPageOptions): string {
  const card = (tenant: Tenant) => {
    const { config } = tenant;
    const language = config.defaultLanguage;
    const palette = config.branding.base.palette;
    const link = `${options.origin}/?otel=${encodeURIComponent(tenant.id)}`;
    const current = tenant.id === options.currentId;
    return `<article class="hotel"${current ? ' aria-current="true"' : ""}>
  <div class="top" style="background:${palette.primary}">
    <div class="logo" style="background:${palette.logoFrame}">${config.branding.base.logoUrl ? `<img src="${escapeHtml(config.branding.base.logoUrl)}" alt="">` : ""}</div>
    <div><h2 ${langAttr(language)}>${escapeHtml(hotelName(config, language))}</h2><p ${langAttr(language)}>${escapeHtml(guideLabel(config, language))}</p></div>
  </div>
  <div class="body">
    <p class="muted">Tasarım: <strong>${escapeHtml(DESIGNS[config.branding.design].name.TR ?? config.branding.design)}</strong> · Kimlik: <code>${escapeHtml(tenant.id)}</code> · ${config.languages.length} dil${tenant.server.hosts.length ? ` · ${tenant.server.hosts.map(escapeHtml).join(", ")}` : ""}${current ? " · <strong>şu an seçili</strong>" : ""}</p>
    <div class="copy"><input type="text" readonly value="${escapeHtml(link)}" aria-label="Demo bağlantısı"><button class="btn" type="button" data-copy="${escapeHtml(link)}">Kopyala</button></div>
    <div class="actions">
      <a class="btn primary" href="/?otel=${encodeURIComponent(tenant.id)}">Rehberi aç</a>
      <a class="btn" href="/qr?otel=${encodeURIComponent(tenant.id)}">QR afişi</a>
      <a class="btn" href="/qr?otel=${encodeURIComponent(tenant.id)}&amp;layout=cards">Masa kartları</a>
    </div>
  </div>
</article>`;
  };
  const designs = options.tenants.filter((tenant) => tenant.id.startsWith("tasarim-"));
  const hotels = options.tenants.filter((tenant) => !tenant.id.startsWith("tasarim-"));

  const body = `<div class="toolbar"><h1><span lang="en">IrisMap</span> · Demo otelleri</h1><span class="muted">${options.tenants.length} otel</span>
  <a class="btn primary" href="/tanitim">Tanıtım broşürü</a>
  ${options.currentId ? '<a class="btn" href="/?otel=">Seçimi kaldır</a>' : ""}</div>
<main>
  <p class="intro">Her otelin bağlantısını müşteri adayına gönderin. Bağlantıyı açan kişi rehberi o otelin adı, logosu ve renkleriyle görür. Bağlantı bu sunucunun adresiyle çalışır; otelin kendi alan adı bağlandığında misafirler doğrudan kendi otellerini görür.</p>
  ${designs.length ? `<h2 class="section">Tasarım seçenekleri</h2><p class="intro">Otel sahibine beş hazır tasarımı gösterin; “Otel Adınız” yerine otelin adı ve logosu gelir. Seçilen tasarımla otel oluşturmak için: <code>npm run otel:yeni -- --tasarim klasik …</code></p><div class="grid">${designs.map(card).join("")}</div>` : ""}
  ${hotels.length ? `<h2 class="section">Oteller</h2><div class="grid">${hotels.map(card).join("")}</div>` : ""}
</main>
<script>
document.addEventListener("click", function (event) {
  var button = event.target.closest("[data-copy]");
  if (!button) return;
  var text = button.getAttribute("data-copy");
  var done = function () { button.textContent = "Kopyalandı"; setTimeout(function () { button.textContent = "Kopyala"; }, 1600); };
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(done, function () {});
  else { var input = button.previousElementSibling; input.select(); try { document.execCommand("copy"); done(); } catch (e) {} }
});
</script>`;

  const style = `
main{max-width:1100px;margin:0 auto;padding:16px}
.intro{max-width:760px;line-height:1.55;color:#4a5150;font-size:14px}
.section{font-size:18px;margin:28px 0 4px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px}
.hotel{background:#fff;border:1px solid #e3e3de;border-radius:16px;overflow:hidden}
.hotel[aria-current=true]{outline:3px solid #2f5d62}
.top{display:flex;gap:12px;align-items:center;padding:16px;color:#fff}
.top h2{margin:0;font:700 18px Georgia,serif}
.top p{margin:2px 0 0;font-size:12px;opacity:.85}
.logo{flex:none;width:52px;height:52px;border-radius:12px;padding:6px;display:flex;align-items:center;justify-content:center;border:1px solid rgba(255,255,255,.35)}
.logo img{max-width:100%;max-height:100%}
.body{padding:14px 16px 16px}
.body p{margin:0 0 10px;font-size:12px}
.copy{display:flex;gap:6px;margin-bottom:10px}
.copy input{flex:1;font-size:12px}
.actions{display:flex;flex-wrap:wrap;gap:6px}
`;
  return document("IrisMap · Demo otelleri", body, style);
}

/* ----------------------------------------------------------- Report */

/**
 * Usage report for hotel staff. The page holds no data itself: after the
 * report key is entered, the browser loads the aggregate counters from
 * /api/analytics/summary and draws the tables.
 */
export function renderReportPage(tenant: Tenant): string {
  const { config } = tenant;
  const name = hotelName(config, config.defaultLanguage);
  const body = `<div class="toolbar"><h1>${escapeHtml(name)} · Kullanım raporu</h1>
  <button class="btn" type="button" id="print" hidden>Yazdır / PDF</button>
  <button class="btn" type="button" id="csv" hidden>CSV indir</button>
  <button class="btn" type="button" id="logout" hidden>Çıkış</button>
</div>
<main>
  <form id="login" class="panel">
    <label for="key"><strong>Rapor anahtarı</strong></label>
    <p class="muted">IrisMap yöneticinizin verdiği anahtarı girin. Anahtar yalnızca bu sekmede hatırlanır.</p>
    <div class="row"><input type="password" id="key" autocomplete="current-password" required minlength="4"><button class="btn primary" type="submit">Raporu göster</button></div>
    <p id="error" class="error" role="alert"></p>
  </form>
  <section id="report" hidden>
    <p class="muted" id="updated"></p>
    <div class="cards" id="cards"></div>
    <div class="grid2">
      <section class="panel wide"><h2>Aylara göre</h2><table id="months"></table><p class="muted small">Aylık kırılım IrisMap 1.1 ile başlar; öncesi yalnızca toplamlarda görünür.</p></section>
      <section class="panel"><h2>Misafir dilleri</h2><table id="languages"></table></section>
      <section class="panel"><h2>En çok incelenen yerler</h2><table id="places"></table></section>
      <section class="panel"><h2>En çok açılan bölümler</h2><table id="modules"></table></section>
      <section class="panel"><h2>Rotalar</h2><table id="tours"></table></section>
      <section class="panel"><h2>Misafir iletişimi</h2><table id="contact"></table></section>
    </div>
    <p class="muted small">Tüm sayılar anonim toplamlardır; misafirlerin kimliği, IP adresi veya cihaz bilgisi tutulmaz.</p>
  </section>
</main>
<script>
(function () {
  var MONTHS = ["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"];
  var LANGS = { TR: "Türkçe", EN: "İngilizce", DE: "Almanca", ZH: "Çince", RU: "Rusça", AR: "Arapça" };
  var MODULES = { HOME: "Ana sayfa", MAP: "Harita", TOURS: "Rotalar", PERSONAL: "Kişisel plan", SETTINGS: "Ayarlar", PLACES: "Gezilecek yerler", EVENTS: "Kültür takvimi", AI_GUIDE: "Yapay zekâ rehberi", PRACTICAL: "Pratik bilgiler", HOTEL: "Otel bilgileri", PRIVACY: "Gizlilik" };
  var $ = function (id) { return document.getElementById(id); };
  var store = { get: function () { try { return sessionStorage.getItem("irismap-report-key") || ""; } catch (e) { return ""; } },
    set: function (v) { try { v ? sessionStorage.setItem("irismap-report-key", v) : sessionStorage.removeItem("irismap-report-key"); } catch (e) {} } };
  var lastCsv = "";
  var fmt = function (n) { return Number(n || 0).toLocaleString("tr-TR"); };

  function table(el, head, rows, empty) {
    el.textContent = "";
    var thead = el.createTHead().insertRow();
    head.forEach(function (h, i) { var th = document.createElement("th"); th.textContent = h; if (i) th.className = "num"; thead.appendChild(th); });
    var tbody = el.createTBody();
    if (!rows.length) { var r = tbody.insertRow(); var c = r.insertCell(); c.colSpan = head.length; c.className = "muted"; c.textContent = empty || "Henüz veri yok"; return; }
    rows.forEach(function (row) { var tr = tbody.insertRow(); row.forEach(function (v, i) { var td = tr.insertCell(); td.textContent = i ? fmt(v) : v; if (i) td.className = "num"; }); });
  }
  function card(label, value, note) {
    var div = document.createElement("div"); div.className = "card";
    var b = document.createElement("b"); b.textContent = fmt(value);
    var s = document.createElement("span"); s.textContent = label;
    div.appendChild(b); div.appendChild(s);
    if (note) { var n = document.createElement("small"); n.textContent = note; div.appendChild(n); }
    return div;
  }
  function byPrefix(counts, prefix) {
    var out = [];
    Object.keys(counts).forEach(function (k) { if (k.indexOf(prefix) === 0) out.push([k.slice(prefix.length), counts[k]]); });
    return out.sort(function (a, b) { return b[1] - a[1]; });
  }
  function render(data) {
    var c = data.counts || {};
    var contact = function (prefix) { return (c[prefix + "reception_call"] || 0) + (c[prefix + "whatsapp_click"] || 0) + (c[prefix + "email_click"] || 0); };
    var now = new Date();
    var thisMonth = "month:" + now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0") + "|";
    $("updated").textContent = "Güncelleme: " + new Date(data.updatedAt).toLocaleString("tr-TR");
    var cards = $("cards"); cards.textContent = "";
    cards.appendChild(card("Rehber açılışı (toplam)", c.app_open));
    cards.appendChild(card("Bu ay açılış", c[thisMonth + "app_open"]));
    cards.appendChild(card("Resepsiyona ulaşma", contact(""), "Arama, WhatsApp, e-posta"));
    cards.appendChild(card("Yürüyüş rotası", c.route_start));
    cards.appendChild(card("Mekân incelemesi", c.place_detail_view));
    cards.appendChild(card("Rezervasyon tıklaması", c.booking_click));

    var months = {};
    Object.keys(c).forEach(function (k) { var m = /^month:(\\d{4}-\\d{2})\\|/.exec(k); if (m) months[m[1]] = true; });
    var monthRows = Object.keys(months).sort().reverse().slice(0, 12).map(function (m) {
      var p = "month:" + m + "|"; var parts = m.split("-");
      return [MONTHS[Number(parts[1]) - 1] + " " + parts[0], c[p + "app_open"] || 0, c[p + "place_detail_view"] || 0, c[p + "route_start"] || 0, contact(p), c[p + "booking_click"] || 0];
    });
    var monthHead = ["Ay", "Açılış", "Mekân", "Rota", "İletişim", "Rezervasyon"];
    table($("months"), monthHead, monthRows);
    table($("languages"), ["Dil", "Açılış"], byPrefix(c, "app_open|language:").map(function (r) { return [LANGS[r[0]] || r[0], r[1]]; }));
    var names = data.names || { places: {}, tours: {} };
    table($("places"), ["Yer", "İnceleme"], byPrefix(c, "place_detail_view|placeId:").slice(0, 10).map(function (r) { var n = names.places[r[0]]; return [n ? n.TR : "#" + r[0], r[1]]; }));
    table($("modules"), ["Bölüm", "Açılış"], byPrefix(c, "module_open|module:").filter(function (r) { return MODULES[r[0]]; }).map(function (r) { return [MODULES[r[0]], r[1]]; }));
    table($("tours"), ["Rota", "Açılış"], byPrefix(c, "tour_open|tourId:").map(function (r) { var n = names.tours[r[0]]; return [n ? n.TR : "#" + r[0], r[1]]; }));
    table($("contact"), ["Kanal", "Tıklama"], [["Telefon", c.reception_call || 0], ["WhatsApp", c.whatsapp_click || 0], ["E-posta", c.email_click || 0], ["Geri bildirim", c.feedback_start || 0], ["Rezervasyon", c.booking_click || 0]]);

    lastCsv = [monthHead.join(";")].concat(monthRows.map(function (r) { return r.join(";"); })).join("\\n");
    $("login").hidden = true; $("report").hidden = false;
    ["print", "csv", "logout"].forEach(function (id) { $(id).hidden = false; });
  }
  function load(key) {
    $("error").textContent = "";
    fetch("/api/analytics/summary", { headers: { Authorization: "Bearer " + key }, cache: "no-store", credentials: "same-origin" })
      .then(function (r) {
        if (r.status === 404) throw new Error("Anahtar geçersiz ya da bu otel için rapor kapalı.");
        if (r.status === 429) throw new Error("Çok fazla deneme yapıldı; bir dakika sonra tekrar deneyin.");
        if (!r.ok) throw new Error("Rapor şu anda alınamadı (" + r.status + ").");
        return r.json();
      })
      .then(function (data) { store.set(key); render(data); })
      .catch(function (e) { store.set(""); $("login").hidden = false; $("error").textContent = e.message || "Rapor alınamadı."; });
  }
  $("login").addEventListener("submit", function (e) { e.preventDefault(); load($("key").value.trim()); });
  $("logout").addEventListener("click", function () { store.set(""); location.reload(); });
  $("print").addEventListener("click", function () { window.print(); });
  $("csv").addEventListener("click", function () {
    var blob = new Blob(["\\ufeff" + lastCsv], { type: "text/csv;charset=utf-8" });
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "irismap-rapor.csv";
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  });
  var saved = store.get();
  if (saved) load(saved);
})();
</script>`;

  const style = `
main{max-width:1100px;margin:0 auto;padding:16px}
.panel{background:#fff;border:1px solid #e3e3de;border-radius:16px;padding:16px;margin-bottom:16px}
.panel h2{font-size:15px;margin:0 0 10px}
.row{display:flex;gap:8px;flex-wrap:wrap}
.row input{flex:1;min-width:200px}
.error{color:#b42318;font-weight:600;min-height:1em}
.cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;margin-bottom:16px}
.card{background:#fff;border:1px solid #e3e3de;border-radius:14px;padding:14px}
.card b{display:block;font-size:26px;color:#2f5d62}
.card span{display:block;font-size:12px;font-weight:600;margin-top:2px}
.card small{display:block;font-size:11px;color:#6b716f}
.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:16px}
.grid2 .panel{margin:0;overflow-x:auto}
.grid2 .wide{grid-column:1/-1}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{padding:7px 6px;border-bottom:1px solid #eeeeea;text-align:start}
th{font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#6b716f}
.num{text-align:end;font-variant-numeric:tabular-nums}
.small{font-size:11px}
@media print{main{max-width:none}.panel,.card{break-inside:avoid}}
`;
  return document(`${name} · Kullanım raporu`, body, style);
}

/* --------------------------------------------------------- Brochure */

export interface BrochureOptions {
  designs: Array<{ preset: DesignPreset; hotelId: string | null }>;
  /** Public address of the demo server; QR codes are added only when known. */
  publicUrl: string | null;
  /** Seller's contact lines (IRISMAP_SATIS_ILETISIM, separated by "|"). */
  contact: string[];
  /** Hotel opened by the "live demo" QR code (the neutral demo hotel). */
  demoHotelId: string | null;
  notices: string[];
}

const FEATURES: Array<[string, string, string]> = [
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3z"/><path d="M9 3v15M15 6v15"/></svg>`, "Etkileşimli harita", "Otelin çevresi, 130 mekân, gerçek yaya güzergâhı ve “neredeyim”."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="13" cy="4" r="2"/><path d="M10 22l2-7 3 3v6M8 12l2-4 4 1 3 4"/></svg>`, "Hazır rotalar", "Otelinizden başlayan çevre yürüyüşü ve temalı şehir rotaları."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-8-5.5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.5-8 11-8 11z"/></svg>`, "Kişisel plan", "Favoriler, gezi listesi ve en kısa yürüyüş sırasına dizme."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/></svg>`, "Yapay zekâ rehberi", "Misafirin sorularını altı dilde, otelinizin bilgileriyle cevaplar."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 21l1.9-5.4A8 8 0 1 1 21 12z"/></svg>`, "Resepsiyona WhatsApp", "Mesajlar oda numarasıyla hazır gelir; arama ve e-posta tek dokunuş."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>`, "Kültür takvimi", "Sema törenleri, festivaller ve pratik bilgiler tek yerde."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>`, "Altı dil", "Türkçe, İngilizce, Almanca, Çince, Rusça ve Arapça (sağdan sola)."],
  [`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>`, "KVKK uyumlu", "Hesap yok, ad/telefon istenmez; veriler misafirin telefonunda kalır."],
];

const BENEFITS: Array<[string, string]> = [
  ["Resepsiyonun yükü azalır", "“Nereye gidelim, nasıl gideriz?” sorularının cevabı misafirin cebinde."],
  ["Misafir memnuniyeti artar", "Yabancı misafirler şehri kendi dilinde, kaybolmadan keşfeder."],
  ["Talepler düzenli gelir", "WhatsApp mesajları oda numarasıyla gelir; kim, hangi oda belli."],
  ["Markanız her ekranda", "Otelinizin adı, logosu ve renkleri; size özel çevre rotası."],
  ["Ölçülebilir sonuç", "Aylık rapor: kaç misafir kullandı, hangi dillerde, en çok neye baktı."],
  ["Kurulum aynı gün", "Uygulama indirme yok; QR afiş ve oda kartları hazır teslim edilir."],
];

export async function renderBrochurePage(options: BrochureOptions): Promise<string> {
  const qr = async (url: string) => QRCode.toString(url, { type: "svg", errorCorrectionLevel: "M", margin: 1, color: { dark: "#1c3a3e", light: "#ffffff" } });
  const phone = (src: string, extra = "") => `<figure class="phone ${extra}"><img src="${escapeHtml(src)}" alt="" onerror="this.closest('figure').classList.add('missing')"></figure>`;
  const base = options.publicUrl?.replace(/\/$/, "") ?? null;

  const designCards = await Promise.all(options.designs.map(async ({ preset, hotelId }) => {
    const swatches = [preset.palette.primary, preset.palette.primaryDeep, preset.palette.accent, preset.palette.accentSoft, preset.palette.soft]
      .map((color) => `<i style="background:${color}"></i>`).join("");
    const link = base && hotelId ? `${base}/?otel=${encodeURIComponent(hotelId)}` : null;
    return `<article class="design">
      ${phone(`/tanitim/${preset.id}-home.jpg`)}
      ${phone(`/tanitim/${preset.id}-detail.jpg`, "second")}
      <h3 style="color:${preset.palette.primaryInk}">${escapeHtml(preset.name.TR ?? preset.id)}</h3>
      <p>${escapeHtml(preset.description.TR ?? "")}</p>
      <div class="swatches">${swatches}</div>
      ${link ? `<div class="qr-small">${await qr(link)}</div><span class="qr-label">Canlı deneyin</span>` : ""}
    </article>`;
  }));

  const contact = options.contact.length
    ? `<div class="contact"><h3>İletişim</h3>${options.contact.map((line) => `<p>${escapeHtml(line)}</p>`).join("")}</div>`
    : "";
  const demoLink = base && options.demoHotelId ? `${base}/?otel=${encodeURIComponent(options.demoHotelId)}` : null;
  const liveDemo = demoLink ? `<div class="live"><div class="qr-big">${await qr(demoLink)}</div><p><strong>Canlı demo</strong><br>${escapeHtml(displayUrl(demoLink))}</p></div>` : "";

  const body = `<div class="toolbar no-print"><h1>IrisMap · Tanıtım broşürü</h1>
  <button class="btn primary" type="button" onclick="window.print()">Yazdır / PDF kaydet</button>
  ${options.notices.map((notice) => `<p class="notice" role="status">${escapeHtml(notice)}</p>`).join("")}
</div>
<main>
<section class="page cover">
  <div class="cover-text">
    <p class="kicker"><span lang="en">IrisMap</span> · Otel misafirleri için dijital şehir rehberi</p>
    <h2>Misafirleriniz şehri <em>sizin adınızla</em> keşfetsin.</h2>
    <p class="lead">QR kodu okutan misafir, otelinizin adı, logosu ve renkleriyle açılan altı dilli bir rehber görür: harita, yürüyüş rotaları, kültür takvimi, yapay zekâ rehberi ve resepsiyona tek dokunuşla WhatsApp. Uygulama indirmek gerekmez.</p>
    <ul class="stats"><li><b>6</b> dil</li><li><b>130</b> mekân</li><li><b>5</b> hazır tasarım</li><li><b>1</b> günde kurulum</li></ul>
  </div>
  <div class="cover-phones">${phone("/tanitim/klasik-home.jpg", "back-left")}${phone("/tanitim/modern-places.jpg", "front")}${phone("/tanitim/deniz-detail.jpg", "back-right")}</div>
</section>

<section class="page">
  <p class="kicker">Misafir deneyimi</p>
  <h2>Misafirleriniz neler yapabilir?</h2>
  <div class="features">${FEATURES.map(([icon, title, text]) => `<div class="feature"><span class="icon">${icon}</span><h3>${escapeHtml(title)}</h3><p>${escapeHtml(text)}</p></div>`).join("")}</div>
  <div class="row-phones">${phone("/tanitim/luks-ai.jpg")}${phone("/tanitim/doga-places.jpg")}${phone("/tanitim/klasik-detail.jpg")}${phone("/tanitim/modern-map.jpg")}</div>
</section>

<section class="page">
  <p class="kicker">Size özel görünüm</p>
  <h2>Otelinize uygun tasarımı seçin</h2>
  <p class="lead small">Her tasarımda otelinizin adı, logosu ve isterseniz kendi kurumsal renkleriniz kullanılır. Aşağıdaki örneklerde “Otel Adınız” yazan yere sizin adınız gelir.</p>
  <div class="designs">${designCards.join("")}</div>
</section>

<section class="page">
  <p class="kicker">Oteliniz için</p>
  <h2>Ne kazanırsınız?</h2>
  <div class="benefits">${BENEFITS.map(([title, text]) => `<div><h3>${escapeHtml(title)}</h3><p>${escapeHtml(text)}</p></div>`).join("")}</div>
  <div class="steps-wrap">
    <div class="steps"><h3>Kurulum dört adımda</h3><ol>
      <li><b>Bilgi formu</b> — otel adı, logo, iletişim, hizmetler.</li>
      <li><b>Tasarım seçimi</b> — beş tasarımdan biri, kendi renklerinizle.</li>
      <li><b>Aynı gün yayında</b> — rehber.oteliniz.com adresinde, HTTPS ile.</li>
      <li><b>Teslim</b> — A4 QR afiş, masa kartları, odaya özel QR kartlar ve aylık kullanım raporu.</li>
    </ol></div>
    ${liveDemo}
  </div>
  ${contact}
  <p class="foot">IrisMap · Harita verileri © OpenStreetMap katkıcıları · Fotoğraflar Wikimedia Commons ve Kültür Envanteri</p>
</section>
</main>`;

  const style = `
@font-face{font-family:"BrochureHead";font-weight:600;src:url(/tanitim/fonts/poppins-latin-600-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:"BrochureHead";font-weight:600;src:url(/tanitim/fonts/poppins-latin-ext-600-normal.woff2) format("woff2");unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:"BrochureHead";font-weight:700;src:url(/tanitim/fonts/poppins-latin-700-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:"BrochureHead";font-weight:700;src:url(/tanitim/fonts/poppins-latin-ext-700-normal.woff2) format("woff2");unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:"BrochureBody";font-weight:400;src:url(/tanitim/fonts/inter-latin-400-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:"BrochureBody";font-weight:400;src:url(/tanitim/fonts/inter-latin-ext-400-normal.woff2) format("woff2");unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@font-face{font-family:"BrochureBody";font-weight:600;src:url(/tanitim/fonts/inter-latin-600-normal.woff2) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}
@font-face{font-family:"BrochureBody";font-weight:600;src:url(/tanitim/fonts/inter-latin-ext-600-normal.woff2) format("woff2");unicode-range:U+0100-02AF,U+0304,U+0308,U+0329,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}
@page{size:A4;margin:0}
body{font-family:"BrochureBody",system-ui,sans-serif;color:#1f2b2c;background:#e9e9e4}
h2,h3,.kicker,.stats b{font-family:"BrochureHead","BrochureBody",system-ui,sans-serif}
main{display:flex;flex-direction:column;align-items:center;gap:16px;padding:16px 0}
.page{position:relative;width:210mm;height:297mm;padding:18mm 16mm 14mm;background:#fff;box-shadow:0 2px 14px rgba(0,0,0,.1);overflow:hidden;break-after:page}
.kicker{margin:0;font-size:9.5pt;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:#b88a4a}
h2{margin:3mm 0 5mm;font-size:24pt;line-height:1.15;color:#1c3a3e}
h2 em{font-style:normal;color:#b88a4a}
h3{margin:0 0 1.5mm;font-size:11.5pt;color:#1c3a3e}
p{margin:0;font-size:10pt;line-height:1.5;color:#3d4a4b}
.lead{font-size:11.5pt;line-height:1.55;max-width:150mm}
.lead.small{font-size:10pt;margin-bottom:6mm}
.cover{background:radial-gradient(circle at 85% 15%,#2f5d62 0,#1c3a3e 70%);color:#fff;display:flex;flex-direction:column}
.cover .kicker{color:#e7d3ae}
.cover h2{font-size:32pt;color:#fff;max-width:160mm}
.cover h2 em{color:#e7d3ae}
.cover .lead{color:rgba(255,255,255,.88)}
.stats{display:flex;gap:4mm;list-style:none;padding:0;margin:8mm 0 0}
.stats li{padding:3mm 5mm;border:1px solid rgba(231,211,174,.5);border-radius:4mm;font-size:9.5pt;color:rgba(255,255,255,.85)}
.stats b{display:block;font-size:18pt;color:#e7d3ae}
.cover-phones{position:relative;flex:1;margin-top:8mm}
.phone{margin:0;position:relative;aspect-ratio:390/844;border:2.4mm solid #111;border-radius:7mm;overflow:hidden;background:#f4f2ee;box-shadow:0 6mm 14mm rgba(0,0,0,.28)}
.phone img{display:block;width:100%;height:100%;object-fit:cover}
.phone.missing{display:none}
.cover-phones .phone{position:absolute;bottom:-6mm;width:60mm}
.cover-phones .front{left:50%;transform:translateX(-50%);z-index:2;width:66mm}
.cover-phones .back-left{left:12mm;transform:rotate(-6deg)}
.cover-phones .back-right{right:12mm;transform:rotate(6deg)}
.features{display:grid;grid-template-columns:1fr 1fr;gap:4mm 8mm;margin-bottom:7mm}
.feature{display:grid;grid-template-columns:9mm 1fr;column-gap:3mm}
.feature .icon{grid-row:span 2;width:8mm;height:8mm;color:#b88a4a}
.feature .icon svg{width:100%;height:100%}
.row-phones{display:flex;justify-content:center;gap:6mm}
.row-phones .phone{width:40mm}
.designs{display:grid;grid-template-columns:repeat(5,1fr);gap:4mm}
.design{display:flex;flex-direction:column;align-items:center;text-align:center}
.design .phone{width:100%;border-width:1.6mm;border-radius:5mm;margin-bottom:4mm}
.design .phone.second{width:86%;margin-top:-1mm}
.design p{font-size:8pt;line-height:1.4;min-height:22mm}
.swatches{display:flex;gap:1.2mm;margin:2.5mm 0}
.swatches i{width:5mm;height:5mm;border-radius:50%;border:.3mm solid rgba(0,0,0,.12)}
.qr-small{width:22mm;height:22mm;margin-top:1mm}
.qr-small svg,.qr-big svg{width:100%;height:100%}
.qr-label{font-size:7.5pt;color:#6b716f}
.benefits{display:grid;grid-template-columns:1fr 1fr;gap:5mm 8mm;margin-bottom:8mm}
.benefits>div{padding:4mm 5mm;border-radius:3mm;background:#f6f4ef;border-left:1.2mm solid #b88a4a}
.steps-wrap{display:flex;gap:8mm;align-items:flex-start}
.steps{flex:1}
.steps ol{margin:2mm 0 0;padding-left:5mm}
.steps li{font-size:10pt;line-height:1.5;margin-bottom:2mm;color:#3d4a4b}
.live{width:46mm;text-align:center}
.qr-big{width:40mm;height:40mm;margin:0 auto 2mm}
.live p{font-size:8.5pt}
.contact{margin-top:8mm;padding:5mm 6mm;border-radius:3mm;background:#1c3a3e;color:#fff}
.contact h3{color:#e7d3ae}
.contact p{color:#fff}
.foot{position:absolute;left:16mm;right:16mm;bottom:8mm;font-size:7pt;color:#8a918f}
@media print{body{background:#fff}main{padding:0;gap:0}.page{box-shadow:none}}
@media screen and (max-width:820px){.page{zoom:.45}}
`;
  return document("IrisMap · Tanıtım broşürü", body, style);
}
