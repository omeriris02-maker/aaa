import { canonicalPlaceId, PLACES, TOURS } from "../src/data";
import { AROUND_HOTEL_TOUR_ID } from "../src/utils/tours";

/** Turkish and English names of places and tours for hotel reports. */
export function namesFor(placeIds: number[], tourIds: number[]) {
  const places: Record<string, { TR: string; EN: string }> = {};
  for (const id of placeIds) {
    const place = PLACES.find((candidate) => candidate.id === canonicalPlaceId(id));
    if (place) places[id] = { TR: place.isim_tr, EN: place.isim_en };
  }
  const tours: Record<string, { TR: string; EN: string }> = {};
  for (const id of tourIds) {
    if (id === AROUND_HOTEL_TOUR_ID) {
      tours[id] = { TR: "Otel çevresi yürüyüşü", EN: "Walk around the hotel" };
      continue;
    }
    const tour = TOURS.find((candidate) => candidate.id === id);
    if (tour) tours[id] = { TR: tour.isim_tr, EN: tour.isim_en };
  }
  return { places, tours };
}
