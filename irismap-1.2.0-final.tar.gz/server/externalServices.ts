import { ExpiringCache } from "./rateLimit";

export const USER_AGENT = `IrisMap/1.0 (hotel guest guide${process.env.OPERATOR_CONTACT_EMAIL ? `; ${process.env.OPERATOR_CONTACT_EMAIL}` : ""})`;

/**
 * Third-party endpoints. The defaults are free public services with fair-use
 * limits; commercial deployments should point these at their own or paid
 * providers (see README, "Üçüncü taraf hizmetler").
 */
const OSRM_FOOT_URL = (process.env.IRISMAP_OSRM_URL || "https://routing.openstreetmap.de/routed-foot/route/v1/driving").replace(/\/$/, "");
const VALHALLA_URL = process.env.IRISMAP_VALHALLA_URL || "https://valhalla1.openstreetmap.de/route";
const OPEN_METEO_API_KEY = process.env.OPEN_METEO_API_KEY?.trim() || "";

/** fetch with a hard timeout; the timer is always cleared. */
export async function fetchWithTimeout(url: string, init: RequestInit = {}, timeoutMs = 8000): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      ...init,
      signal: controller.signal,
      headers: { "User-Agent": USER_AGENT, ...(init.headers as Record<string, string> | undefined) },
    });
  } finally {
    clearTimeout(timer);
  }
}

/* ------------------------------------------------------------------------ */
/* Walking routes                                                            */
/* ------------------------------------------------------------------------ */

export type Coordinate = [number, number];

export interface WalkingRouteResult {
  coordinates: Coordinate[];
  distanceKm: number;
  durationMinutes: number;
  fallback: false;
}

export const isValidCoordinate = (value: unknown): value is Coordinate =>
  Array.isArray(value)
  && value.length === 2
  && value.every((part) => typeof part === "number" && Number.isFinite(part))
  && value[0] >= -180 && value[0] <= 180
  && value[1] >= -90 && value[1] <= 90;

export function haversineMeters(a: Coordinate, b: Coordinate): number {
  const toRadians = (degree: number) => degree * Math.PI / 180;
  const earthRadius = 6_371_000;
  const deltaLat = toRadians(b[1] - a[1]);
  const deltaLng = toRadians(b[0] - a[0]);
  const value = Math.sin(deltaLat / 2) ** 2
    + Math.cos(toRadians(a[1])) * Math.cos(toRadians(b[1])) * Math.sin(deltaLng / 2) ** 2;
  return earthRadius * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

export function decodePolyline6(encoded: string): Coordinate[] {
  const coordinates: Coordinate[] = [];
  let index = 0;
  let latitude = 0;
  let longitude = 0;
  const decodeValue = () => {
    let result = 0;
    let shift = 0;
    let byte = 0;
    do {
      if (index >= encoded.length) throw new Error("Invalid encoded route shape");
      byte = encoded.charCodeAt(index++) - 63;
      result |= (byte & 0x1f) << shift;
      shift += 5;
    } while (byte >= 0x20);
    return (result & 1) ? ~(result >> 1) : result >> 1;
  };
  while (index < encoded.length) {
    latitude += decodeValue();
    longitude += decodeValue();
    coordinates.push([longitude / 1e6, latitude / 1e6]);
  }
  return coordinates;
}

/** Maximum distance a routing provider may move a stop when snapping it to a road. */
const MAX_SNAP_METERS = 180;
const routeCache = new ExpiringCache<WalkingRouteResult>(500, 6 * 60 * 60 * 1000);

type OsrmResponse = {
  routes?: Array<{ distance?: number; duration?: number; geometry?: { coordinates?: unknown[] } }>;
  waypoints?: Array<{ location?: unknown }>;
};

type ValhallaResponse = {
  trip?: { legs?: Array<{ shape?: string }>; summary?: { length?: number; time?: number } };
};

async function osrmRoute(coordinates: Coordinate[], straightLine: number): Promise<WalkingRouteResult> {
  const coordinatePath = coordinates.map(([lng, lat]) => `${lng},${lat}`).join(";");
  const response = await fetchWithTimeout(
    `${OSRM_FOOT_URL}/${coordinatePath}?overview=full&geometries=geojson&steps=false`,
    {},
    6000,
  );
  if (!response.ok) throw new Error(`Routing provider returned ${response.status}`);
  const data = await response.json() as OsrmResponse;
  const route = data.routes?.[0];
  const routeCoordinates = route?.geometry?.coordinates;
  if (!Array.isArray(routeCoordinates) || routeCoordinates.length < 2 || !routeCoordinates.every(isValidCoordinate)) {
    throw new Error("Routing provider returned no valid route");
  }
  const waypoints = data.waypoints;
  if (
    !Array.isArray(waypoints)
    || waypoints.length !== coordinates.length
    || waypoints.some((waypoint, index) =>
      !isValidCoordinate(waypoint?.location) || haversineMeters(coordinates[index], waypoint.location) > MAX_SNAP_METERS)
  ) {
    throw new Error("Routing provider snapped a stop too far from its requested location");
  }
  const distance = route?.distance;
  const duration = route?.duration;
  if (typeof distance !== "number" || !Number.isFinite(distance) || distance < straightLine * 0.9) {
    throw new Error("Routing provider returned an implausible distance");
  }
  if (typeof duration !== "number" || !Number.isFinite(duration)) {
    throw new Error("Routing provider returned an invalid duration");
  }
  return {
    coordinates: routeCoordinates as Coordinate[],
    distanceKm: Number((distance / 1000).toFixed(2)),
    durationMinutes: Math.round(duration / 60),
    fallback: false,
  };
}

async function valhallaRoute(coordinates: Coordinate[], straightLine: number): Promise<WalkingRouteResult> {
  const response = await fetchWithTimeout(VALHALLA_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      locations: coordinates.map(([lon, lat]) => ({ lat, lon })),
      costing: "pedestrian",
      units: "kilometers",
      directions_options: { units: "kilometers" },
    }),
  }, 7000);
  if (!response.ok) throw new Error(`Backup routing provider returned ${response.status}`);
  const data = await response.json() as ValhallaResponse;
  const legs = data.trip?.legs;
  if (!Array.isArray(legs) || legs.length !== coordinates.length - 1) {
    throw new Error("Backup routing provider returned invalid legs");
  }
  const routeCoordinates: Coordinate[] = [];
  legs.forEach((leg, index) => {
    if (typeof leg?.shape !== "string") throw new Error("Backup route shape is missing");
    const legCoordinates = decodePolyline6(leg.shape);
    if (
      legCoordinates.length < 2
      || haversineMeters(coordinates[index], legCoordinates[0]) > MAX_SNAP_METERS
      || haversineMeters(coordinates[index + 1], legCoordinates[legCoordinates.length - 1]) > MAX_SNAP_METERS
    ) {
      throw new Error("Backup route did not match the requested stops");
    }
    routeCoordinates.push(...(index === 0 ? legCoordinates : legCoordinates.slice(1)));
  });
  const distanceKm = Number(data.trip?.summary?.length);
  const durationSeconds = Number(data.trip?.summary?.time);
  if (!Number.isFinite(distanceKm) || distanceKm * 1000 < straightLine * 0.9 || !Number.isFinite(durationSeconds)) {
    throw new Error("Backup routing provider returned implausible metrics");
  }
  return {
    coordinates: routeCoordinates,
    distanceKm: Number(distanceKm.toFixed(2)),
    durationMinutes: Math.round(durationSeconds / 60),
    fallback: false,
  };
}

/**
 * Returns a verified road-following walking route, or null. No synthetic
 * straight line is ever produced: callers show the stops instead.
 */
export async function getWalkingRoute(coordinates: Coordinate[]): Promise<(WalkingRouteResult & { cached?: boolean }) | null> {
  const key = coordinates.map(([lng, lat]) => `${lng.toFixed(6)},${lat.toFixed(6)}`).join(";");
  const cached = routeCache.get(key);
  if (cached) return { ...cached, cached: true };

  const straightLine = coordinates.slice(1).reduce(
    (total, coordinate, index) => total + haversineMeters(coordinates[index], coordinate),
    0,
  );

  for (const provider of [osrmRoute, valhallaRoute]) {
    try {
      const result = await provider(coordinates, straightLine);
      routeCache.set(key, result);
      return result;
    } catch (error) {
      console.warn(`[IrisMap] walking route provider ${provider.name} unavailable:`, (error as Error).message);
    }
  }
  return null;
}

/* ------------------------------------------------------------------------ */
/* Wikimedia Commons gallery                                                 */
/* ------------------------------------------------------------------------ */

export interface CommonsPhoto {
  url: string;
  caption_tr: string;
  caption_en: string;
  caption_de: string;
  caption_zh: string;
  caption_ru: string;
  caption_ar: string;
  source: string;
  license: string;
  sourceUrl?: string;
}

type CommonsPage = {
  title?: string;
  canonicalurl?: string;
  imageinfo?: Array<{
    url?: string;
    thumburl?: string;
    descriptionurl?: string;
    mime?: string;
    extmetadata?: Record<string, { value?: string }>;
  }>;
};

const commonsCache = new ExpiringCache<CommonsPhoto[]>(1000, 24 * 60 * 60 * 1000);

const stripHtml = (value = "") =>
  value
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, "\"")
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, " ")
    .trim();

/** Words that say what a building is, not which one it is. */
const GENERIC_WORDS = new Set([
  "camii", "cami", "camisi", "mescidi", "mescit", "mosque", "masjid", "turbe", "turbesi", "tomb", "medrese", "medresesi",
  "madrasa", "muzesi", "muze", "museum", "hani", "han", "caravanserai", "hamami", "hamam", "bath", "kalesi", "kale",
  "castle", "kilisesi", "church", "parki", "park", "golu", "gol", "lake", "konya", "turkey", "turkiye", "ve", "and",
  "the", "of", "tarihi", "historic", "historical", "eski", "old", "buyuk", "great", "kucuk", "small", "merkezi",
  "center", "centre", "tabiat", "nature", "antik", "ancient", "kenti", "city", "koprusu", "bridge", "kosku", "pavilion",
]);

const normalizeWords = (value: string) =>
  value
    .toLocaleLowerCase("tr-TR")
    .replace(/[çğıöşüâîû]/g, (char) => ({ ç: "c", ğ: "g", ı: "i", ö: "o", ş: "s", ü: "u", â: "a", î: "i", û: "u" })[char] ?? char)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .split(/[^a-z0-9]+/)
    .filter(Boolean);

/**
 * True when a Commons file title names the place itself (one of its
 * distinctive words), e.g. "Konya Hasbey Dar'ül Huffazı 083.jpg" for
 * "Hasbey Darülhuffazı" — but not "Ortaköy Mosque" for "Orta Camii".
 */
export function isRelevantPhotoTitle(title: string, names: string[]): boolean {
  const words = new Set(normalizeWords(title));
  const distinctive = names.flatMap(normalizeWords).filter((word) => word.length >= 4 && !GENERIC_WORDS.has(word));
  return distinctive.some((word) => words.has(word));
}

export async function getCommonsPhotos(place: string, english: string, cityHint: string, limit: number): Promise<{ photos: CommonsPhoto[]; cached: boolean; unavailable?: boolean }> {
  const cacheKey = `${place}|${english}|${cityHint}|${limit}`.toLocaleLowerCase("tr-TR");
  const cached = commonsCache.get(cacheKey);
  if (cached) return { photos: cached, cached: true };

  try {
    const params = new URLSearchParams({
      action: "query",
      format: "json",
      origin: "*",
      generator: "search",
      gsrsearch: `${place} ${english} ${cityHint}`.replace(/\s+/g, " ").trim(),
      gsrnamespace: "6",
      gsrlimit: String(Math.min(limit * 2, 20)),
      prop: "imageinfo|info",
      inprop: "url",
      iiprop: "url|mime|extmetadata",
      iiurlwidth: "1400",
    });
    const response = await fetchWithTimeout(`https://commons.wikimedia.org/w/api.php?${params}`, {}, 9000);
    if (!response.ok) throw new Error(`Commons returned ${response.status}`);
    const payload = await response.json() as { query?: { pages?: Record<string, CommonsPage> } };
    const label = english || place;
    const photos = Object.values(payload.query?.pages || {})
      .map((page): CommonsPhoto | null => {
        const info = page.imageinfo?.[0];
        const metadata = info?.extmetadata || {};
        const mime = info?.mime || "";
        const url = info?.thumburl || info?.url;
        if (!url || !/^https:\/\/upload\.wikimedia\.org\//.test(url) || !mime.startsWith("image/") || mime.includes("svg")) {
          return null;
        }
        // Search results often show a similarly named building elsewhere.
        if (!isRelevantPhotoTitle(page.title ?? "", [place, english])) return null;
        const artist = stripHtml(metadata.Artist?.value || metadata.Credit?.value || "Wikimedia Commons").slice(0, 90);
        const sourceUrl = info?.descriptionurl || page.canonicalurl;
        return {
          url,
          caption_tr: `${place} arşiv görünümü`,
          caption_en: `Archive view of ${label}`,
          caption_de: `Archivansicht: ${label}`,
          caption_zh: `${label} 的档案照片`,
          caption_ru: `Архивный снимок: ${label}`,
          caption_ar: "صورة أرشيفية من ويكيميديا كومنز",
          source: `${artist} / Wikimedia Commons`,
          license: stripHtml(metadata.LicenseShortName?.value || metadata.UsageTerms?.value || "Wikimedia Commons").slice(0, 80),
          sourceUrl: sourceUrl && /^https:\/\//.test(sourceUrl) ? sourceUrl : undefined,
        };
      })
      .filter((photo): photo is CommonsPhoto => photo !== null)
      .slice(0, limit);
    commonsCache.set(cacheKey, photos);
    return { photos, cached: false };
  } catch (error) {
    console.warn("[IrisMap] Wikimedia Commons gallery unavailable:", (error as Error).message);
    return { photos: [], cached: false, unavailable: true };
  }
}

/* ------------------------------------------------------------------------ */
/* Weather                                                                   */
/* ------------------------------------------------------------------------ */

export interface WeatherResult {
  available: boolean;
  temp: number | null;
  /** WMO weather code group used by the app to choose text and icon. */
  condition: "clear" | "partly-cloudy" | "fog" | "rain" | "snow" | "showers" | "storm" | "cloudy" | "unknown";
}

const weatherCache = new ExpiringCache<WeatherResult>(200, 15 * 60 * 1000);

export function weatherCondition(code: number): WeatherResult["condition"] {
  if (code === 0) return "clear";
  if (code >= 1 && code <= 3) return "partly-cloudy";
  if (code >= 45 && code <= 48) return "fog";
  if (code >= 51 && code <= 67) return "rain";
  if (code >= 71 && code <= 77) return "snow";
  if (code >= 80 && code <= 86) return "showers";
  if (code >= 95) return "storm";
  return "cloudy";
}

export async function getWeather(lat: number, lng: number, timezone: string): Promise<WeatherResult> {
  const key = `${lat.toFixed(3)},${lng.toFixed(3)}`;
  const cached = weatherCache.get(key);
  if (cached) return cached;
  try {
    const params = new URLSearchParams({
      latitude: String(lat),
      longitude: String(lng),
      current_weather: "true",
      timezone,
    });
    // Open-Meteo's free API is for non-commercial use; a customer key switches to the commercial endpoint.
    if (OPEN_METEO_API_KEY) params.set("apikey", OPEN_METEO_API_KEY);
    const host = OPEN_METEO_API_KEY ? "https://customer-api.open-meteo.com" : "https://api.open-meteo.com";
    const response = await fetchWithTimeout(`${host}/v1/forecast?${params}`, {}, 6000);
    if (!response.ok) throw new Error(`Weather service returned ${response.status}`);
    const data = await response.json() as { current_weather?: { temperature?: number; weathercode?: number } };
    const current = data.current_weather;
    if (!current || !Number.isFinite(current.temperature) || !Number.isFinite(current.weathercode)) {
      throw new Error("Weather service returned invalid data");
    }
    const result: WeatherResult = {
      available: true,
      temp: Math.round(current.temperature as number),
      condition: weatherCondition(current.weathercode as number),
    };
    weatherCache.set(key, result);
    return result;
  } catch (error) {
    console.warn("[IrisMap] weather unavailable:", (error as Error).message);
    return { available: false, temp: null, condition: "unknown" };
  }
}
