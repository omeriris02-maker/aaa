import express, { type NextFunction, type Request, type Response } from "express";
import { readFileSync } from "node:fs";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { timingSafeEqual } from "node:crypto";
import { isLanguage } from "../shared/languages";
import { AiGuide, AI_QUESTION_MAX_LENGTH, parseLanguage, sanitizeHistory } from "./ai";
import { AnalyticsStore } from "./analytics";
import {
  getCommonsPhotos,
  getWalkingRoute,
  getWeather,
  isValidCoordinate,
} from "./externalServices";
import { buildIconSvg, buildManifest, NOT_CONFIGURED_HTML, renderIndexHtml } from "./html";
import { isPrivateAddress, parseRooms, renderBrochurePage, renderDemoPage, renderQrPage, renderReportPage } from "./pages";
import { DESIGN_IDS, DESIGNS } from "../shared/designs";
import { RateLimiter } from "./rateLimit";
import type { GeneratedImage, Tenant, TenantRegistry } from "./tenants";
import { DESTINATIONS } from "../shared/destinations";

export type AppMode = "production" | "development" | "test";

export interface AppOptions {
  registry: TenantRegistry;
  analytics: AnalyticsStore;
  ai: AiGuide;
  mode: AppMode;
  /** Project root; index.html (development) and dist/ (production) live here. */
  rootDir: string;
  /** Template used in test mode instead of index.html. */
  testIndexHtml?: string;
  analyticsToken?: string;
  /** Per-hotel report keys (hotel id → key); each opens only that hotel's report. */
  reportTokens?: Record<string, string>;
  allowFraming?: boolean;
  trustProxy?: boolean | number | string;
  version?: string;
  /**
   * Sales demo mode: `/?otel=<id>` shows any hotel on this server's own
   * address and `/demo` lists them. Hotel domains listed in `hosts` always
   * show their own hotel.
   */
  demo?: boolean;
  /** When set, `/demo` needs `?anahtar=<key>`. */
  demoKey?: string;
  /** Seller's contact lines shown on the sales brochure (/tanitim). */
  salesContact?: string[];
}

export interface AppHandle {
  app: express.Express;
  close: () => Promise<void>;
}

const tenantOf = (res: Response): Tenant | null => (res.locals.tenant as Tenant | undefined) ?? null;

export const PREVIEW_COOKIE = "irismap_hotel";
const PREVIEW_PARAMS = ["otel", "hotel"];
const PREVIEW_MAX_AGE_SECONDS = 30 * 24 * 60 * 60;

export function readCookie(header: string | undefined, name: string): string | null {
  for (const part of (header || "").split(";")) {
    const index = part.indexOf("=");
    if (index < 0 || part.slice(0, index).trim() !== name) continue;
    try {
      return decodeURIComponent(part.slice(index + 1).trim());
    } catch {
      return null;
    }
  }
  return null;
}

const tokensMatch = (supplied: string, expected: string) => {
  const a = Buffer.from(supplied);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
};

const isLoopback = (address: string | undefined) =>
  address === "127.0.0.1" || address === "::1" || address === "::ffff:127.0.0.1";

export function parseTrustProxy(value: string | undefined): boolean | number | string {
  if (value === undefined || value.trim() === "") return 1;
  const normalized = value.trim().toLowerCase();
  if (normalized === "true") return true;
  if (normalized === "false" || normalized === "0") return false;
  if (/^\d+$/.test(normalized)) return Number(normalized);
  return value.trim();
}

/** "?otel=<id>" while a demo hotel is shown, so its files never mix with another hotel's. */
const previewQuery = (res: Response, tenant: Tenant) =>
  res.locals.preview ? `?otel=${encodeURIComponent(tenant.id)}` : "";

/**
 * The hotel's public origin: its first domain in `hosts` (served over HTTPS),
 * or the address of this request (demo links, single-hotel servers).
 */
function publicOrigin(req: Request, res: Response, tenant: Tenant): string {
  if (!res.locals.preview && tenant.server.hosts[0]) return `https://${tenant.server.hosts[0]}`;
  return `${req.protocol}://${req.get("host")}`;
}

export async function createApp(options: AppOptions): Promise<AppHandle> {
  const { registry, analytics, ai, mode } = options;
  const app = express();
  const closers: Array<() => Promise<void> | void> = [];

  app.disable("x-powered-by");
  app.set("trust proxy", options.trustProxy ?? 1);

  // Basic hardening headers for every response.
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "geolocation=(self), camera=(), microphone=(), payment=()");
    if (!options.allowFraming) res.setHeader("X-Frame-Options", "SAMEORIGIN");
    next();
  });

  // Every request belongs to one hotel: the owner of the host name, then (demo
  // mode only) the hotel chosen with ?otel=<id> or remembered in a cookie,
  // then the default hotel. A hotel's own domain always shows that hotel.
  app.use((req, res, next) => {
    let tenant = registry.matchHost(req.headers.host);
    let preview = false;
    if (!tenant && options.demo) {
      const param = PREVIEW_PARAMS.map((name) => req.query[name]).find((value) => typeof value === "string") as string | undefined;
      const requested = param === undefined ? undefined : param.trim().toLowerCase();
      const chosen = registry.get(requested || (readCookie(req.headers.cookie, PREVIEW_COOKIE) ?? ""));
      const isPage = req.method === "GET" && !req.path.startsWith("/api/") && !/\.[a-z0-9]{1,8}$/i.test(req.path);
      if (isPage && requested !== undefined) {
        const secure = req.secure ? "; Secure" : "";
        if (requested === "") {
          res.setHeader("Set-Cookie", `${PREVIEW_COOKIE}=; Path=/; Max-Age=0; SameSite=Lax; HttpOnly${secure}`);
        } else if (registry.get(requested)) {
          res.setHeader("Set-Cookie", `${PREVIEW_COOKIE}=${requested}; Path=/; Max-Age=${PREVIEW_MAX_AGE_SECONDS}; SameSite=Lax; HttpOnly${secure}`);
        }
      }
      if (requested === "") {
        tenant = null;
      } else if (chosen) {
        tenant = chosen;
        preview = true;
      }
    }
    res.locals.tenant = tenant ?? registry.defaultTenant;
    res.locals.preview = preview;
    if (options.demo) res.vary("Cookie");
    next();
  });

  app.use("/api", express.json({ limit: "64kb" }));

  const aiLimiter = new RateLimiter(12, 60_000);
  const serviceLimiter = new RateLimiter(90, 60_000);
  const analyticsLimiter = new RateLimiter(240, 60_000);
  closers.push(() => aiLimiter.stop(), () => serviceLimiter.stop(), () => analyticsLimiter.stop());

  const requireTenant = (req: Request, res: Response, next: NextFunction) => {
    if (tenantOf(res)) return next();
    return res.status(404).json({ error: "No hotel is configured for this address" });
  };

  /* ---------------------------------------------------------------- API */

  app.get("/api/health", (_req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json({ status: "ok", version: options.version ?? "dev", time: new Date().toISOString() });
  });

  app.get("/api/config", requireTenant, (_req, res) => {
    res.setHeader("Cache-Control", "no-cache");
    res.json(tenantOf(res)!.config);
  });

  app.post("/api/analytics", requireTenant, analyticsLimiter.middleware(), (req, res) => {
    const tenant = tenantOf(res)!;
    const accepted = analytics.record(tenant.id, req.body?.event, req.body?.metadata, { timezone: tenant.config.timezone });
    res.status(accepted ? 202 : 400).json({ accepted });
  });

  const reportLimiter = new RateLimiter(30, 60_000);
  closers.push(() => reportLimiter.stop());

  app.get("/api/analytics/summary", requireTenant, async (req, res, next) => {
    try {
      const tenant = tenantOf(res)!;
      const adminToken = options.analyticsToken?.trim();
      const hotelToken = options.reportTokens?.[tenant.id]?.trim();
      const supplied = (req.get("authorization") || "").replace(/^Bearer\s+/i, "").trim();
      res.setHeader("Cache-Control", "no-store");
      if (supplied && !reportLimiter.take(req.ip || "unknown")) {
        res.setHeader("Retry-After", "60");
        return res.status(429).json({ error: "Too many attempts; try again in a minute" });
      }
      const allowed = adminToken || hotelToken
        ? Boolean(supplied) && [adminToken, hotelToken].some((token) => token && tokensMatch(supplied, token))
        : mode !== "production" && isLoopback(req.socket.remoteAddress);
      if (!allowed) return res.status(404).json({ error: "Not found" });
      const counts = analytics.summary(tenant.id);
      const idsFor = (prefix: string) => Object.keys(counts)
        .map((key) => key.startsWith(prefix) ? Number(key.slice(prefix.length)) : NaN)
        .filter(Number.isInteger);
      const { namesFor } = await import("./placeNames");
      return res.json({
        tenant: tenant.id,
        hotel: tenant.config.name,
        timezone: tenant.config.timezone,
        updatedAt: new Date().toISOString(),
        privacy: "aggregate-only",
        counts,
        names: namesFor(idsFor("place_detail_view|placeId:"), idsFor("tour_open|tourId:")),
      });
    } catch (error) {
      return next(error);
    }
  });

  app.get("/api/commons-photos", requireTenant, serviceLimiter.middleware(), async (req, res, next) => {
    try {
      const place = typeof req.query.place === "string" ? req.query.place.trim().slice(0, 100) : "";
      const english = typeof req.query.english === "string" ? req.query.english.trim().slice(0, 100) : "";
      const limit = Math.min(Math.max(Number(req.query.limit) || 6, 1), 10);
      if (!place) return res.status(400).json({ error: "A place name is required" });
      const tenant = tenantOf(res)!;
      const result = await getCommonsPhotos(place, english, DESTINATIONS[tenant.config.destination].commonsSearchHint, limit);
      res.setHeader("Cache-Control", "public, max-age=3600");
      return res.json(result);
    } catch (error) {
      return next(error);
    }
  });

  app.post("/api/route", requireTenant, serviceLimiter.middleware(), async (req, res, next) => {
    try {
      const coordinates = req.body?.coordinates;
      if (
        !Array.isArray(coordinates)
        || coordinates.length < 2
        || coordinates.length > 25
        || !coordinates.every(isValidCoordinate)
      ) {
        return res.status(400).json({ error: "Two to twenty-five valid coordinates are required" });
      }
      const route = await getWalkingRoute(coordinates);
      if (!route) return res.status(503).json({ error: "Verified walking route unavailable", fallback: false });
      return res.json(route);
    } catch (error) {
      return next(error);
    }
  });

  app.get("/api/weather", requireTenant, serviceLimiter.middleware(), async (_req, res, next) => {
    try {
      const tenant = tenantOf(res)!;
      if (!tenant.config.features.weather) return res.status(404).json({ error: "Weather is disabled" });
      const weather = await getWeather(tenant.config.location.lat, tenant.config.location.lng, tenant.config.timezone);
      res.setHeader("Cache-Control", "public, max-age=600");
      return res.status(weather.available ? 200 : 503).json(weather);
    } catch (error) {
      return next(error);
    }
  });

  app.post("/api/ai-guide", requireTenant, async (req, res, next) => {
    try {
      const tenant = tenantOf(res)!;
      if (!tenant.config.features.aiGuide) return res.status(404).json({ error: "The AI guide is disabled" });
      const question = typeof req.body?.question === "string" ? req.body.question.trim() : "";
      if (!question) return res.status(400).json({ error: "A question is required" });
      if (question.length > AI_QUESTION_MAX_LENGTH) return res.status(400).json({ error: "Question is too long" });
      if (req.body?.language !== undefined && !isLanguage(req.body.language)) {
        return res.status(400).json({ error: "Unsupported language" });
      }
      if (!aiLimiter.take(req.ip || "unknown")) {
        res.setHeader("Retry-After", "60");
        return res.status(429).json({ error: "Please wait before asking another question" });
      }
      const language = parseLanguage(req.body?.language, tenant.config.defaultLanguage);
      const result = await ai.ask(tenant, question, language, sanitizeHistory(req.body?.history));
      res.setHeader("Cache-Control", "no-store");
      return res.json(result);
    } catch (error) {
      return next(error);
    }
  });

  app.use("/api", (_req, res) => {
    res.status(404).json({ error: "Not found" });
  });

  /* ------------------------------------------------------- Hotel assets */

  for (const tenant of registry.tenants) {
    app.use(`/tenant-assets/${tenant.id}`, express.static(tenant.assetsDirectory, {
      index: false,
      dotfiles: "ignore",
      fallthrough: false,
      setHeaders: (res, filePath) => {
        res.setHeader("Cache-Control", "public, max-age=3600");
        if (filePath.endsWith(".svg")) res.setHeader("Content-Security-Policy", "script-src 'none'");
      },
    }));
  }

  app.get("/manifest.webmanifest", (_req, res) => {
    const tenant = tenantOf(res);
    if (!tenant) return res.status(404).end();
    res.setHeader("Cache-Control", "no-cache");
    res.type("application/manifest+json");
    return res.send(JSON.stringify(buildManifest(tenant, previewQuery(res, tenant))));
  });

  const imageRoutes: Record<string, GeneratedImage> = {
    "/icon-192.png": "icon192",
    "/icon-512.png": "icon512",
    "/icon-maskable-512.png": "maskable512",
    "/apple-touch-icon.png": "appleTouch",
    "/apple-touch-icon-precomposed.png": "appleTouch",
    "/og-image.png": "og",
    "/favicon.ico": "favicon",
  };
  app.get(Object.keys(imageRoutes), (req, res) => {
    const file = tenantOf(res)?.images[imageRoutes[req.path]];
    if (!file) return res.status(404).type("text/plain").send("Not found");
    res.setHeader("Cache-Control", "public, max-age=3600");
    if (file.endsWith(".ico")) res.type("image/x-icon");
    return res.sendFile(file);
  });

  app.get("/icon.svg", (_req, res) => {
    const tenant = tenantOf(res);
    if (!tenant) return res.status(404).end();
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.setHeader("Content-Security-Policy", "script-src 'none'");
    res.type("image/svg+xml");
    return res.send(buildIconSvg(tenant));
  });

  /* ------------------------------------------------- Staff & sales pages */

  app.get("/robots.txt", (_req, res) => {
    res.setHeader("Cache-Control", "public, max-age=3600");
    res.type("text/plain").send("User-agent: *\nDisallow: /api/\nDisallow: /demo\nDisallow: /qr\nDisallow: /rapor\nDisallow: /tanitim\n");
  });

  /** Public address of the hotel's guide, used inside QR codes. */
  const guideBaseUrl = (req: Request, res: Response, tenant: Tenant) =>
    res.locals.preview
      ? `${publicOrigin(req, res, tenant)}/?otel=${encodeURIComponent(tenant.id)}`
      : `${publicOrigin(req, res, tenant)}/`;

  app.get("/rapor", (_req, res) => {
    const tenant = tenantOf(res);
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Robots-Tag", "noindex");
    if (!tenant) return res.status(404).type("html").send(NOT_CONFIGURED_HTML);
    return res.type("html").send(renderReportPage(tenant));
  });

  app.get("/qr", serviceLimiter.middleware(), async (req, res, next) => {
    try {
      const tenant = tenantOf(res);
      res.setHeader("Cache-Control", "no-store");
      res.setHeader("X-Robots-Tag", "noindex");
      if (!tenant) return res.status(404).type("html").send(NOT_CONFIGURED_HTML);
      const roomsInput = typeof req.query.rooms === "string" ? req.query.rooms.slice(0, 400) : "";
      const singleRoom = typeof req.query.room === "string" ? req.query.room.slice(0, 12) : "";
      const parsed = parseRooms(roomsInput || singleRoom);
      const notices: string[] = [];
      if (parsed.error) notices.push(`Oda kartları hazırlanamadı: ${parsed.error}.`);
      const guideUrl = guideBaseUrl(req, res, tenant);
      if (isPrivateAddress(guideUrl)) {
        notices.push("Bu QR kodlar bu bilgisayarın yerel adresini açıyor; misafir telefonları bu adrese ulaşamaz. Sayfayı yayındaki adresten açın ya da hotel.json içindeki hosts alanına otelin alan adını yazın.");
      } else if (guideUrl.startsWith("http://")) {
        notices.push("Adres https ile başlamıyor. Konum ve paylaşım özellikleri için rehberi HTTPS ile yayınlayın.");
      }
      const rooms = parsed.error ? [] : parsed.rooms;
      const layout = rooms.length > 0 || req.query.layout === "cards" ? "cards" : "poster";
      return res.type("html").send(await renderQrPage({
        tenant,
        guideUrl,
        layout,
        rooms,
        roomsInput,
        notices,
        keepQuery: res.locals.preview ? `otel=${encodeURIComponent(tenant.id)}&` : "",
      }));
    } catch (error) {
      return next(error);
    }
  });

  const demoPage = (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("X-Robots-Tag", "noindex");
    const current = res.locals.preview ? tenantOf(res)?.id ?? null : null;
    return res.type("html").send(renderDemoPage({
      tenants: registry.tenants,
      origin: `${req.protocol}://${req.get("host")}`,
      currentId: current,
    }));
  };

  if (options.demo) {
    // Sales brochure for hotel owners (print to PDF); QR codes use the public address.
    app.get("/tanitim", async (req, res, next) => {
      try {
        res.setHeader("Cache-Control", "no-store");
        res.setHeader("X-Robots-Tag", "noindex");
        const requested = typeof req.query.adres === "string" ? req.query.adres.trim() : "";
        let publicUrl: string | null = null;
        if (/^https:\/\/[^\s"'<>]+$/.test(requested)) publicUrl = requested;
        else if (!isPrivateAddress(`${req.protocol}://${req.get("host")}/`)) publicUrl = `${req.protocol}://${req.get("host")}`;
        return res.type("html").send(await renderBrochurePage({
          designs: DESIGN_IDS.map((id) => ({ preset: DESIGNS[id], hotelId: registry.get(`tasarim-${id}`) ? `tasarim-${id}` : null })),
          publicUrl,
          contact: options.salesContact ?? [],
          demoHotelId: registry.get("demo") ? "demo" : registry.tenants.find((tenant) => tenant.id.startsWith("tasarim-"))?.id ?? null,
          notices: publicUrl ? [] : ["Bu sayfa yerel adresten açıldı: canlı demo QR kodları yayındaki adresten açıldığında (ya da ?adres=https://... ile) eklenir."],
        }));
      } catch (error) {
        return next(error);
      }
    });

    app.get("/demo", (req, res) => {
      const key = options.demoKey?.trim();
      const supplied = typeof req.query.anahtar === "string" ? req.query.anahtar : typeof req.query.key === "string" ? req.query.key : "";
      if (key && !(supplied && tokensMatch(supplied, key))) {
        res.setHeader("Cache-Control", "no-store");
        return res.status(404).type("text/plain").send("Not found");
      }
      return demoPage(req, res);
    });
  }

  /* ---------------------------------------------------------- Front end */

  let loadTemplate: (url: string) => Promise<string> = async () => "";
  const renderHtml = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenant = tenantOf(res);
      res.setHeader("Cache-Control", "no-cache");
      if (!tenant) {
        // Demo servers without a default hotel open the hotel list instead.
        if (options.demo && !options.demoKey?.trim()) return demoPage(req, res);
        return res.status(404).type("html").send(NOT_CONFIGURED_HTML);
      }
      const template = await loadTemplate(req.originalUrl);
      return res.type("html").send(renderIndexHtml(template, tenant, {
        imageUrl: (file) => `${publicOrigin(req, res, tenant)}/${file}${previewQuery(res, tenant)}`,
        assetQuery: previewQuery(res, tenant),
      }));
    } catch (error) {
      return next(error);
    }
  };
  if (mode === "production") {
    const distDir = path.join(options.rootDir, "dist");
    let template: string;
    try {
      template = readFileSync(path.join(distDir, "index.html"), "utf8");
    } catch {
      throw new Error(`dist/index.html not found in ${distDir}. Run "npm run build" first.`);
    }
    loadTemplate = async () => template;
    app.get("/index.html", (req, res, next) => void renderHtml(req, res, next));
    app.use(express.static(distDir, {
      index: false,
      // Folders such as /tanitim are not pages: no "/tanitim/" redirect.
      redirect: false,
      setHeaders: (res, filePath) => {
        if (filePath.endsWith(`${path.sep}index.html`)) {
          res.setHeader("Cache-Control", "no-cache");
        } else if (filePath.includes(`${path.sep}assets${path.sep}`)) {
          res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        } else if (filePath.endsWith("sw.js")) {
          res.setHeader("Cache-Control", "no-cache");
        } else {
          res.setHeader("Cache-Control", "public, max-age=3600");
        }
      },
    }));
  } else if (mode === "development") {
    const { createServer } = await import("vite");
    const vite = await createServer({
      root: options.rootDir,
      server: { middlewareMode: true },
      appType: "custom",
    });
    closers.push(() => vite.close());
    app.use(vite.middlewares);
    loadTemplate = async (url) => {
      const raw = await readFile(path.join(options.rootDir, "index.html"), "utf8");
      return vite.transformIndexHtml(url, raw);
    };
  } else {
    loadTemplate = async () => options.testIndexHtml ?? "";
  }

  app.get("*", (req, res, next) => {
    // Missing files must not be answered with the app shell.
    if (/\.[a-z0-9]{1,8}$/i.test(req.path) && req.path !== "/index.html") {
      return res.status(404).type("text/plain").send("Not found");
    }
    return void renderHtml(req, res, next);
  });

  // Errors: JSON for the API, plain text elsewhere; never a stack trace.
  app.use((error: Error & { status?: number; type?: string }, req: Request, res: Response, _next: NextFunction) => {
    const status = error.type === "entity.parse.failed"
      ? 400
      : error.type === "entity.too.large"
        ? 413
        : error.status && error.status >= 400 && error.status < 600
          ? error.status
          : 500;
    if (status >= 500) console.error("[IrisMap] request failed:", req.method, req.path, error);
    if (res.headersSent) return;
    const message = status === 400 ? "Invalid request body" : status === 413 ? "Request is too large" : status === 404 ? "Not found" : "Something went wrong";
    if (req.path.startsWith("/api/")) res.status(status).json({ error: message });
    else res.status(status).type("text/plain").send(message);
  });

  return {
    app,
    close: async () => {
      for (const close of closers) await close();
      analytics.close();
    },
  };
}
