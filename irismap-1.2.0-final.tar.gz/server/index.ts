import "dotenv/config";
import path from "node:path";
import { readFileSync } from "node:fs";
import { AiGuide } from "./ai";
import { AnalyticsStore } from "./analytics";
import { createApp, parseTrustProxy, type AppMode } from "./app";
import { loadTenants, TenantLoadError } from "./tenants";

const rootDir = process.cwd();
const mode: AppMode = process.env.NODE_ENV === "production" || process.argv.includes("--production")
  ? "production"
  : "development";

const readVersion = () => {
  try {
    return (JSON.parse(readFileSync(path.join(rootDir, "package.json"), "utf8")) as { version?: string }).version ?? "unknown";
  } catch {
    return "unknown";
  }
};

/** ANALYTICS_TOKEN_<HOTEL_ID> (e.g. ANALYTICS_TOKEN_GRAND_KONYA) opens one hotel's report. */
function reportTokensFromEnv(ids: string[]): Record<string, string> {
  const tokens: Record<string, string> = {};
  for (const id of ids) {
    const value = process.env[`ANALYTICS_TOKEN_${id.toUpperCase().replace(/-/g, "_")}`]?.trim();
    if (!value) continue;
    if (value.length < 12) console.warn(`[IrisMap] warning: the report key for "${id}" is shorter than 12 characters; use a longer one.`);
    tokens[id] = value;
  }
  return tokens;
}

async function main() {
  // Demo links (/?otel=<id>, /demo) and demo hotels are on while developing unless switched off.
  const demo = process.env.IRISMAP_DEMO === "true" || (mode === "development" && process.env.IRISMAP_DEMO !== "false");
  const tenantsDir = path.resolve(rootDir, process.env.IRISMAP_TENANTS_DIR || "tenants");
  const registry = loadTenants(tenantsDir, process.env.IRISMAP_DEFAULT_TENANT, console.warn, { includeDemo: demo });
  console.log(
    `[IrisMap] ${registry.tenants.length} hotel(s) loaded: ${registry.tenants.map((tenant) => tenant.id).join(", ")}`
    + (registry.defaultTenant
      ? ` (default: ${registry.defaultTenant.id})`
      : demo ? " (no default; other addresses show the demo hotel list)" : " (no default; unknown hosts get 404)"),
  );

  const analytics = new AnalyticsStore(path.resolve(rootDir, process.env.ANALYTICS_DIR || "data/analytics"), {
    legacyFile: path.resolve(rootDir, process.env.ANALYTICS_FILE || "data/analytics-summary.json"),
    legacyTenantId: registry.defaultTenant?.id,
  });

  const { app, close } = await createApp({
    registry,
    analytics,
    ai: new AiGuide(),
    mode,
    rootDir,
    analyticsToken: process.env.ANALYTICS_ADMIN_TOKEN,
    reportTokens: reportTokensFromEnv(registry.tenants.map((tenant) => tenant.id)),
    allowFraming: process.env.IRISMAP_ALLOW_FRAMING === "true",
    trustProxy: parseTrustProxy(process.env.TRUST_PROXY),
    version: readVersion(),
    demo,
    demoKey: process.env.IRISMAP_DEMO_KEY,
    salesContact: (process.env.IRISMAP_SATIS_ILETISIM ?? "").split("|").map((line) => line.trim()).filter(Boolean).slice(0, 6),
  });

  const port = Number(process.env.PORT) || 3000;
  const host = process.env.HOST || "0.0.0.0";
  const server = app.listen(port, host, () => {
    console.log(`[IrisMap] ${mode} server running at http://localhost:${port}`);
    if (demo) {
      console.log(`[IrisMap] demo links: http://localhost:${port}/demo`);
    }
  });

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`[IrisMap] ${signal} received, shutting down…`);
    const force = setTimeout(() => process.exit(0), 8000);
    force.unref();
    server.close(() => {
      void close().finally(() => process.exit(0));
    });
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("unhandledRejection", (reason) => {
    console.error("[IrisMap] unhandled promise rejection:", reason);
  });
}

main().catch((error) => {
  if (error instanceof TenantLoadError) {
    console.error(`\n[IrisMap] ${error.message}\n`);
  } else {
    console.error("[IrisMap] failed to start:", error);
  }
  process.exit(1);
});
