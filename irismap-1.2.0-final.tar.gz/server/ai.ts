import { GoogleGenAI } from "@google/genai";
import { cityName, hotelName, localized } from "../shared/guideText";
import { formatText, isLanguage, type Language } from "../shared/languages";
import type { Tenant } from "./tenants";

export const AI_QUESTION_MAX_LENGTH = 800;
export const AI_HISTORY_MAX_TURNS = 8;
const AI_TIMEOUT_MS = 25_000;

const LANGUAGE_NAMES: Record<Language, string> = {
  TR: "Turkish",
  EN: "English",
  DE: "German",
  ZH: "Simplified Chinese",
  RU: "Russian",
  AR: "Modern Standard Arabic", // audit:allow-latin (instruction for the AI model)
};

export interface ChatTurn {
  role: "user" | "model";
  text: string;
}

/** Keeps only well-formed, size-limited turns that start with a user turn. */
export function sanitizeHistory(value: unknown): ChatTurn[] {
  if (!Array.isArray(value)) return [];
  const turns = value
    .filter((item): item is ChatTurn =>
      !!item
      && typeof item === "object"
      && ((item as ChatTurn).role === "user" || (item as ChatTurn).role === "model")
      && typeof (item as ChatTurn).text === "string"
      && (item as ChatTurn).text.trim().length > 0)
    .map((item) => ({ role: item.role, text: item.text.trim().slice(0, AI_QUESTION_MAX_LENGTH * 2) }))
    .slice(-AI_HISTORY_MAX_TURNS);
  while (turns.length > 0 && turns[0].role !== "user") turns.shift();
  return turns;
}

export function buildSystemPrompt(tenant: Tenant, language: Language): string {
  const { config } = tenant;
  const hotel = hotelName(config, "EN");
  const city = cityName(config, "EN");
  const services = [
    ...config.services.included.map((item) => `- ${localized(config, item, "EN")} (included)`),
    ...config.services.onRequest.map((item) => `- ${localized(config, item, "EN")} (on request)`),
  ];
  const contact = [
    config.contact.phone && `Reception phone: ${config.contact.phone.display}`,
    config.contact.whatsapp && `Reception WhatsApp: ${config.contact.whatsapp.display}`,
    config.contact.email && `E-mail: ${config.contact.email}`,
    config.contact.website && `Website: ${config.contact.website}`,
  ].filter(Boolean);
  const address = localized(config, config.location.address, "EN");

  return [
    `You are the virtual concierge and ${city} guide of "${hotel}", a hotel in ${city}.`,
    "Your tone is polite, warm, professional and concise.",
    "",
    "SCOPE",
    `- Only help with ${city}'s sights, history, culture, traditional food, crafts and shopping, getting around the city, visit planning, and the hotel's guest services.`,
    `- For anything else, politely say that you are ${hotel}'s ${city} guide and offer help with the topics above.`,
    "- Never ask for or store the guest's name, room number or any personal data.",
    "- Stay neutral: never recommend, rank or promote a named restaurant, shop, tour company or other business. You may suggest dishes, crafts, neighbourhoods, transport types or experiences, and refer guests to reception for a suitable business.",
    "- Do not present opening hours, prices, event dates or timetables as current unless they appear in this conversation; ask guests to confirm changeable information before visiting.",
    "- Do not invent hotel facts. If a hotel question is not answered by the facts below, ask the guest to contact reception.",
    "",
    "HOTEL FACTS",
    `- Name: ${hotel}`,
    address ? `- Address: ${address}` : "",
    ...contact.map((line) => `- ${line}`),
    services.length ? "- Guest services:" : "",
    ...services,
    tenant.server.aiHotelFacts ? `- Notes: ${tenant.server.aiHotelFacts}` : "",
    "",
    "ANSWER FORMAT",
    `- Always answer in ${LANGUAGE_NAMES[language]}.`,
    "- Keep answers structured and under 250 words. Plain text only; short lists are fine.",
  ].filter((line) => line !== "").join("\n");
}

/* ------------------------------------------------------------------------ */
/* Offline answers (no API key, quota exhausted or provider error)          */
/* ------------------------------------------------------------------------ */

const ON_TOPIC_KEYWORDS = [
  "mevlana", "rumi", "müze", "museum", "hotel", "otel", "konya", "cami", "mosque", "medrese", "madrasa",
  "tarih", "history", "kültür", "culture", "yemek", "eat", "food", "kebap", "kebab", "etliekmek", "bamya",
  "çorba", "soup", "tatlı", "dessert", "gezi", "tour", "rota", "route", "oda", "room", "kahvaltı", "breakfast",
  "karatay", "ince minare", "alaeddin", "aziziye", "sahip ata", "şems", "sems", "selimiye", "meram", "selçuklu",
  "seljuk", "sille", "plan", "itinerary", "ulaşım", "transport", "tram", "tramvay", "alışveriş", "shopping",
  "görmem", "gezilecek", "şehir", "yöresel", "hizmet", "dish", "cuisine", "visit", "see", "miss", "city", "service",
  "essen", "speise", "gericht", "küche", "sehenswürdigkeit", "moschee", "geschichte", "reise", "verpassen", "leistung",
  "конья", "музей", "мечет", "медрес", "еда", "кухн", "блюд", "маршрут", "отел", "истор", "город", "посмотр", "услуг",
  "قونية", "متحف", "مسجد", "مدرسة", "طعام", "أكل", "مطبخ", "طبق", "أطباق", "مسار", "فندق", "مولانا", "تاريخ", "زيارة", "برنامج", "خدمات",
  "科尼亚", "博物馆", "清真寺", "美食", "食物", "路线", "酒店", "历史", "吃", "服务", "游览", "景点",
];

const SERVICE_KEYWORDS = [
  "hizmet", "olanak", "imkan", "service", "amenit", "facilit", "leistung", "ausstattung",
  "услуг", "удобств", "خدمات", "مرافق", "服务", "设施",
];
const ITINERARY_KEYWORDS = [
  "günlük", "gezi planı", "itinerary", "1-day", "one day", "tagesplan", "tagestour", "一天", "行程", "на один день", "ليوم", "برنامج زيارة",
];

const MUSEUM_KEYWORDS = ["mevlana", "museum", "müze", "музей", "متحف", "مولانا", "博物馆", "梅芙拉纳"];
const FOOD_KEYWORDS = [
  "yemek", "ne yenir", "kebap", "kebab", "etliekmek", "lezzet", "food", "eat", "dish", "cuisine", "restaurant",
  "essen", "speis", "gericht", "küche", "еда", "кебаб", "кухн", "блюд", "طعام", "أكل", "كباب", "مطبخ", "طبق", "أطباق",
  "美食", "食物", "吃", "菜",
];

const OFFLINE_TEXT: Record<"offTopic" | "museum" | "food" | "general" | "itinerary" | "services" | "noServices", Record<Language, string>> = {
  itinerary: {
    TR: "Konya için 1 günlük örnek plan: Sabah Mevlana Müzesi ve Selimiye Camii; ardından Aziziye Camii ve tarihî çarşı. Öğle yemeğinde etliekmek veya fırın kebabı deneyebilirsiniz. Öğleden sonra Alaeddin Tepesi ve Alaeddin Camii, İnce Minareli Medrese ve Karatay Medresesi. Akşam, programa uygunsa Mevlana Kültür Merkezi'nde sema gösterisi. Açılış saatlerini ve programı ziyaret öncesinde teyit edin; uygulamadaki Hazır Rotalar bölümünü de kullanabilirsiniz.",
    EN: "A sample day in Konya: in the morning, the Mevlana Museum and Selimiye Mosque, then Aziziye Mosque and the historic bazaar. For lunch try etliekmek or fırın kebabı. In the afternoon, Alaeddin Hill and Mosque, the İnce Minareli Madrasa and the Karatay Madrasa. In the evening, a sema ceremony at the Mevlana Cultural Center if one is scheduled. Please confirm opening hours and programmes before visiting; the Curated Routes section of this guide can help too.",
    DE: "Ein Beispieltag in Konya: Vormittags das Mevlana-Museum und die Selimiye-Moschee, danach die Aziziye-Moschee und der historische Basar. Mittags Etliekmek oder Fırın Kebabı probieren. Nachmittags Alaeddin-Hügel und -Moschee, die İnce-Minareli-Medrese und die Karatay-Medrese. Abends – falls im Programm – eine Sema-Zeremonie im Mevlana-Kulturzentrum. Bitte prüfen Sie Öffnungszeiten und Programm vorab; auch die ausgewählten Routen dieses Führers helfen.",
    ZH: "科尼亚一日游建议：上午参观梅芙拉纳博物馆和塞利米耶清真寺，然后前往阿齐齐耶清真寺和历史集市。午餐可品尝 Etliekmek 肉饼或烤羊肉。下午游览阿拉丁山与阿拉丁清真寺、细塔神学院和卡拉泰神学院。晚上如有安排，可在梅芙拉纳文化中心观看旋转舞仪式。请在参观前确认开放时间和日程，也可使用本指南的精选路线。",
    RU: "Пример дня в Конье: утром — Музей Мевляны и мечеть Селимие, затем мечеть Азизие и исторический базар. На обед попробуйте этлиэкмек или фырын-кебаб. После обеда — холм и мечеть Алаэддина, медресе Индже Минаре и медресе Каратай. Вечером, если есть в программе, — церемония сема в Культурном центре Мевляны. Уточняйте часы работы и программу заранее; помогут и готовые маршруты в этом путеводителе.",
    AR: "برنامج مقترح ليوم في قونية: صباحاً متحف مولانا وجامع السليمية، ثم جامع العزيزية والسوق التاريخي. على الغداء جرّب إيتلي إكمك أو كباب الفرن. بعد الظهر تلة علاء الدين وجامعها ومدرسة إنجه منارة ومدرسة قره طاي. مساءً، إن توفر في البرنامج، عرض السماع في مركز مولانا الثقافي. يُرجى التحقق من ساعات الزيارة والبرامج مسبقاً، ويمكنك أيضاً الاستفادة من المسارات المقترحة في هذا الدليل.",
  },
  services: {
    TR: "{hotel} misafirlerine sunulan hizmetler: {services}. Ayrıntılar ve talepleriniz için resepsiyona başvurabilirsiniz.",
    EN: "Services for {hotel} guests: {services}. Please contact reception for details or requests.",
    DE: "Leistungen für Gäste von {hotel}: {services}. Für Details oder Wünsche wenden Sie sich bitte an die Rezeption.",
    ZH: "{hotel}为宾客提供的服务：{services}。如需了解详情或提出需求，请联系前台。",
    RU: "Услуги для гостей ({hotel}): {services}. За подробностями и с просьбами обращайтесь на стойку регистрации.",
    AR: "الخدمات المتاحة لضيوف {hotel}: {services}. للتفاصيل أو الطلبات يُرجى التواصل مع الاستقبال.",
  },
  noServices: {
    TR: "Otel hizmetleriyle ilgili güncel bilgi için lütfen {hotel} resepsiyonuna başvurun.",
    EN: "For up-to-date information about hotel services, please contact {hotel} reception.",
    DE: "Aktuelle Informationen zu den Hotelleistungen erhalten Sie an der Rezeption von {hotel}.",
    ZH: "如需了解酒店服务的最新信息，请联系{hotel}前台。",
    RU: "Актуальную информацию об услугах отеля можно получить на стойке регистрации ({hotel}).",
    AR: "للحصول على معلومات محدثة عن خدمات الفندق، يُرجى التواصل مع استقبال {hotel}.",
  },
  offTopic: {
    TR: "{hotel} {city} rehberiyim. Şehirdeki tarihî mekânlar, yerel lezzetler, gezi planı ve otel hizmetleri konusunda yardımcı olabilirim. Lütfen bu konulardan biriyle ilgili soru sorun.",
    EN: "I am the {city} guide of {hotel}. I can help with historic places, local cuisine, visit planning and hotel services. Please ask a question about one of these topics.",
    DE: "Ich bin der {city}-Reiseführer von {hotel}. Ich helfe gern bei historischen Orten, regionaler Küche, Besuchsplanung und Hotelleistungen.",
    ZH: "我是{hotel}的{city}向导，可以为您介绍历史古迹、当地美食、游览安排和酒店服务。请就这些主题提问。",
    RU: "Я гид отеля {hotel} по городу {city}. Могу помочь с историческими местами, местной кухней, планом прогулки и услугами отеля.",
    AR: "أنا دليل {city} في {hotel}. يمكنني مساعدتك في الأماكن التاريخية والمأكولات المحلية وتخطيط الزيارة وخدمات الفندق.",
  },
  museum: {
    TR: "Mevlana Müzesi, Konya'nın en önemli duraklarından biridir. Yeşil Kubbe ve Mevlevî kültürüne ait koleksiyon öne çıkar. Ziyaret saatleri ve giriş koşulları değişebileceği için gitmeden önce resmî kaynaktan teyit etmenizi öneririz.",
    EN: "The Mevlana Museum is one of Konya's most important sights. Its Green Dome and Mevlevi culture collection are highlights. Opening hours and admission conditions may change, so please confirm them with an official source before visiting.",
    DE: "Das Mevlana-Museum gehört zu den wichtigsten Sehenswürdigkeiten Konyas. Besonders sehenswert sind die Grüne Kuppel und die Sammlung zur Mevlevi-Kultur. Bitte prüfen Sie Öffnungszeiten und Eintrittsbedingungen vor dem Besuch bei einer offiziellen Quelle.",
    ZH: "梅芙拉纳博物馆是科尼亚最重要的景点之一，以绿色穹顶和梅夫莱维文化藏品闻名。开放时间和入场规定可能变化，请在参观前通过官方渠道确认。",
    RU: "Музей Мевляны — одна из главных достопримечательностей Коньи. Особенно интересны Зелёный купол и коллекция, посвящённая культуре Мевлеви. Перед посещением уточните часы работы и условия входа в официальном источнике.",
    AR: "يُعد متحف مولانا من أهم معالم قونية، ويشتهر بالقبة الخضراء ومقتنيات الثقافة المولوية. قد تتغير ساعات الزيارة وشروط الدخول، لذا يُنصح بالتأكد من المصدر الرسمي قبل الزيارة.",
  },
  food: {
    TR: "Konya'da fırın kebabı, etliekmek, bamya çorbası ve sac arası gibi geleneksel lezzetleri deneyebilirsiniz. Size yakın ve ihtiyaçlarınıza uygun bir işletme için resepsiyona danışabilirsiniz.",
    EN: "Traditional Konya dishes include fırın kebabı, etliekmek, okra soup and sac arası dessert. Please ask reception for a nearby option suited to your needs.",
    DE: "Zur traditionellen Küche Konyas gehören Fırın Kebabı, Etliekmek, Okrasuppe und das Dessert Sac Arası. Fragen Sie die Rezeption nach einer passenden Möglichkeit in der Nähe.",
    ZH: "在科尼亚可以品尝烤羊肉、Etliekmek 肉饼、秋葵汤和 Sac Arası 甜点。若需寻找附近合适的餐厅，请咨询酒店前台。",
    RU: "К традиционным блюдам Коньи относятся фырын-кебаб, этлиэкмек, суп из бамии и десерт сач-арасы. Подходящее заведение поблизости можно уточнить на стойке регистрации.",
    AR: "يمكنكم تجربة كباب الفرن وإيتلي إكمك وحساء البامية وحلوى ساج أراسي من مطبخ قونية التقليدي. اسألوا مكتب الاستقبال عن مكان قريب ومناسب لاحتياجاتكم.",
  },
  general: {
    TR: "Hoş geldiniz! Kadim Selçuklu başkenti Konya'da gezip görebileceğiniz pek çok medrese, cami ve müze bulunur. {hotel} rehberindeki interaktif harita ve hazır rotalarla keşfe başlayabilir, dilediğiniz konuda resepsiyona danışabilirsiniz.",
    EN: "Welcome to {hotel}! Konya, the historic Seljuk capital, is rich in madrasas, mosques and museums. Use the interactive map and curated routes to start exploring, or ask reception for personal recommendations.",
    DE: "Willkommen bei {hotel}! Über die interaktive Karte und die vorbereiteten Routen entdecken Sie Konyas seldschukische Bauwerke, Moscheen, Medresen und Museen.",
    ZH: "欢迎入住{hotel}！科尼亚是塞尔柱王朝的历史名城，拥有众多神学院、清真寺和博物馆。您可以通过互动地图和精选路线开始探索，也可以随时咨询前台。",
    RU: "Добро пожаловать! Используйте интерактивную карту и готовые маршруты, чтобы познакомиться с сельджукской архитектурой, мечетями, медресе и музеями Коньи. С любыми вопросами можно обратиться на стойку регистрации.",
    AR: "مرحباً بكم في {hotel}! قونية عاصمة سلجوقية تاريخية غنية بالمدارس والمساجد والمتاحف. استخدموا الخريطة التفاعلية والمسارات المقترحة لبدء الاستكشاف، أو اسألوا الاستقبال عن توصيات شخصية.",
  },
};

export function offlineAnswer(question: string, language: Language, tenant: Tenant): string {
  const lower = question.toLocaleLowerCase("tr-TR");
  const { config } = tenant;
  const services = [...config.services.included, ...config.services.onRequest]
    .map((item) => localized(config, item, language))
    .filter(Boolean)
    .join(language === "ZH" ? "、" : language === "AR" ? "، " : ", ");
  const values = { hotel: hotelName(config, language), city: cityName(config, language), services };
  const onTopic = lower.length < 5 || ON_TOPIC_KEYWORDS.some((keyword) => lower.includes(keyword));
  const pick = (topic: keyof typeof OFFLINE_TEXT) => formatText(OFFLINE_TEXT[topic][language], values);
  if (!onTopic) return pick("offTopic");
  if (SERVICE_KEYWORDS.some((keyword) => lower.includes(keyword))) return pick(services ? "services" : "noServices");
  if (ITINERARY_KEYWORDS.some((keyword) => lower.includes(keyword))) return pick("itinerary");
  if (MUSEUM_KEYWORDS.some((keyword) => lower.includes(keyword))) return pick("museum");
  if (FOOD_KEYWORDS.some((keyword) => lower.includes(keyword))) return pick("food");
  return pick("general");
}

/* ------------------------------------------------------------------------ */
/* Gemini client                                                             */
/* ------------------------------------------------------------------------ */

export interface GuideAnswer {
  answer: string;
  mode: "online" | "offline";
}

export class AiGuide {
  private readonly client: GoogleGenAI | null;
  readonly model: string;

  constructor(apiKey = process.env.GEMINI_API_KEY, model = process.env.GEMINI_MODEL) {
    this.model = model?.trim() || "gemini-2.5-flash";
    const key = apiKey?.trim();
    if (!key || key === "MY_GEMINI_API_KEY") {
      this.client = null;
      console.warn("[IrisMap] GEMINI_API_KEY is not set; the AI guide answers with built-in offline replies.");
      return;
    }
    this.client = new GoogleGenAI({ apiKey: key });
  }

  get online() {
    return this.client !== null;
  }

  async ask(tenant: Tenant, question: string, language: Language, history: ChatTurn[] = []): Promise<GuideAnswer> {
    if (!this.client) return { answer: offlineAnswer(question, language, tenant), mode: "offline" };
    try {
      const response = await this.client.models.generateContent({
        model: this.model,
        contents: [
          ...history.map((turn) => ({ role: turn.role, parts: [{ text: turn.text }] })),
          { role: "user", parts: [{ text: question }] },
        ],
        config: {
          systemInstruction: buildSystemPrompt(tenant, language),
          temperature: 0.6,
          abortSignal: AbortSignal.timeout(AI_TIMEOUT_MS),
        },
      });
      const text = response.text?.trim();
      if (!text) throw new Error("Empty response from the AI provider");
      return { answer: text, mode: "online" };
    } catch (error) {
      console.error("[IrisMap] AI provider error; using offline reply:", (error as Error).message);
      return { answer: offlineAnswer(question, language, tenant), mode: "offline" };
    }
  }
}

export const parseLanguage = (value: unknown, fallback: Language): Language =>
  isLanguage(value) ? value : fallback;
