import { readFileSync } from "node:fs";
import path from "node:path";
import { guideDescription, guideTitle, hotelName } from "../shared/guideText";
import type { Language } from "../shared/languages";
import { GENERATED_IMAGES, type Tenant } from "./tenants";

export const escapeHtml = (value: string) =>
  value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

/** JSON that is safe to place inside an inline <script> element. */
export const serializeForScript = (value: unknown) =>
  JSON.stringify(value)
    .replace(/</g, "\\u003c")
    .replace(/>/g, "\\u003e")
    .replace(/&/g, "\\u0026")
    .replace(/\u2028/g, "\\u2028")
    .replace(/\u2029/g, "\\u2029");

export const HEAD_PLACEHOLDER = "<!--irismap:head-->";
export const CONFIG_PLACEHOLDER = "<!--irismap:config-->";

const OG_LOCALES: Record<Language, string> = {
  TR: "tr_TR",
  EN: "en_GB",
  DE: "de_DE",
  ZH: "zh_CN",
  RU: "ru_RU",
  AR: "ar_AR", // audit:allow-latin (locale code)
};

export interface PageContext {
  /** Absolute address of a hotel image, e.g. https://guide.example.com/og-image.png */
  imageUrl: (file: string) => string;
  /**
   * Added to icon and manifest addresses ("?otel=<id>" for demo links), so a
   * phone that opened several demo hotels never mixes up their cached icons.
   */
  assetQuery?: string;
}

/** Adds the hotel's title, colours, icons, link preview and configuration to index.html. */
export function renderIndexHtml(template: string, tenant: Tenant, context?: PageContext): string {
  const { config } = tenant;
  const language = config.defaultLanguage;
  const title = escapeHtml(guideTitle(config, language));
  const description = escapeHtml(guideDescription(config, language));
  const query = escapeHtml(context?.assetQuery ?? "");
  const head = [
    `<title>${title}</title>`,
    `<meta name="description" content="${description}" />`,
    `<meta name="theme-color" content="${escapeHtml(config.branding.base.palette.primary)}" />`,
    ...(tenant.images.favicon ? [`<link rel="icon" href="/favicon.ico${query}" sizes="16x16 32x32 48x48" />`] : []),
    `<link rel="icon" href="/icon.svg${query}" type="image/svg+xml" />`,
    ...(tenant.images.appleTouch ? [`<link rel="apple-touch-icon" href="/apple-touch-icon.png${query}" />`] : []),
    `<link rel="manifest" href="/manifest.webmanifest${query}" />`,
    `<meta name="apple-mobile-web-app-title" content="${escapeHtml(config.shortName)}" />`,
    `<meta name="mobile-web-app-capable" content="yes" />`,
    `<meta property="og:type" content="website" />`,
    `<meta property="og:site_name" content="${escapeHtml(hotelName(config, language))}" />`,
    `<meta property="og:title" content="${title}" />`,
    `<meta property="og:description" content="${description}" />`,
    `<meta property="og:locale" content="${OG_LOCALES[language]}" />`,
    ...(tenant.images.og && context
      ? [
        `<meta property="og:image" content="${escapeHtml(context.imageUrl(GENERATED_IMAGES.og))}" />`,
        `<meta property="og:image:width" content="1200" />`,
        `<meta property="og:image:height" content="630" />`,
        `<meta name="twitter:card" content="summary_large_image" />`,
      ]
      : [`<meta name="twitter:card" content="summary" />`]),
  ].join("\n    ");
  const script = `<script>window.__IRISMAP_CONFIG__=${serializeForScript(config)};</script>`;

  if (!template.includes(HEAD_PLACEHOLDER) || !template.includes(CONFIG_PLACEHOLDER)) {
    throw new Error("index.html is missing the IrisMap placeholders");
  }
  return template
    .replace(/<html lang="[^"]*"( dir="[^"]*")?>/, `<html lang="${language.toLowerCase()}" dir="${language === "AR" ? "rtl" : "ltr"}">`)
    .replace(HEAD_PLACEHOLDER, head)
    .replace(CONFIG_PLACEHOLDER, script);
}

export function buildManifest(tenant: Tenant, assetQuery = "") {
  const { config } = tenant;
  const language = config.defaultLanguage;
  return {
    id: `/${assetQuery}`,
    name: guideTitle(config, language),
    short_name: config.shortName,
    description: guideDescription(config, language),
    start_url: `/${assetQuery}`,
    scope: "/",
    display: "standalone",
    background_color: config.branding.base.palette.page,
    theme_color: config.branding.base.palette.primary,
    lang: language.toLowerCase(),
    dir: language === "AR" ? "rtl" : "ltr",
    icons: [
      { src: `/icon.svg${assetQuery}`, sizes: "any", type: "image/svg+xml", purpose: "any" },
      ...(tenant.images.icon192 ? [{ src: `/icon-192.png${assetQuery}`, sizes: "192x192", type: "image/png", purpose: "any" }] : []),
      ...(tenant.images.icon512 ? [{ src: `/icon-512.png${assetQuery}`, sizes: "512x512", type: "image/png", purpose: "any" }] : []),
      ...(tenant.images.maskable512 ? [{ src: `/icon-maskable-512.png${assetQuery}`, sizes: "512x512", type: "image/png", purpose: "maskable" }] : []),
    ],
  };
}

const iconCache = new Map<string, string>();

/**
 * Square app icon: the hotel logo centred on its frame colour. SVG logos are
 * embedded inline and raster logos as data URIs, because browsers do not load
 * external files from an SVG used as an image.
 */
export function buildIconSvg(tenant: Tenant, { rounded = true }: { rounded?: boolean } = {}): string {
  const cacheKey = `${tenant.id}:${rounded}`;
  const cached = iconCache.get(cacheKey);
  if (cached) return cached;

  const { palette, logoUrl } = tenant.config.branding.base;
  const frame = `<rect width="512" height="512"${rounded ? ' rx="112"' : ""} fill="${palette.logoFrame}"/>`;
  let logo = "";
  const prefix = `/tenant-assets/${tenant.id}/`;
  if (logoUrl.startsWith(prefix)) {
    const file = decodeURIComponent(logoUrl.slice(prefix.length));
    const filePath = path.join(tenant.assetsDirectory, file);
    try {
      if (/\.svg$/i.test(file)) {
        const source = readFileSync(filePath, "utf8")
          .replace(/^﻿/, "")
          .replace(/<\?xml[^>]*\?>/g, "")
          .replace(/<!DOCTYPE[^>]*>/gi, "")
          .trim();
        const nested = source.replace(/^<svg\b/, '<svg x="96" y="80" width="320" height="352" preserveAspectRatio="xMidYMid meet"');
        if (nested !== source) logo = nested;
      } else {
        const mime = /\.png$/i.test(file) ? "image/png" : /\.webp$/i.test(file) ? "image/webp" : "image/jpeg";
        const data = readFileSync(filePath).toString("base64");
        logo = `<image x="96" y="80" width="320" height="352" preserveAspectRatio="xMidYMid meet" href="data:${mime};base64,${data}"/>`;
      }
    } catch {
      logo = "";
    }
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">${frame}${logo}</svg>`;
  iconCache.set(cacheKey, svg);
  return svg;
}

export const NOT_CONFIGURED_HTML = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>IrisMap</title>
<style>body{font-family:system-ui,sans-serif;display:grid;place-items:center;min-height:100vh;margin:0;background:#f7f7f4;color:#2e2e2e}main{max-width:28rem;padding:2rem;text-align:center}</style>
</head><body><main><h1>IrisMap</h1><p>Bu adres için yapılandırılmış bir otel bulunamadı.</p><p>No hotel is configured for this address.</p></main></body></html>`;
