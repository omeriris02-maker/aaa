import type { NextFunction, Request, Response } from "express";

/**
 * Small fixed-window rate limiter keyed by client IP. Old windows are pruned
 * periodically so the map cannot grow without bound.
 */
export class RateLimiter {
  private readonly windows = new Map<string, { startedAt: number; count: number }>();
  private readonly pruneTimer: NodeJS.Timeout;

  constructor(
    private readonly limit: number,
    private readonly windowMs: number,
    private readonly maxKeys = 50_000,
  ) {
    this.pruneTimer = setInterval(() => this.prune(), windowMs);
    this.pruneTimer.unref?.();
  }

  /** Returns true when the request is allowed. */
  take(key: string, now = Date.now()): boolean {
    const current = this.windows.get(key);
    if (!current || now - current.startedAt >= this.windowMs) {
      if (!current && this.windows.size >= this.maxKeys) this.prune(now);
      this.windows.set(key, { startedAt: now, count: 1 });
      return true;
    }
    current.count += 1;
    return current.count <= this.limit;
  }

  prune(now = Date.now()) {
    for (const [key, value] of this.windows) {
      if (now - value.startedAt >= this.windowMs) this.windows.delete(key);
    }
    // Still full (sustained flood from many addresses): start over rather than
    // growing without bound.
    if (this.windows.size >= this.maxKeys) this.windows.clear();
  }

  get size() {
    return this.windows.size;
  }

  stop() {
    clearInterval(this.pruneTimer);
  }

  middleware(message = "Too many requests, please wait a moment") {
    return (req: Request, res: Response, next: NextFunction) => {
      if (this.take(req.ip || "unknown")) return next();
      res.setHeader("Retry-After", String(Math.ceil(this.windowMs / 1000)));
      return res.status(429).json({ error: message });
    };
  }
}

/** Bounded cache with expiry; the oldest entry is evicted when full. */
export class ExpiringCache<T> {
  private readonly entries = new Map<string, { expiresAt: number; value: T }>();

  constructor(private readonly maxEntries: number, private readonly ttlMs: number) {}

  get(key: string, now = Date.now()): T | undefined {
    const entry = this.entries.get(key);
    if (!entry) return undefined;
    if (entry.expiresAt <= now) {
      this.entries.delete(key);
      return undefined;
    }
    return entry.value;
  }

  set(key: string, value: T, now = Date.now()) {
    this.entries.delete(key);
    if (this.entries.size >= this.maxEntries) {
      const oldest = this.entries.keys().next().value;
      if (oldest !== undefined) this.entries.delete(oldest);
    }
    this.entries.set(key, { expiresAt: now + this.ttlMs, value });
  }

  get size() {
    return this.entries.size;
  }
}
