import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from "node:fs";
import path from "node:path";
import { isLanguage } from "../shared/languages";

export const ANALYTICS_EVENTS = new Set([
  "app_open",
  "language_select",
  "theme_select",
  "module_open",
  "place_detail_view",
  "tour_open",
  "route_start",
  "show_on_map",
  "reception_call",
  "whatsapp_click",
  "email_click",
  "booking_click",
  "feedback_start",
]);

export const ANALYTICS_MODULES = new Set([
  "HOME",
  "MAP",
  "TOURS",
  "PERSONAL",
  "SETTINGS",
  "PLACES",
  "EVENTS",
  "AI_GUIDE",
  "PRACTICAL",
  "HOTEL",
  "PRIVACY",
  "hotel",
  "hotel_booking",
  "events",
]);

/** Upper bound of distinct counters per hotel; protects memory and disk. */
export const MAX_KEYS_PER_TENANT = 5000;
const WRITE_INTERVAL_MS = 5000;

type Metadata = Record<string, unknown>;

/** Converts untrusted metadata into the small set of allowed dimensions. */
export function safeDimensions(metadata: unknown): Record<string, string> {
  const dimensions: Record<string, string> = {};
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return dimensions;
  const value = metadata as Metadata;
  if (isLanguage(value.language)) dimensions.language = value.language;
  if (typeof value.theme === "string" && /^[a-z0-9-]{1,40}$/.test(value.theme)) dimensions.theme = value.theme;
  if (typeof value.module === "string" && ANALYTICS_MODULES.has(value.module)) dimensions.module = value.module;
  if (Number.isInteger(value.placeId) && (value.placeId as number) > 0 && (value.placeId as number) < 100_000) {
    dimensions.placeId = String(value.placeId);
  }
  if (Number.isInteger(value.tourId) && (value.tourId as number) >= -1 && (value.tourId as number) < 1000) {
    dimensions.tourId = String(value.tourId);
  }
  if (Number.isInteger(value.routeStopCount) && (value.routeStopCount as number) > 0 && (value.routeStopCount as number) <= 25) {
    dimensions.routeStopCount = String(value.routeStopCount);
  }
  return dimensions;
}

/** Calendar month ("2026-10") in the hotel's time zone. */
export function monthIn(timezone: string, date: Date = new Date()): string {
  try {
    const parts = new Intl.DateTimeFormat("en-CA", { timeZone: timezone, year: "numeric", month: "2-digit" }).formatToParts(date);
    const year = parts.find((part) => part.type === "year")?.value;
    const month = parts.find((part) => part.type === "month")?.value;
    if (year && month) return `${year}-${month}`;
  } catch {
    // unknown time zone: fall back to UTC
  }
  return date.toISOString().slice(0, 7);
}

interface TenantCounters {
  counts: Map<string, number>;
  dirty: boolean;
}

/**
 * Aggregate-only counters per hotel, persisted as one JSON file per hotel.
 * Writes are throttled and atomic (temporary file + rename) so a crash never
 * leaves a half-written file behind.
 */
export class AnalyticsStore {
  private readonly tenants = new Map<string, TenantCounters>();
  private timer: NodeJS.Timeout | null = null;

  constructor(
    private readonly directory: string,
    private readonly options: { legacyFile?: string; legacyTenantId?: string; persist?: boolean } = {},
  ) {}

  private fileFor(tenantId: string) {
    return path.join(this.directory, `${tenantId}.json`);
  }

  private load(tenantId: string): TenantCounters {
    const existing = this.tenants.get(tenantId);
    if (existing) return existing;
    const counters: TenantCounters = { counts: new Map(), dirty: false };
    const file = this.fileFor(tenantId);
    let source: string | null = null;
    if (this.options.persist !== false) {
      if (existsSync(file)) source = file;
      else if (
        this.options.legacyFile
        && this.options.legacyTenantId === tenantId
        && existsSync(this.options.legacyFile)
      ) {
        source = this.options.legacyFile;
        counters.dirty = true;
      }
    }
    if (source) {
      try {
        const stored = JSON.parse(readFileSync(source, "utf8")) as Record<string, unknown>;
        const entries = stored && typeof stored === "object" && "counts" in stored && typeof stored.counts === "object"
          ? (stored.counts as Record<string, unknown>)
          : stored;
        for (const [key, value] of Object.entries(entries ?? {})) {
          if (typeof value === "number" && Number.isFinite(value) && value >= 0 && key.length <= 120) {
            counters.counts.set(key, Math.floor(value));
          }
          if (counters.counts.size >= MAX_KEYS_PER_TENANT) break;
        }
      } catch (error) {
        console.warn(`[IrisMap] analytics file for "${tenantId}" could not be read; starting empty.`, error);
      }
    }
    this.tenants.set(tenantId, counters);
    return counters;
  }

  private increment(counters: TenantCounters, key: string) {
    const current = counters.counts.get(key);
    if (current === undefined && counters.counts.size >= MAX_KEYS_PER_TENANT) return;
    counters.counts.set(key, (current ?? 0) + 1);
    counters.dirty = true;
  }

  /**
   * Counts one event: an all-time total, one per allowed dimension and a
   * monthly total (`month:2026-10|app_open`) for hotel reports. Returns
   * false when the event name is not allowed.
   */
  record(
    tenantId: string,
    event: unknown,
    metadata: unknown,
    { timezone = "UTC", now = new Date() }: { timezone?: string; now?: Date } = {},
  ): boolean {
    if (typeof event !== "string" || !ANALYTICS_EVENTS.has(event)) return false;
    const counters = this.load(tenantId);
    const dimensions = safeDimensions(metadata);
    this.increment(counters, event);
    for (const [key, value] of Object.entries(dimensions)) {
      this.increment(counters, `${event}|${key}:${value}`);
    }
    const month = `month:${monthIn(timezone, now)}`;
    this.increment(counters, `${month}|${event}`);
    if (event === "app_open" && dimensions.language) this.increment(counters, `${month}|${event}|language:${dimensions.language}`);
    this.schedule();
    return true;
  }

  summary(tenantId: string) {
    const counters = this.load(tenantId);
    return Object.fromEntries([...counters.counts.entries()].sort(([a], [b]) => a.localeCompare(b)));
  }

  private schedule() {
    if (this.options.persist === false || this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flush();
    }, WRITE_INTERVAL_MS);
    this.timer.unref?.();
  }

  flush() {
    if (this.options.persist === false) return;
    for (const [tenantId, counters] of this.tenants) {
      if (!counters.dirty) continue;
      try {
        mkdirSync(this.directory, { recursive: true });
        const file = this.fileFor(tenantId);
        const temporary = `${file}.${process.pid}.tmp`;
        writeFileSync(temporary, JSON.stringify(Object.fromEntries(counters.counts), null, 2), "utf8");
        renameSync(temporary, file);
        counters.dirty = false;
      } catch (error) {
        // Analytics must never interrupt the guest application.
        console.warn(`[IrisMap] analytics for "${tenantId}" could not be saved.`, error);
      }
    }
  }

  close() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.flush();
  }
}
