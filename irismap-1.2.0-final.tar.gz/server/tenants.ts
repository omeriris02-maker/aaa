import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import {
  normalizeHotelConfig,
  TENANT_ID,
  type HotelConfig,
  type HotelServerSettings,
} from "../shared/hotelConfig";

/** PNG images made by `npm run otel:gorseller` (home-screen icons, link preview). */
export const GENERATED_IMAGES = {
  icon192: "icon-192.png",
  icon512: "icon-512.png",
  maskable512: "icon-maskable-512.png",
  appleTouch: "apple-touch-icon.png",
  og: "og-image.png",
  favicon: "favicon.ico",
} as const;

export type GeneratedImage = keyof typeof GENERATED_IMAGES;

export interface Tenant {
  id: string;
  directory: string;
  assetsDirectory: string;
  config: HotelConfig;
  server: HotelServerSettings;
  /** Absolute paths of the generated images that exist. */
  images: Partial<Record<GeneratedImage, string>>;
}

export function findGeneratedImages(assetsDirectory: string): Tenant["images"] {
  const images: Tenant["images"] = {};
  for (const [key, file] of Object.entries(GENERATED_IMAGES) as Array<[GeneratedImage, string]>) {
    const candidate = path.join(assetsDirectory, file);
    try {
      if (statSync(candidate).isFile()) images[key] = candidate;
    } catch {
      // not generated yet
    }
  }
  return images;
}

export class TenantLoadError extends Error {
  constructor(readonly problems: string[]) {
    super(`Hotel configuration could not be loaded:\n  - ${problems.join("\n  - ")}`);
    this.name = "TenantLoadError";
  }
}

export const tenantAssetUrl = (tenantId: string, file: string) =>
  `/tenant-assets/${tenantId}/${encodeURIComponent(file)}`;

/** Loads and validates one hotel folder (`<dir>/hotel.json` + `<dir>/assets`). */
export function loadTenantFolder(directory: string, { requireFolderNameMatch = true } = {}): {
  tenant: Tenant | null;
  errors: string[];
  warnings: string[];
} {
  const folderName = path.basename(directory);
  const configPath = path.join(directory, "hotel.json");
  const assetsDirectory = path.join(directory, "assets");
  const label = `tenants/${folderName}/hotel.json`;

  if (!existsSync(configPath)) {
    return { tenant: null, errors: [`${label}: file is missing`], warnings: [] };
  }

  let raw: unknown;
  try {
    raw = JSON.parse(readFileSync(configPath, "utf8").replace(/^﻿/, ""));
  } catch (error) {
    return {
      tenant: null,
      errors: [`${label}: not valid JSON (${(error as Error).message})`],
      warnings: [],
    };
  }

  const declaredId = typeof (raw as { id?: unknown })?.id === "string" ? (raw as { id: string }).id : folderName;
  const { hotel, problems } = normalizeHotelConfig(raw, (file) => {
    const candidate = path.join(assetsDirectory, file);
    if (path.dirname(candidate) !== assetsDirectory) return null;
    try {
      return statSync(candidate).isFile() ? tenantAssetUrl(declaredId, file) : null;
    } catch {
      return null;
    }
  });

  const errors = problems.errors.map((problem) => `${label} → ${problem}`);
  const warnings = problems.warnings.map((problem) => `${label} → ${problem}`);
  if (hotel && requireFolderNameMatch && hotel.config.id !== folderName) {
    errors.push(`${label} → id: must be "${folderName}" (the same as the folder name)`);
  }
  if (!hotel || errors.length > 0) return { tenant: null, errors, warnings };

  return {
    tenant: {
      id: hotel.config.id,
      directory,
      assetsDirectory,
      config: hotel.config,
      server: hotel.server,
      images: findGeneratedImages(assetsDirectory),
    },
    errors,
    warnings,
  };
}

export class TenantRegistry {
  private readonly byHost = new Map<string, Tenant>();

  constructor(
    readonly tenants: Tenant[],
    readonly defaultTenant: Tenant | null,
  ) {
    for (const tenant of tenants) {
      for (const host of tenant.server.hosts) this.byHost.set(host, tenant);
    }
  }

  get(id: string): Tenant | undefined {
    return this.tenants.find((tenant) => tenant.id === id);
  }

  /**
   * The hotel that owns a request host, without falling back to the default.
   * The `Host` header may include a port; both `name:port` and `name` are tried.
   */
  matchHost(host: string | undefined): Tenant | null {
    const value = (host || "").trim().toLowerCase();
    if (!value) return null;
    return this.byHost.get(value) ?? this.byHost.get(value.replace(/:\d+$/, "")) ?? null;
  }

  /** Finds the hotel for a request host, or the default hotel. */
  resolve(host: string | undefined): Tenant | null {
    return this.matchHost(host) ?? this.defaultTenant;
  }
}

/**
 * Loads every hotel folder inside `tenantsDirectory`. Folders starting with
 * "_" or "." are templates and are skipped. Throws a TenantLoadError that
 * lists every problem when any hotel is invalid, so a broken configuration
 * never reaches guests.
 */
export function loadTenants(
  tenantsDirectory: string,
  defaultTenantId?: string,
  log: (message: string) => void = console.warn,
  { includeDemo = false }: { includeDemo?: boolean } = {},
): TenantRegistry {
  if (!existsSync(tenantsDirectory)) {
    throw new TenantLoadError([`tenants folder not found: ${tenantsDirectory}`]);
  }

  const folders = readdirSync(tenantsDirectory, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && !entry.name.startsWith("_") && !entry.name.startsWith("."))
    .map((entry) => entry.name)
    .sort();

  const errors: string[] = [];
  const tenants: Tenant[] = [];
  const skippedDemo: string[] = [];
  for (const folder of folders) {
    if (!TENANT_ID.test(folder)) {
      errors.push(`tenants/${folder}: folder name must use lowercase letters, digits and dashes`);
      continue;
    }
    const result = loadTenantFolder(path.join(tenantsDirectory, folder));
    result.warnings.forEach((warning) => log(`[IrisMap] warning: ${warning}`));
    errors.push(...result.errors);
    // Sales demo hotels ("demo": true) are checked but only served in demo mode.
    if (result.tenant?.server.demo && !includeDemo) skippedDemo.push(result.tenant.id);
    else if (result.tenant) tenants.push(result.tenant);
  }

  const hostOwners = new Map<string, string>();
  for (const tenant of tenants) {
    for (const host of tenant.server.hosts) {
      const owner = hostOwners.get(host);
      if (owner) errors.push(`host "${host}" is used by both "${owner}" and "${tenant.id}"`);
      hostOwners.set(host, tenant.id);
    }
  }

  if (folders.length === 0) errors.push(`no hotel folder found in ${tenantsDirectory}`);
  else if (tenants.length === 0 && skippedDemo.length > 0 && errors.length === 0) {
    errors.push(`only demo hotels were found (${skippedDemo.join(", ")}); set IRISMAP_DEMO=true to serve them`);
  }

  let defaultTenant: Tenant | null = null;
  const requestedDefault = defaultTenantId?.trim();
  if (requestedDefault) {
    defaultTenant = tenants.find((tenant) => tenant.id === requestedDefault) ?? null;
    if (!defaultTenant && skippedDemo.includes(requestedDefault)) {
      errors.push(`IRISMAP_DEFAULT_TENANT="${requestedDefault}" is a demo hotel; set IRISMAP_DEMO=true to serve it`);
    } else if (!defaultTenant && !errors.some((error) => error.includes(`tenants/${requestedDefault}/`))) {
      errors.push(`IRISMAP_DEFAULT_TENANT="${requestedDefault}" does not match any hotel folder`);
    }
  } else if (tenants.length === 1) {
    defaultTenant = tenants[0];
  }

  if (errors.length > 0) throw new TenantLoadError(errors);
  return new TenantRegistry(tenants, defaultTenant);
}
